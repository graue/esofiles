/*
 * An interpreter for the Sortle programming language, written in horrible
 * ANSI C. I mean the code is just awful. Sometimes laughably so. But it
 * may perhaps be interesting, in the manner of a train wreck.
 *
 * Public domain.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum            /* sortle.c version 1.0 */
{                       /* changes:             */
    TKN_LITNUM,         /*   - fixed current expression name being searched */
    TKN_LITSTR,         /*     by regexes */
    TKN_OP,             /*   - fixed regexes not matching if they ended */
    TKN_UNSET           /*     with a @ or ! element that had not been */
} tkntype;              /*     totally fulfilled in the search string */
                        /*   - fixed elements being skipped after a () or */
typedef enum            /*     [] group */
{                       /*   - fixed barfing if a @ element was not matched */
    OPN_ADD,            /*   - fixed regexes searching forwards from the */
    OPN_MUL,            /*     current expression rather than backwards */
    OPN_DIV,            /*   - fixed failure to match if multiple @ */
    OPN_MOD,            /*     elements in a row are missing */
    OPNS_SEP,           /*   - fixed names of unlinked expressions not */
    OPS_MAX = OPNS_SEP, /*     getting freed */
    OPS_CAT,            /*   - implemented clobbering */
    OPS_RGX,            /*   - renamed file to sortle.c */
    OPS_MNY
} optype;

typedef struct tknlst
{
    struct tknlst *prev, *next;
    tkntype type;
    union
    {
        unsigned int num;
        char *str;
        optype op;
    } u;
} tknlst;

typedef struct expr
{
    struct expr *prev, *next;
    char *name;
    tknlst *tkns;
} expr;

typedef struct programinfo
{
    expr *pos;
    int maxstacksize;
} programinfo;

void barf(char *msg)
{
    puts(msg);
    exit(1);
}

void addtkn(expr *start)
{
    tknlst *foothold;
    foothold = start->tkns;
    if(foothold->type != TKN_UNSET)
    {
        tknlst *tmp;
        tmp = foothold->prev;
        foothold->prev = malloc(sizeof(tknlst));
        if(!foothold->prev) barf("Out of memory");
        foothold->prev->next = foothold;
        foothold->prev->prev = tmp;
        tmp->next = foothold->prev;
    }
}

void inittkns(expr *start)
{
    tknlst *tkns;
    tkns = malloc(sizeof(tknlst));
    if(!tkns) barf("Out of memory");
    tkns->prev = tkns->next = tkns;
    tkns->type = TKN_UNSET;
    start->tkns = tkns;
}

/*
// 4 6 8 9 21 54 66 4 6 8 9 21 54 66 ...
//         11^
// keep going right until you find one that's greater than you, but whose
// previous is lower than you

// 4 6 8 9 21 54 66 4 6 8 9 21 54 66 ...
//         99^
// keep going right until you find one that's lower than you, and whose
// previous is also lower than you, but which is lower than its previous

// 4 6 8 9 21 54 66 4 6 8 9 21 54 66 ...
//          1^
// keep going right until you find one that's greater than you, and whose
// previous is also greater than you, but which is lower than its previous

// In general, go right until you find one in any of these cases:
//  1 foothold > name && foothold->prev < name
//  2 foothold < name && foothold->prev < name && foothold < foothold->prev
//  3 foothold > name && foothold->prev > name && foothold < foothold->prev

// In case 2, foothold < foothold->prev && foothold->prev < name implies
//    that foothold < name, so:
//  2 foothold->prev < name && foothold < foothold->prev

// In case 3, foothold < foothold->prev && foothold > name implies
//    that foothold->prev > name, so:
//  3 foothold > name && foothold < foothold->prev

// 2 and 3 then can be combined as follows:
//2&3 foothold < foothold->prev && (foothold->prev < name || foothold > name)

// so
//  (foothold > name && foothold->prev < name)
//||(foothold < foothold->prev && (foothold->prev < name || foothold > name))
*/

#define GREATER(s1, s2) (strcmp(s1, s2) > 0 ? 1 : 0)
#define LESS(s1, s2) (!GREATER(s1, s2))
expr *addexpr(expr *foothold, char *name)
{
    if(foothold->name != NULL && foothold->prev != foothold) /*normal case,*/
    { /* 2 or more expressions */
        expr *tmp;
        while(!(
            (GREATER(foothold->name, name) && LESS(foothold->prev->name,
            name)) || (LESS(foothold->name, foothold->prev->name)
            && (LESS(foothold->prev->name, name)
            || GREATER(foothold->name, name)))
        ))
            foothold = foothold->next;
        if(!strcmp(foothold->prev->name, name) || !strcmp(foothold->name,
            name)) barf("Expression defined twice");
        tmp = foothold->prev;
        foothold->prev = malloc(sizeof(expr));
        if(!foothold->prev) barf("Out of memory");
        foothold->prev->next = foothold;
        foothold->prev->prev = tmp;
        tmp->next = foothold = foothold->prev;
    }
    else if(foothold->name) /* 1 expression */
    {
        expr *tmp;
        tmp = malloc(sizeof(expr));
        if(!tmp) barf("Out of memory");
        foothold->next = foothold->prev = tmp;
        tmp->next = tmp->prev = foothold;
        foothold = tmp;
    }
    foothold->name = malloc(strlen(name) + 1);
    if(!foothold->name) barf("Out of memory");
    strcpy(foothold->name, name);
    inittkns(foothold);
    return foothold;
}
#undef LESS
#undef GREATER

programinfo *load(char *filename)
{
    char buf[65535];
    FILE *fptr;
    programinfo *info;

    fptr = fopen(filename, "rt");
    if(!fptr) barf("Cannot open file");
    info = malloc(sizeof(programinfo));
    if(!info) barf("Out of memory");
    info->pos = malloc(sizeof(expr));
    info->maxstacksize = 0;
    if(!info->pos) barf("Out of memory");
    info->pos->prev = info->pos->next = info->pos;
    info->pos->name = NULL;
    while(fgets(buf, 65535, fptr))
    {
        char *p, *line;
        int stacksize = 0;
        if(!(p = strchr((line = buf), '\n'))) barf("Line too long");
        *p = '\0';
        while(*line && isascii(*line) && isspace(*line)) line++;
            /* remove leading whitespace */
        if(!*line || *line == '#') continue; /* skip comments, blank lines */
        for(p = line; *p != ':' && (!isascii(*p) || !isspace(*p)); p++)
            if(*p < 'A' || (*p > 'Z' && *p < 'a') || *p > 'z')
                barf("Invalid pair1");
        if(*p != ':')
        {
            for(*p++ = '\0'; *p != ':'; p++)
                if(!*p || (!isascii(*p) || !isspace(*p)))
                    barf("Invalid pair2");
        }
            else *p = '\0';
        if(*(++p) != '=') barf("Invalid pair3"); ++p;
        info->pos = addexpr(info->pos, line);
        while(*p && isascii(*p) && isspace(*p)) ++p;
        while(*p)
        {
            char *lut = "\"0123456789+*/%^~?$", *ptknidx;
            int tknidx;
            if(*p == '#') break; /* allow comments at ends of lines */
            ptknidx = strchr(lut, *p);
            if(!ptknidx) barf("Invalid token");
            tknidx = ptknidx - lut;
            addtkn(info->pos);
            info->pos->tkns->prev->type =
                !tknidx ? TKN_LITSTR : (tknidx <= 10 ? TKN_LITNUM : TKN_OP);
            switch(info->pos->tkns->prev->type)
            {
                case TKN_OP:
                    info->pos->tkns->prev->u.op = tknidx - 11 + OPN_ADD;
                    stacksize--;
                    if(stacksize < 0) barf("Expression pulls an empty stack");
                    p++;
                    if(*p && (!isascii(*p) || !isspace(*p)))
                        barf("Invalid expression");
                    break;
                case TKN_LITNUM:
                    info->pos->tkns->prev->u.num = 0;
                    while(*p && isascii(*p) && isdigit(*p))
                    {
                        info->pos->tkns->prev->u.num *= 10;
                        info->pos->tkns->prev->u.num += *p - '0';
                        p++;
                    }
                    if(*p && (!isascii(*p) || !isspace(*p)))
                        barf("Invalid expression");
                    stacksize++;
                    if(stacksize > info->maxstacksize)
                        info->maxstacksize = stacksize;
                    break;
                case TKN_LITSTR:
                {
                    int len = 0, efflen;
                    p++;
                    while(*p != '"') { if(!*p) barf("Unclosed string");
                        p++, len++; }
                    p -= (efflen = len);
                    {
                        int i;
                        for(i = 0; i < len - 2; i++)
                            if(p[i] == '\\' && isascii(p[i+1])
                                && isxdigit(p[i+1]) && isascii(p[i+2])
                                && isxdigit(p[i+2])) efflen -= 2;
                    }
                    info->pos->tkns->prev->u.str = malloc(efflen+1);
                    if(!info->pos->tkns->prev->u.str) barf("Out of memory");
                    {
                        int i;
                        for(i = 0; i <= len; i++)
                        {
                            if(i == len)
                                info->pos->tkns->prev->u.str[i] = '\0';
                            else if(i < len - 2 && p[i] == '\\'
                                && isascii(p[i+1]) && isxdigit(p[i+1])
                                && isascii(p[i+2]) && isxdigit(p[i+2]))
                            {
                                unsigned char uc;
                                if(isdigit(p[i+1])) uc = p[i+1] - '0';
                                else uc = p[i+1] - 'a' + 10;
                                uc *= 10;
                                if(isdigit(p[i+2])) uc += p[i+2] - '0';
                                else uc = p[i+2] - 'a' + 10;
                                info->pos->tkns->prev->u.str[i] = (char)uc;
                            }
                            else
                                info->pos->tkns->prev->u.str[i] = p[i];
                        }
                    }
                    p += len + 1;
                    stacksize++;
                    if(stacksize > info->maxstacksize)
                        info->maxstacksize = stacksize;
                    break;
                }
                default:
                    barf("The thing that should never happen has happened");
            }
            while(*p && isascii(*p) && isspace(*p)) ++p;
        }
        if(stacksize != 1) barf("Deficient or abundant stack");
    }
    if(info->pos->name == NULL) /* no expressions found? */
        barf("No expressions found");
    if(info->pos->next != info->pos) /* >1 lines */
        while(strcmp(info->pos->name, info->pos->prev->name) > 0)
            info->pos = info->pos->next;
    return info;
}

char *evaluate(expr *e, int st);
void exprmostlyfree(expr *d);
void exprfree(expr *d);

void unlinkme(expr *me)
{
    if(me->next == me)
    {
        exprmostlyfree(me);
        me->name = NULL;
    }
    else
    {
        expr *pre, *post;
	pre = me->prev;
        post = me->next;
        exprfree(me);
        pre->next = post;
        post->prev = pre;
    }
}

#define GREATER(s1, s2) (strcmp(s1, s2) > 0 ? 1 : 0)
#define LESS(s1, s2) (!GREATER(s1, s2))
expr *relinkme(expr *me, expr *them)
{
    /* name is the one I want to add, foothold->name is the rover */
    expr *rover = them;
    if(them->next != them) { /* at least 2 them expressions */
    while(!(
        (GREATER(rover->name, me->name) && LESS(rover->prev->name,
        me->name)) || (LESS(rover->name, rover->prev->name)
        && (LESS(rover->prev->name, me->name)
        || GREATER(rover->name, me->name)))
    ))
        rover = rover->next; }

    if(rover != me && !strcmp(rover->name, me->name))
    {
        /* clobber another expression */
	rover = rover->next;
        unlinkme(rover);
    }
    else if(rover->prev != me && !strcmp(rover->prev->name, me->name))
        /* similarly clobber another expression */
        unlinkme(rover->prev);

    if(!rover->name)
    {
        /* I've just clobbered the last other expression */
        rover->name = me->name;
        rover->tkns = me->tkns;
        free(me);
        return rover;
    }

    /* rover is now the one I want to be linked in before */
    me->prev = rover->prev;
    rover->prev = me;
    me->next = rover;
    me->prev->next = me;
    return me;
}
#undef LESS
#undef GREATER

void exprmostlyfree(expr *d)
{
    tknlst *myloc;
    myloc = d->tkns;
    do
    {
        tknlst *tmp;
        if(myloc->type == TKN_LITSTR)
            free(myloc->u.str);
        tmp = myloc;
        myloc = myloc->next;
        free(tmp);
    } while(myloc != d->tkns);
    free(d->name);
}

void exprfree(expr *d)
{
    exprmostlyfree(d);
    free(d);
}

programinfo *run(programinfo *p)
{
    char *newname;

    evaluate(NULL, p->maxstacksize); /* just initialize the stack */

    /* step one */
    if(p->pos->next == p->pos) /* only one expression! */
    {
        puts(p->pos->name);
        goto dead;
    }

    /* step two */
#define current (p->pos)

stepthree:
    /* step three */
    newname = evaluate(current, p->maxstacksize);

    /* step four */
    if(!*newname)
    {
        /* step five */
        expr *predeadexp;
        predeadexp = current->prev;

        /* step six */
        current = current->next;

        /* step seven */
        exprfree(current->prev);
        predeadexp->next = current;
        current->prev = predeadexp;

        /* step eight */
        if(current == predeadexp)
        {
            puts(current->name);
            goto dead;
        }

        /* step nine */
        goto stepthree;
    }
    else
    {
        expr *outsider;
        /* step ten */
        free(current->name);
        current->name = newname;

        /* step eleven */
        current->prev->next = outsider = current->next;
        current->next->prev            = current->prev;
        current->next = current->prev = NULL; /* just to be safe */
        current = relinkme(current, outsider);

        /* step eleven point five (after step eight) */
        if(current == current->next)
        {
            puts(current->name);
            goto dead;
        }

        /* step twelve */
        current = current->next;

        /* step thirteen */
        goto stepthree;
    }

dead:
    return p;
#undef current
}

void myfree(programinfo *p)
{
    expr *startingpoint;
    startingpoint = p->pos;
    do
    {
        tknlst *myloc;
        expr *temp;
        myloc = p->pos->tkns;
        do
        {
            tknlst *tmp;
            if(myloc->type == TKN_LITSTR)
                free(myloc->u.str);
            tmp = myloc;
            myloc = myloc->next;
            free(tmp);
        } while(myloc != p->pos->tkns);
        temp = p->pos;
        p->pos = p->pos->next;
        free(temp);
    } while(p->pos != startingpoint);
    free(p);
}

int main(int argc, char *argv[])
{
    if(argc != 2)
        barf("Usage: sort PROGRAM");
    myfree(run(load(argv[1])));
    return 0;
}

char *strdupe(char *s)
{
    char *result;
    result = malloc(strlen(s) + 1);
    if(!result) barf("Out of memory");
    strcpy(result, s);
    return result;
}

typedef struct stacked
{
    int isnum;
    union
    {
        unsigned int num;
        char *str;
    } u;
} stacked;

char *evalregex(expr *e, char *op1, char *op2);

char *regexwrap(expr *e, char *op1, char *op2)
{
    char *result;
    result = evalregex(e, op1, op2);
    free(op1);
    free(op2);
    return result;
}

void makenumber(stacked *s)
{
    char *p;
    unsigned int num = 0;

    if(s->isnum)
        return;

    for(p = s->u.str; *p && isascii(*p) && isdigit(*p); p++)
    {
        num *= 10;
        num += *p - '0';
    }

    s->u.num = num;
    s->isnum = 1;
}

void makestring(stacked *s)
{
    char *str;
    int digitsrequired = 0;
    unsigned int num;

    if(!s->isnum)
        return;

    num = s->u.num;
    while(num)
    {
        digitsrequired++;
        num /= 10;
    }
    str = malloc(digitsrequired+1);
    if(!str) barf("Out of memory");
    str[digitsrequired] = '\0';
    num = s->u.num;
    while(num)
    {
        digitsrequired--;
        str[digitsrequired] = '0' + num % 10;
        num /= 10;
    }
    s->u.str = str;
    s->isnum = 0;
}

char *superconcat(char *op1, char *op2)
{
    /* concatenate op1 onto the end of op2 */
    char *result;

    result = malloc(strlen(op1) + strlen(op2) + 1);
    if(!result) barf("Out of memory");
    strcpy(result, op2);
    strcat(result, op1);
    free(op1);
    free(op2);
    return result;
}

char *mnymax(char *op1, char *op2)
{
    char *result;
    int cmp;
    cmp = strcmp(op1, op2);
    if(cmp > 0)
    {
        result = op1;
        free(op2);
    }
    else if(cmp)
    {
        result = op2;
        free(op1);
    }
    else
    {
        result = malloc(1);
        if(!result) barf("Out of memory");
        *result = '\0';
        free(op1); free(op2);
    }
    return result;
}

/* e is only needed for regex match, which cares about its start position */

void pushpull(stacked *s, tknlst *t, int *d, expr *e)
{
    s += *d;
    if(t->type == TKN_LITSTR)
    {
        s->u.str = strdupe(t->u.str);
        s->isnum = 0;
        ++(*d);
    }
    else if(t->type == TKN_LITNUM)
    {
        s->u.num = t->u.num;
        s->isnum = 1;
        ++(*d);
    }
    /* t->type must be TKN_OP */
    else if(t->u.op < OPNS_SEP)
    {
        int op1, op2, res;

        makenumber(s-1);
        makenumber(s-2);
        op1 = (s-1)->u.num;
        op2 = (s-2)->u.num;
        if(t->u.op == OPN_ADD) res = op1 + op2;
        else if(t->u.op == OPN_MUL) res = op1 * op2;
        else if(t->u.op == OPN_DIV) res = op2 / op1;
        else /* t->u.op == OPN_MOD */ res = op2 % op1;
        s--, (*d)--;
        (s-1)->u.num = res;
    }
    else /* string operation */
    {
        char *result;
        makestring(s-1);
        makestring(s-2);
        if(t->u.op == OPS_MAX || t->u.op == OPS_MNY)
            result = mnymax((s-1)->u.str, (s-2)->u.str);
        else if(t->u.op == OPS_CAT)
            result = superconcat((s-1)->u.str, (s-2)->u.str);
        else /* t->u.op == OPS_RGX */
            result = regexwrap(e, (s-1)->u.str, (s-2)->u.str);
        s--, (*d)--;
        (s-1)->u.str = result;
    }
}

char *evaluate(expr *e, int st)
{
    static stacked *stack;
    tknlst *tpos;
    int depth = 0;

    if(!e)
    {
        stack = malloc(sizeof(stacked) * st);
        if(!stack) barf("Out of memory");
        return NULL;
    }

    tpos = e->tkns;
    do
    {
        if(depth < 0 || depth > st)
            barf("Depth out of range");
        pushpull(stack, tpos, &depth, e);
        if(depth < 0 || depth > st)
            barf("Depth out of range afterwards");
        tpos = tpos->next;
    } while(tpos != e->tkns);

    if(depth != 1) barf("Internal stack conflict");
    makestring(stack);
    return stack[0].u.str;
}

char *regexmatch(char *srch, char *rgx);

char *evalregex(expr *e, char *op1, char *op2)
{
    /* test for an invalid regular expression */
    {
        int valid = 1, parenstate = 0, bracketstate = 0;
        char *p;
        for(p = op2; *p; p++)
        {
            if(*p == '(')
            {
                if(!parenstate) parenstate = 1;
                else { valid = 0; break; }
            }
            else if(*p == ')')
            {
                if(parenstate == 1) parenstate = 2;
                else { valid = 0; break; }
            }
            else if(*p == '[')
            {
                if(bracketstate == 1) { valid = 0; break; }
                bracketstate = 1;
            }
            else if(*p == ']')
            {
                if(!bracketstate) { valid = 0; break; }
                bracketstate = 0;
            }
            else if((*p == '@' || *p == '!') && (bracketstate || parenstate ==
                1)) { valid = 0; break; }
        }
        if(!valid)
        {
            p = malloc(1);
            if(!p) barf("Out of memory"); /* heh */
            *p = '\0';
            return p;
        }
    }

    if(!*op1)
    {
        char *answersofar = NULL;
        expr *start;
        start = e;
        while(e->prev != start) /* note: the current expression is skipped */
        {                       /* this is important */
            e = e->prev;
            answersofar = regexmatch(e->name, op2);
            if(answersofar) break;
        }
        if(!answersofar) {
        answersofar = malloc(1);
        if(!answersofar) barf("Out of memory");
        *answersofar = '\0'; }
        return answersofar;
    }
    {
        char *answersofar;
        int maxlen, len = 1, ofs = 0;
        maxlen = strlen(op1);
        do
        {
            char c;
            c = op1[ofs + len];
            op1[ofs + len] = '\0';
            answersofar = regexmatch(&op1[ofs], op2);
            op1[ofs + len] = c;
            if(answersofar) break;
            /* test starting at offset ofs, length len */
            if(++ofs + len > maxlen)
            {
                ofs = 0;
                len++;
            }
        } while(len <= maxlen);
        if(!answersofar) {
        answersofar = malloc(1);
        if(!answersofar) barf("Out of memory");
        *answersofar = '\0'; }
        return answersofar;
    }
}

typedef enum
{
    EMOD_0OR1,
    EMOD_1ORMORE,
    EMOD_JUSTONE
} emod;

typedef struct rgxelmt
{
    char *content;
    emod mod;
    int capture;
    char *match;
} rgxelmt;

/* returns 0 if strings are equal */
int strndotcmp(const char *s1, const char *s2, int n)
{
    if(!*s1 && !*s2) return 0;
    if(!*s1 || !*s2) return 1;
    do
    {
        if(*s1 != *s2 && *s1 != '.' && *s2 != '.') return 1;
        if(!--n) return 0;
    }
    while(*(++s1) && *(++s2));
    return 0;
}

void freeelems(rgxelmt *elems, int numelems)
{
    for(numelems--; numelems >= 0; numelems--)
        free(elems[numelems].content);
    free(elems);
}

char *regexmatch(char *srch, char *rgx)
{
    rgxelmt *elems;
    int numelems = 0, i, satisfied, last;
    char *p, *result = NULL;
    elems = malloc(sizeof(rgxelmt) * strlen(rgx)); /* most we could need */
    for(p = rgx; *p; p++)
    {
        if(*p == '(' || *p == '[')
        {
            char *q;
            q = strchr(p, (*p == '(') ? ')' : ']');
            *q = '\0';
            elems[numelems].content = strdupe(p+1);
            elems[numelems].capture = (*p == '(');
            elems[numelems].match = NULL;
            *q = ')';
            p = q+1;
            if(*p == '@') elems[numelems].mod = EMOD_0OR1;
            else if(*p == '!') elems[numelems].mod = EMOD_1ORMORE;
            else { elems[numelems].mod = EMOD_JUSTONE; p--; }
            numelems++;
            continue;
        }
        if(*p == '@' || *p == '!')
            elems[numelems-1].mod = (*p == '@' ? EMOD_0OR1 : EMOD_1ORMORE);
        else
        {
            elems[numelems].capture = 0;
            elems[numelems].mod = EMOD_JUSTONE;
            elems[numelems].content = strdupe("1");
            elems[numelems].content[0] = *p;
            numelems++;
        }
    }

    if(numelems == 0)
    {
        free(elems);
        return NULL; /* can this happen? I don't know, but why risk it, eh */
    }
    last = numelems - 1;

    satisfied = elems[0].mod == EMOD_0OR1 ? 1 : 0;

    for(i = 0, p = srch;;)
    {
        if(!*p)
        {
            if(satisfied && i == last) break;
            freeelems(elems, numelems);
            return NULL; /* srch ended too early, no match */
        }

        if(satisfied && i < last && !strndotcmp(p, elems[i+1].content,
            strlen(elems[i+1].content)))
        {
            i++;
            elems[i].match = p;
            p += strlen(elems[i].content);
            if(elems[i].mod == EMOD_1ORMORE)
                continue; /* note: satisfied already set */
            i++;
            if(i > last)
            {
                if(!*p)
                    break;
                /* too much at end of search string */
                freeelems(elems, numelems);
                return NULL;
            }
            satisfied = elems[i].mod == EMOD_0OR1 ? 1 : 0;
            continue;
        }

        if(!strndotcmp(p, elems[i].content, strlen(elems[i].content)))
        {
            elems[i].match = p;
            p += strlen(elems[i].content);
            if(elems[i].mod == EMOD_1ORMORE)
            {
                satisfied = 1;
                continue;
            }
            i++;
            if(i > last)
            {
                if(!*p)
                    break;
                /* too much at end of search string */
                freeelems(elems, numelems);
                return NULL;
            }
            satisfied = elems[i].mod == EMOD_0OR1 ? 1 : 0;
            continue;
        }

        /* there is still hope if this element and next are both EMOD_0OR1 */
        {
            int j;
            for(j = i; j <= last; j++)
            {
                if(!strndotcmp(p, elems[j].content, strlen(elems[j].content)))
                {
                    elems[j].match = p;
                    p += strlen(elems[j].content);
                    i = j;
                    if(elems[i].mod == EMOD_1ORMORE)
                        goto outercontinue;
                    i++;
                    if(i > last)
                    {
                        if(!*p)
                            break;
                        /* too much at end of search string */
                        freeelems(elems, numelems);
                        return NULL;
                    }
                    satisfied = elems[i].mod == EMOD_0OR1 ? 1 : 0;
                    goto outercontinue;
                }
                if(j == last || elems[j].mod != EMOD_0OR1)
                    break;
            }

            if(0)
outercontinue:
                continue;
        }
        freeelems(elems, numelems);
        return NULL; /* no match */
    }

    /* each element should now be matched */
    for(i = 0; i < numelems; i++)
    {
        if(!elems[i].match)
        {
            if(elems[i].mod != EMOD_0OR1)
            {
                fprintf(stderr, "I don't have a match for element %d!\n", i);
                barf("Oh no!");
            }
            if(elems[i].capture)
            {
                /* you captured a 0-or-1 element, and it wasn't there. */
                /* that means the match succeeds, but you get an empty
                   string anyway */
                /* note: may mask a nonempty result you would have gotten
                   from another substring or expression name */
                freeelems(elems, numelems);
                return strdupe("");
            }
        }
        if(elems[i].capture)
        {
            char c;
            c = elems[i].match[ strlen(elems[i].content) ];
            elems[i].match[ strlen(elems[i].content) ] = '\0';
            if(result)
            {
                fprintf(stderr, "I already had a result before element %d\n",
                i); barf("Oh no!");
            }
            result = strdupe(elems[i].match);
            elems[i].match[ strlen(elems[i].content) ] = c;
        }
    }

    if(!result)
        result = strdupe(srch);

    freeelems(elems, numelems);
    return result;
}
