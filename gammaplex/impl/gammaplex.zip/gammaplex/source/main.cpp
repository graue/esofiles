/*
Gammaplex Interpreter

Copyright (c) 2004, Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

*) Redistributions of source code must retain the above copyright notice, this 
list of conditions and the following disclaimer.
*) Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <cmath>
#include <cstdlib> //for random numbers rand();
#include <SDL/SDL.h>
#include <iostream>
#include <fstream>
#include "QuickCG.h"
using namespace std;

#define RA 1048576
#define SA 1048576

#define MAXIW 1024
#define MAXIH 1024

#define MAXGOSUB 1024



Uint8 instruction[MAXIW][MAXIH];

Uint32 ix = 0, iy = 0; //instruction pointer
Uint32 iw, ih; //width and height of actual instruction matrix
Uint32 id = 1; //instruction pointer direction (N, E, S, W); 1 = E (to the right)
Scalar sc[RA]; //max 65536 scalars in memory, the first 8 are parameters of functions
Scalar st[SA]; //a stack to put extra values on
Uint32 rp, sp; //the register pointer, and the stack pointer (stack pointer only used internally)
Scalar dc = 1; //the decimal counter: 1 = will create new number on stack, 0 = enter digits before point, 0.1 - 0.0000000...00001 = enter digits after the point
Scalar anchorTime = 50; //minimum time between two time anchors in milliseconds
Scalar lastAnchorTime; //time at previous time anchor
int instructionMode = 0; //extended or string mode: 0 = normal, 1 = extended command, 2 = string mode, 3 = temporary normal command mode while in string mode
int currentInstruction;
int debugMode = 0;
int gosubx[MAXGOSUB]; //for RETURN commands of GOSUBS
int gosuby[MAXGOSUB];
int gosubd[MAXGOSUB];
int gp; //gosub pointer
Uint32 ticks = 0;
int numStackProgram = 0; //hoeveel registers / stack kopieren met stack program
int stackProgram[16]; //16 register addressen voor te poppen / pushen
int stringCommandLifeSpan = 0;

bool escapeRelease = 0;


inline void changeDC(int digit);
inline void moveIP();
inline void moveIPBack();
void push(Scalar value);
Scalar pop();
#define PROGRAMBUFFER 1048576
char buffer[PROGRAMBUFFER]; //max progarm size currently 1024x1024
int startX, startY; //here the ip will start
void printDebugInfo();
void userInteraction();
void loadCodeFile(char * filename);
void initializeParameters();
void executeCommand(Uint8 instruction);

//gammadraw functions
void GgetRGB(int c, Uint8& R, Uint8& G, Uint8& B);
void GsetRGB(int& c, Uint8 R, Uint8 G, Uint8 B);
void Gpset(int x, int y, bool textBG = 0);
bool Gline(int x1, int y1, int x2, int y2);
bool Gdisk(int xc, int yc, int radius);
bool Gcircle(int xc, int yc, int radius);
void Gcls();
bool Grect(int x1, int y1, int x2, int y2);
int Gprint(char *text, int x = 0, int y = 0);
int Giprint(int a, int x = 0, int y = 0, bool orderSigns = 0);
int Gfprint(double a, int length, int x = 0, int y = 0, bool orderSigns = 0);
int Gcprint(unsigned char n, int x = 0, int y = 0);
  
int main(int argc, char *argv[])
{       
    screen(256,256,0, "Gammaplex - Hit esc for menu"); 
    
    initializeParameters();
    
    if(argv[1]) loadCodeFile(argv[1]);
    else loadCodeFile("gamma.txt");      
    
    //set initial anchor time
    lastAnchorTime = getTime();
    
    cls();
    redraw();
    
    
    //start main loop
    while(!done())
    {      
        //when you press escape, give options      
        readKeys();
        if(inkeys[SDLK_ESCAPE] && escapeRelease) {escapeRelease = 0; userInteraction();}
        if(!inkeys[SDLK_ESCAPE]) escapeRelease = 1;         
        
                
        //get current instruciton
        currentInstruction = instruction[ix][iy];
        
        //safety for array parameters
        sp %= SA;
        rp %= RA;
          
        executeCommand(currentInstruction);              
               
        //increment instruction pointer in current direction
        moveIP();
        ticks++;

        //debug info
        if(debugMode > 0)
        {
            //when debugmode is 1: printed at redraw command 'R'
            if(debugMode >= 2) //do it every single frame now
            {
                drawBuffer(screenBuffer);
                printDebugInfo();
                redraw();
            }    
            if(debugMode == 3) sleep();
        }      
        
    }    
    return(0);    
}

int x, y, z, r, g, b, i, j, x1, x2, yy1, y2, x3, y3, x4, y4; //some variables to use at will
Scalar s, t, u, v;//and some scalars if they would be needed
bool b1, b2; //some bools wiiiiii
Uint8 red, green, blue; //yay
char text[256]; //teh omfg!

void executeCommand(Uint8 executeInstruction)
{
    
       
    //set decimal counter to 1 if command is not one of the following:
    if((currentInstruction != '0' && currentInstruction != '1' &&
        currentInstruction != '2' && currentInstruction != '3' &&
        currentInstruction != '4' && currentInstruction != '5' &&
        currentInstruction != '6' && currentInstruction != '7' &&
        currentInstruction != '8' && currentInstruction != '9' &&
        currentInstruction != '.' && currentInstruction != 92  &&/*backslash*/
        currentInstruction != '/' && currentInstruction != '@' &&
        currentInstruction != ';' && currentInstruction != ' ' &&
        currentInstruction != '<' && currentInstruction != '>' &&
        currentInstruction != '^' && currentInstruction != 'v' &&
        currentInstruction != 0)) dc = 1;
    
    
    //perform current command
    bool executeStringCommand = 0;
    if(instructionMode == 3 &&
       (currentInstruction == '>' || currentInstruction == 'v' ||
        currentInstruction == '<' || currentInstruction == '^' ||
        currentInstruction == '/' || currentInstruction == '\\'||
        currentInstruction == ';' || currentInstruction == ' ' ||
        currentInstruction == '#' || currentInstruction == '@' ||
        currentInstruction == ';' || currentInstruction == ' ' ||
        currentInstruction == '+' || currentInstruction == '-' ||
        currentInstruction == '*' || currentInstruction == ':'))
    executeStringCommand = 1;
    if(instructionMode == 0 || executeStringCommand)
    {
        switch(executeInstruction)
        {
            //setting and getting rp and sp
            case 'u': rp++; break;
            case 'd': rp--; break;        
            
            //program flow
            case 92: if(id == 0) id = 3;
                     else if(id == 3) id = 0;
                     else if(id == 1) id = 2;
                     else id = 1;
                     break;
            case '/': if(id == 0) id = 1;
                     else if(id == 1) id = 0;
                     else if(id == 2) id = 3;
                     else id = 2;
                     break;
            case '^': id = 0; break;
            case '>': id = 1; break;
            case 'v': id = 2; break;
            case '<': id = 3; break;
            case 'G': ix = int(pop()); iy = int(pop()); 
                      moveIPBack();
                      break;
            case 'g': push(iy); push(ix); break;
            case '?': u = pop();
                      if(u == 0) moveIP(); //if current stack is false, jump one more forward
                      break;
            case ';': moveIP(); break; //jump over next command and do not execute it, the second moveIP() is done by general program flow ofcourse
            case 'E': moveIPBack(); break;
            case 'e': sleep(); break;
            case 'j': while(getTime() - lastAnchorTime < anchorTime)
                      {
                          SDL_Delay(1);
                          if(done()) end();
                      }    
                      lastAnchorTime = getTime();
                      break;
    
            //math
            case '0': changeDC(0); break;
            case '1': changeDC(1); break;
            case '2': changeDC(2); break;
            case '3': changeDC(3); break;
            case '4': changeDC(4); break;
            case '5': changeDC(5); break;
            case '6': changeDC(6); break;
            case '7': changeDC(7); break;
            case '8': changeDC(8); break;
            case '9': changeDC(9); break;
            case '.': if(dc == 1) push(0); dc = 0.1; break;
            case '"': st[sp]++; break;
            case '\'': st[sp]--; break;
            case '+': s = pop(); t = pop(); push(s + t); break;
            case '-': s = pop(); t = pop(); push(t - s); break;
            case '*': s = pop(); t = pop(); push(s * t); break;
            case ':': s = pop(); t = pop(); push(t / s); break;
            case '~': s = pop(); t = pop(); push(pow(t, s)); break;
            case 'V': st[sp] = sqrt(st[sp]); break;
            case 'T': push(cos(pop())); break;
            case 'p': push(3.1415926535897932384626433832795); break;
            case '%': s = pop(); t = pop(); push(Scalar(int(s) % max(1, int(t)))); break;
            case '&': s = pop(); t = pop(); push(Scalar(int(s) & int(t))); break;
            case '|': s = pop(); t = pop(); push(Scalar(int(s) | int(t))); break;
            case 'x': s = pop(); t = pop(); push(Scalar(int(s) ^ int(t))); break;
            case '!': s = pop(); if(s == 0) s = 1; else s = 0; push(s); break;
            case '_': s = st[sp] = -st[sp]; break;
            case '=': s = pop(); t = pop(); if(s == t) push(1); else push(0); break;
            case ',': s = pop(); t = pop(); if(s < t) push(1); else push(0); break;
            case 't': push(Scalar(getTime())); break;
            case 'N': st[sp] = 0; break;
            case 'n': push(255); break;
            case 'o': push(int(pop())); break;
            case 'k': push(abs(rand()) % 2); break;
            case 'K': push((abs(rand()) % 16384) / 16384.0); break;
            
            //input
            case 'M': getMouseState(x, y); push(y); push(x); break;
            case 'm': getMouseState(x, y, b1, b2); push(b2); push(b1); break;
            case 'I': push(getChar(Uint32(sc[0]) % w, Uint32(sc[1]) % h, Uint32(pop()), 0, Uint8(sc[2]), Uint8(sc[3]), Uint8(sc[4]))); 
                      break;
            case 'J': push(getNumber(Uint32(sc[0]) % w, Uint32(sc[1]) % h, Uint32(pop()), 0, Uint8(sc[2]), Uint8(sc[3]), Uint8(sc[4]))); 
                      break;
            
            //debug mode
            case 'U': debugMode++; debugMode %= 4; break;
            
            //self modifying code
            case 'q': x = Uint32(pop()) % iw; y = Uint32(pop()) % ih;
                      push(instruction[x][y]);
                      break;
            case 'Q': x = Uint32(pop()) % iw; y = Uint32(pop()) % ih;
                      instruction[x][y] = Uint8(pop());
                      break;                      
            
            //graphics
            case 'l': screen(min(max(Uint32(sc[0]), 64), MAXSCREENU), min(max(Uint32(sc[1]), 64), MAXSCREENV), 0 ,"Gammaplex - Hit esc for menu"); break;
            case 'P': Gpset(Uint32(sc[0]) % w, Uint32(sc[1]) % h); break;
            case 'L': x1 = int(sc[0]); yy1 = int(sc[1]); x2 = int(sc[6]); y2 = int(sc[7]);
                      if(clipLine(x1, yy1, x2, y2, &x3, &y3, &x4, &y4))           
                      Gline(x3, y3, x4, y4); 
                      break;
            case 'R': drawBuffer(screenBuffer); 
                      if(debugMode > 0) printDebugInfo(); //debug info is printed to screenbuffer, not gamma graphics buffer
                      redraw(); 
                      break;
            case 'h': push(h-1); break;
            case 'y': push(w-1); break;
            case 'c': Gcls(); break;
            case 'C': Gcircle(Uint32(sc[0]) % w, Uint32(sc[1]) % h, Uint32(sc[5]));
                      break;
            case 'F': Gdisk(Uint32(sc[0]) % w, Uint32(sc[1]) % h, Uint32(sc[5]));
                      break;                      
            case 'B': x1 = int(sc[0]); yy1 = int(sc[1]); x2 = int(sc[6]); y2 = int(sc[7]);
                      if(clipLine(x1, yy1, x2, y2, &x3, &y3, &x4, &y4)) //clipline is just as useful for clipping rectangles          
                      Grect(x3, y3, x4, y4); 
                      break;
            case 'r': Gcprint(Uint8(pop()), Uint32(sc[0]) % w, Uint32(sc[1]) % h);
                      sc[0] += 8;
                      if(sc[0] > w - 8) {sc[0] = Uint32(sc[0]) % 8; sc[1] += 8;}
                      if(sc[1] > h - 8) {sc[1] = Uint32(sc[1]) % 8;}
                      break;
            case 'i': push(Giprint(Sint32(pop()), Uint32(sc[0]) % w, Uint32(sc[1]) % h));
                      break;
            case 'f': push(Gfprint(pop(), 6, Uint32(sc[0]) % w, Uint32(sc[1]) % h));
                      break;      
            case 'H': x = max(0, min(255, int(pop())));      
                      y = max(0, min(255, int(pop())));
                      z = max(0, min(255, int(pop())));
                      HSVtoRGB(x, y, z, Uint8(r), Uint8(g), Uint8(b));
                      push(b);
                      push(g);
                      push(t);
                      break;                        
            //stack
            case '(': push(sc[rp]); break;
            case ')': sc[rp] = pop(); break;
            case '[': push(rp); break;
            case ']': rp = Uint32(pop()); break;
            case 'D': pop(); break;
            case 'w': push(st[sp]); break;
            case 'W': push(st[(sp-1)%SA]); push(st[(sp-1)%SA]); break;
            case 'Y': i = int(pop()); 
                      for(int ii = 0; ii < i; ii++) push( st[ (sp-i+1)%SA ] );
                      break;
            case 's': st[(sp-1)%SA] += st[sp];  st[sp] = st[(sp-1)%SA] - st[sp];  st[(sp-1)%SA] -= st[sp]; break;
            case 'S': st[(sp-2)%SA] += st[sp];  st[sp] = st[(sp-2)%SA] - st[sp];  st[(sp-2)%SA] -= st[sp]; break;
            case '$': i = int(pop()); st[(sp-i)%SA] += st[sp];  st[sp] = st[(sp-i)%SA] - st[sp];  st[(sp-i)%SA] -= st[sp]; break;
            case 'z': u = st[sp]; st[sp] = st[(sp - 2) % SA]; st[(sp - 1) % SA] = u; st[(sp - 2) % SA] = st[(sp - 1) % SA]; break;
            case 'Z': i = int(pop());
                      u = st[sp];
                      st[sp] = st[(sp - j) % SA];
                      st[sp - 1] = u;
                      for(int jj = 2; jj < j; jj++) st[(sp - jj) % SA] = st[(sp - jj + 1) % SA];
                      break;
            case '{': for(int g = 0; g < numStackProgram; g++)
                      {
                          push(sc[(numStackProgram - stackProgram[g] - 1) % RA]);
                      }    
                      break;       
            case '}': for(int g = 0; g < numStackProgram; g++)
                      {
                          sc[stackProgram[g] % RA] = pop();
                      }    
                      break;  
            case 'a': x = abs(int(pop()));
                      switch(x)
                      {
                          case 0: numStackProgram = 0; 
                                  break;
                          case 1: numStackProgram = 2; 
                                  stackProgram[0] = 0; 
                                  stackProgram[1] = 1; 
                                  break;
                          case 2: numStackProgram = 2; 
                                  stackProgram[0] = 6; 
                                  stackProgram[1] = 7; 
                                  break;
                          case 3: numStackProgram = 3; 
                                  stackProgram[0] = 2; 
                                  stackProgram[1] = 3; 
                                  stackProgram[1] = 4;                                       
                                  break;
                          case 4: numStackProgram = 3; 
                                  stackProgram[0] = 8; 
                                  stackProgram[1] = 9; 
                                  stackProgram[1] = 10;                                       
                                  break;
                          case 5: numStackProgram = 8; 
                                  stackProgram[0] = 0; 
                                  stackProgram[1] = 1; 
                                  stackProgram[1] = 2;                                       
                                  stackProgram[0] = 3; 
                                  stackProgram[1] = 4; 
                                  stackProgram[1] = 5;                                       
                                  stackProgram[0] = 6; 
                                  stackProgram[1] = 7;                                       
                                  break;
                          case 6: numStackProgram = 13; 
                                  stackProgram[0] = 0; 
                                  stackProgram[1] = 1; 
                                  stackProgram[1] = 2;                                       
                                  stackProgram[0] = 3; 
                                  stackProgram[1] = 4; 
                                  stackProgram[1] = 5;                                       
                                  stackProgram[0] = 6; 
                                  stackProgram[1] = 7;
                                  stackProgram[0] = 8; 
                                  stackProgram[1] = 9; 
                                  stackProgram[1] = 10;                                       
                                  stackProgram[0] = 11; 
                                  stackProgram[1] = 12;                                                                             
                                  break;                                                                            
                      }   
                      break;
            case 'A': x = abs(int(pop()));
                      y = 0; 
                      if(x > 16) x = 16; 
                      while(y < x)
                      {
                          y++;
                          stackProgram[y] = max(0, min(RA, int(pop())));
                      } 
                      break;   
            case 'X': instructionMode = 1; break;            
            default: break;
            
            //controleer of alles BREAK; heeft!
        }
        if(instructionMode == 3) 
        {
            if(stringCommandLifeSpan == 0) instructionMode = 2;
            if(stringCommandLifeSpan > 0) stringCommandLifeSpan--;            
        }    
    }           
    else if(instructionMode == 1)
    {
        instructionMode = 0; //the next instruction has to be unextended again
        switch(executeInstruction)
        {
            case ';': moveIP(); moveIP(); break; //jump over next command aand the one after that nd do not execute it, the third moveIP() is done by general program flow ofcourse
            case 92: if(id == 0) id = 3;
                     else if(id == 3) id = 0;
                     else if(id == 1) id = 2;
                     else id = 1;
                     instructionMode = 1;
                     break;
            case '/': if(id == 0) id = 1;
                     else if(id == 1) id = 0;
                     else if(id == 2) id = 3;
                     else id = 2;
                     instructionMode = 1; 
                     break;
            case '^': id = 0; instructionMode = 1; break;
            case '>': id = 1; instructionMode = 1; break;
            case 'v': id = 2; instructionMode = 1; break;
            case '<': id = 3; instructionMode = 1; break;     
            case ' ': instructionMode = 1; break;
            case '@': instructionMode = 1; break;
            case '#': instructionMode = 0; break; 
            case '"': instructionMode = 2; break;
            case 'U': debugMode = 0; break;    
            //GOSUB
            case 'G': gosubx[gp] = ix;
                      gosuby[gp] = iy;
                      gosubd[gp] = id;
                      gp++;
                      gp %= MAXGOSUB;                    
                      ix = int(pop()); iy = int(pop()); 
                      moveIPBack();
                      break;
            case 'g': gp--;
                      if(gp < 0) gp = MAXGOSUB - 1;
                      ix = gosubx[gp]; iy = gosuby[gp]; id = gosubd[gp];
                      //moveIPBack(); //NO WAY, don't moveIPBack for "return" after gosub, or you'll do the gosub command AGAIN! ;)
                      break;
            case 'j': anchorTime = max(0, int(pop())); break;
            case '?': u = pop();
                      if(u == 0) {moveIP(); moveIP();}//if current stack is false, jump one more forward
                      break;
            case 'H': r = max(0, min(255, int(pop())));      
                      g = max(0, min(255, int(pop())));
                      b = max(0, min(255, int(pop())));
                      RGBtoHSV(r, g, b, Uint8(x), Uint8(y), Uint8(z));
                      push(z);
                      push(y);
                      push(x);
                      break;   
            case 'T': r = abs(int(pop())); //GonioFreak(TM)
                      u = pop();
                      switch(r)
                      {
                          case 0: push(0); break;
                          case 1: push(sin(u)); break;
                          case 2: push(cos(u)); break;
                          case 3: push(tan(u)); break;
                          case 4: push(1.0 / cos(u)); break;
                          case 5: push(1.0 / sin(u)); break;
                          case 6: push(1.0 / tan(u)); break;
                          case 7: push(asin(u)); break;
                          case 8: push(acos(u)); break;
                          case 9: push(atan(u)); break;
                          case 10: push(1.0 / acos(u)); break;
                          case 11: push(1.0 / asin(u)); break;
                          case 12: push(1.0 / atan(u)); break;
                          case 13: push(sinh(u)); break;
                          case 14: push(cosh(u)); break;
                          case 15: push(tanh(u)); break;
                          case 16: push(1.0 / cosh(u)); break;
                          case 17: push(1.0 / sinh(u)); break;
                          case 18: push(1.0 / tanh(u)); break;
                          case 19: push(log(u + sqrt(1 + u * u))); break;
                          case 20: push(log(u + sqrt(u + 1) * sqrt(u - 1))); break;
                          case 21: push(0.5 * (log(1 + u) - log(1 - u))); break;
                          case 22: push(log(sqrt(1 / u - 1) * sqrt(1 / u + 1) + 1 / u)); break;
                          case 23: push(log(sqrt(1 + 1 / (u * u)) + 1 / u)); break;
                          case 24: push(0.5 * (log(1 + 1 / u) - log(1 - 1 / u))); break;
                          case 25: push(exp(u)); break;
                          case 26: push(log(u)); break;
                          case 27: push(exp(-(u * u))); break; //sorta gaussian distrubution (standard normal distribution)
                          case 28: if(u < 0) push(-1);
                                   else if(u == 0) push(0);
                                   else push(1);
                                   break;                          
                          case 64: push(atan2(pop(), u)); break;
                          case 65: push(log(pop())/log(u)); break;
                          default: break;
                      }    
                      break;
            case 's': x = abs(int(pop())) % SA;
                      for(int gg = 0; gg < x / 2; gg++)
                      {
                          st[(sp - gg) % SA] += st[(sp - x + gg + 1) % SA];  st[(sp - x + gg + 1) % SA] = st[(sp - gg) % SA] - st[(sp - x + gg + 1) % SA];  st[(sp - gg) % SA] -= st[(sp - x + gg + 1) % SA];
                      }  
                      break;  
            case 'S': y = sp;
                      x = 0;
                      while(st[y] > 0 && st[y] < 256 && x < SA) 
                      {
                          y--;
                          if(y < 0) y = SA - 1;
                          x++;
                      }    
                      for(int gg = 0; gg < x / 2; gg++)
                      {
                          st[(sp - gg) % SA] += st[(sp - x + gg + 1) % SA];  st[(sp - x + gg + 1) % SA] = st[(sp - gg) % SA] - st[(sp - x + gg + 1) % SA];  st[(sp - gg) % SA] -= st[(sp - x + gg + 1) % SA];
                      }  
                      break; 
            case 'w': y = sp;
                      x = 0;
                      while(st[y] > 0 && st[y] < 256 && x < SA) 
                      {
                          y--;
                          if(y < 0) y = SA - 1;
                          x++;
                      }    
                      for(int gg = 0; gg < x; gg++)
                      {
                          text[gg] = Uint8(st[(sp - gg) % SA]);
                      }
                      push(0);
                      for(int gg = x - 1; gg >= 0; gg--)
                      {
                          push(text[gg]);
                      }                                             
                      break;  
            case 'I': getString(text, Uint32(sc[0]) % w, Uint32(sc[1]) % h, Uint32(pop()), Uint8(sc[2]), Uint8(sc[3]), Uint8(sc[4])); 
                      x = 0;
                      push(0); //string termination character
                      while(text[x] != 0 && x < 256) {push(text[x]); x++;}
                      //after pushing the string to the stack, mirror it
                      ////
                      y = sp;
                      x = 0;
                      while(st[y] > 0 && st[y] < 256 && x < SA) 
                      {
                          y--;
                          if(y < 0) y = SA - 1;
                          x++;
                      }    
                      for(int gg = 0; gg < x / 2; gg++)
                      {
                          st[(sp - gg) % SA] += st[(sp - x + gg + 1) % SA];  st[(sp - x + gg + 1) % SA] = st[(sp - gg) % SA] - st[(sp - x + gg + 1) % SA];  st[(sp - gg) % SA] -= st[(sp - x + gg + 1) % SA];
                      }    
                      ////                   
                      break; 
            case 'r': x = 0;
                      while(st[sp] > 0 && st[sp] < 256 && x < SA)
                      {
                          Gcprint(Uint8(pop()), Uint32(sc[0]) % w, Uint32(sc[1]) % h);
                          sc[0] += 8;
                          if(sc[0] > w - 8) {sc[0] = Uint32(sc[0]) % 8; sc[1] += 8;}
                          if(sc[1] > h - 8) {sc[1] = Uint32(sc[1]) % 8;}
                          x++;
                      }  
                      //pop(); 
                      break;
            case 'P': GgetRGB(screenBuffer[h * (abs(int(sc[0])) % w) + (abs(int(sc[1])) % h)], red, green, blue);
                      push(red); push(green); push(blue); 
                      break;                     
            default: break;   
            
            
            //controleer of alles BREAK; heeft!
        }            
    }
    else if(instructionMode == 2)
    {
        if(executeInstruction == '"') instructionMode = 3;
        else push(executeInstruction);
    }        
    else if(instructionMode == 3)
    {
        if(stringCommandLifeSpan == 0) instructionMode = 2;
        if(stringCommandLifeSpan > 0) stringCommandLifeSpan--;
        if(executeInstruction == 'X') instructionMode = 0;
        if(executeInstruction == '"') push('"');            
        if(executeInstruction == '2') {stringCommandLifeSpan = 1; instructionMode = 3;}
    }     
}    

void initializeParameters()
{
    //initialize buffers and values
    for(int x = 0; x < MAXIW; x++)
    for(int y = 0; y < MAXIH; y++)
    {
        instruction[x][y] = 0;
    } 
    for(int x = 0; x < MAXGOSUB; x++)
    {
        gosubx[x] = 0;
        gosuby[x] = 0;
        gosubd[x] = 0;
    } 
    for(int x = 0; x < RA; x++)
    {
        sc[x] = 0.0;
    } 
    sc[2] = sc[3] = sc[4] = 255;
    for(int x = 0; x < SA; x++)
    {
        st[x] = 0.0;
    } 
    for(int x = 0; x < MAXSCREENU; x++)
    for(int y = 0; y < MAXSCREENV; y++)
    {
        GsetRGB(screenBuffer[MAXSCREENV * x + y], 0, 0, 0);
    } 
    ix = 0;
    iy = 0;
    id = 1; //instruction pointer direction (N, E, S, W); 1 = E (to the right)
    rp = 0; 
    sp = 0;
    dc = 1; //the decimal counter: 1 = will create new number on stack, 0 = enter digits before point, 0.1 - 0.0000000...00001 = enter digits after the point
    anchorTime = 50; //minimum time between two time anchors in milliseconds
    lastAnchorTime = getTime(); //time at previous time anchor
    instructionMode = 0; //extended or string mode: 0 = normal, 1 = extended command, 2 = string mode, 3 = temporary normal command mode while in string mode
    debugMode = 0;
    gp = 0; //gosub pointer
    ticks = 0;
    numStackProgram = 0; //hoeveel registers / stack kopieren met stack program
    for(int i = 0; i < 16; i++) stackProgram[i] = 0; //16 register addressen voor te poppen / pushen
    screen(256,256,0, "Gammaplex - Hit esc for menu");     
}    

void loadCodeFile(char * filename)
{
    //load up the file
    //any character with ascii code <32 is seen as "enter" value!
    //open file itself
    int filesize = 0;

    std::ifstream file (filename, std::ios::in|std::ios::binary|std::ios::ate);
    if(!file) {cls(); print("File not found. Default code file is gamma.txt, load other files with command line parameter or from within this program with escape, then option 3. Press any key to continue."); redraw(); sleep();}
    else
    {
        filesize = file.tellg();
        if(filesize > PROGRAMBUFFER) filesize = PROGRAMBUFFER;
        file.seekg (0, std::ios::beg);
        file.read (buffer, filesize);
        file.close();          
    }      
    
    //parse file
    //line 1: first line of the instructions, and get width
    if(filesize > 0)
    {
        int filePos = 0;   
        int iPosX = 0, iPosY = 0; 
        while(buffer[filePos]>=32 && filePos < filesize)
        {
            instruction[iPosX][0] = buffer[filePos];
            if(buffer[filePos] == '@') {startX = iPosX; startY = iPosY;}
            filePos++;
            iPosX++;
            
        }
        iw = iPosX;
        iPosY++;
        iPosX = 0;
    
        while(filePos < filesize)
        {
            instruction[iPosX][iPosY] = buffer[filePos];
            if(buffer[filePos] == '@') {startX = iPosX; startY = iPosY;}
            if(buffer[filePos] < 32) {filePos++; continue;}
            filePos++;
            iPosX++;
            if(iPosX >= iw)
            {
                iPosX = 0;
                iPosY++;
            }    
        }
        ih = iPosY;
        
        ix = startX;
        iy = startY;
    }    
    else
    {
        iw = ih = 1;
        instruction[0][0] = 0;
        ix = 0; iy = 0; id = 0;
    }      
}    

void userInteraction()
{
    cls();
    int i = -1;
    bool chosen = 0;
    
    while(!chosen)
    {
        print("Gammaplex Programming Language", 0, 0, 255, 0, 0, 1);
        print("Choose Option:", 0, 8,255,255,255,1);
        print(" 1. Continue", 0, 16,255,255,255,1);
        print(" 2. Exit", 0, 24,255,255,255,1);
        print(" 3. Load Code File", 0, 32,255,255,255,1);
        print(" 4. Memory Editor", 0, 40,255,255,255,1);
        print(" 5. Debugging Options", 0, 48,255,255,255,1);
        print(" 6. Execute Command", 0, 56,255,255,255,1); 
        print(" 9. About...", 0, 64,255,255,255,1);               
        redraw();
        i = numberKey();
        if(i > 0 && i < 10) chosen = 1;
        readKeys();
        if(inkeys[SDLK_ESCAPE] && escapeRelease) {chosen = 1; escapeRelease = 0;}
        if(!inkeys[SDLK_ESCAPE]) escapeRelease = 1; 
        if(done()) end();       
    }    
    if(i == 2)
    {
        end();
    }    
    if(i == 3)
    {
        initializeParameters();
        char filename[256];
        getString(filename, 0, 0, 8);
        loadCodeFile(filename);
        cls();
    }    
    if(i == 4)
    {
        cls();
        chosen = 0;
        bool editloop = 1;
        int j = -1;
        while(editloop)
        {
            print("Choose Option",0,0,255,255,255,1);
            print(" 0. Continue", 0, 8,255,255,255,1);
            print(" 1. Show Info", 0, 16,255,255,255,1);
            print(" 2. Modify Register", 0, 24,255,255,255,1);
            print(" 3. Pop Stack", 0, 32,255,255,255,1);
            print(" 4. Push Stack", 0, 40,255,255,255,1);
            print(" 5. Modify Instruction", 0, 48,255,255,255,1);            
            print(" 6. Modify Instruction Array", 0, 56,255,255,255,1);         
            print(" 7. Modify IP", 0, 64,255,255,255,1);  
            redraw();
            j = numberKey();
            if(j == 0) editloop = 0;
            if(j == 1)
            {
                cls();
                print("iw:", 0, 0); iprint(iw, 24, 0,255,255,255,1);
                print("ih:", 0, 8); iprint(ih, 24, 8,255,255,255,1);
                print("ix:", 0, 16); iprint(ix, 24, 16,255,255,255,1);
                print("iy:", 0, 24); iprint(iy, 24, 24,255,255,255,1);
                print("id:", 0, 32); iprint(id, 24, 32,255,255,255,1);
                print("Press any key to continue", 0, 40,255,255,255,1);
                redraw();
                sleep();
                cls();
            }             
            if(j == 2)
            {
                Uint32 reg = Uint32(getNumber(0,0,-1,"Enter Register Number:",0,0,255,255,255,1)) % RA;
                sc[reg] = getNumber(0,0,-1,"Enter New Value:",255,255,255,1);
                cls();
            }  
            if(j == 3) pop();
            if(j == 4) 
            {
                push(getNumber(0,0,-1,"Enter Value to Push:",255,255,255,1));
                cls();
            }    
            if(j == 5)
            {
                int inx = Uint32(getNumber(0,0,-1,"Enter X Coordinate:",255,255,255,1))%iw;
                int iny = Uint32(getNumber(0,0,-1,"Enter Y Coordinate:",255,255,255,1))%ih;                
                instruction[inx][iny] = Uint8(getNumber(0,0,-1,"Enter New Instruction:",255,255,255,1));
                cls();
            } 
            if(j == 6)
            {
                iw = max(1, Uint32(getNumber(0,0,-1,"Enter X Size:",255,255,255,1)) % MAXIW);
                ih = max(1, Uint32(getNumber(0,0,-1,"Enter Y Size:",255,255,255,1)) % MAXIH);                
                cls();
            }               
            if(j == 7)
            {
                ix = Uint32(getNumber(0,0,-1,"Enter X Coordinate:",255,255,255,1)) % iw;
                iy = Uint32(getNumber(0,0,-1,"Enter Y Coordinate:",255,255,255,1)) % ih;                
                id = Uint8(getNumber(0,0,-1,"Enter Direction:",255,255,255,1)) % 4;
                cls();
            }    
            inkeys = SDL_GetKeyState(NULL);
            if(inkeys[SDLK_ESCAPE] && escapeRelease) {chosen = 1; escapeRelease = 0;}
            if(!inkeys[SDLK_ESCAPE]) escapeRelease = 1; 
            if(done()) end();              
        } 
    }    
    if(i == 5)
    {
        cls();
        chosen = 0;
        int j;
        while(!chosen)
        {
            print("Choose Debug Mode",0,0,255,255,255,1);
            print(" 0. No Debug Mode", 0, 8,255,255,255,1);
            print(" 1. Show Info At Redraw", 0, 16,255,255,255,1);
            print(" 2. Show Info Every Tick", 0, 24,255,255,255,1);
            print(" 3. Sleep Every Tick", 0, 32,255,255,255,1);
            print(" 4. Continue", 0, 40,255,255,255,1);
            redraw();
            j = numberKey();
            if(j > -1 && j < 4) {debugMode = j; chosen = 1;}
            if(j == 4) chosen = 1;
            readKeys();
            if(inkeys[SDLK_ESCAPE] && escapeRelease) {chosen = 1; escapeRelease = 0;}
            if(!inkeys[SDLK_ESCAPE]) escapeRelease = 1; 
            if(done()) end();              
        }    
        
    } 
    if(i == 6)
    {
        bool finished = 0;
        cls();
        chosen = 0;
        int commandEnterMode = 0;
        int j;
        while(!chosen)
        {
            print("How to enter commands?",0,0,255,255,255,1);
            print(" 0. Continue", 0, 8,255,255,255,1);
            print(" 1. Type Character", 0, 16,255,255,255,1);
            print(" 2. Type ASCII Value", 0, 24,255,255,255,1);
            redraw();
            j = numberKey();
            if(j == 0) {chosen = 1; commandEnterMode = 0;}
            if(j == 1) {chosen = 1; commandEnterMode = 1;}
            if(j == 2) {chosen = 1; commandEnterMode = 2;}
            readKeys();
            if(inkeys[SDLK_ESCAPE] && escapeRelease) {chosen = 1; escapeRelease = 0;}
            if(!inkeys[SDLK_ESCAPE]) escapeRelease = 1; 
            if(done()) end();              
        }        
        while(!finished && commandEnterMode > 0)
        {
            if(done()) end();
            readKeys();
            if(inkeys[SDLK_ESCAPE] && escapeRelease) {finished = 1; escapeRelease = 0;}
            if(!inkeys[SDLK_ESCAPE]) escapeRelease = 1; 
            Uint8 command;
            if(commandEnterMode == 1) command = Uint8(getChar(0, 0, -1, "Enter Command, E Ends:",255,255,255,1));
            if(commandEnterMode == 2) command = Uint8(getNumber(0, 0, -1, "Enter Command Number, 0 Ends:",255,255,255,1));
            if(command == 0) finished = 1;
            if(commandEnterMode == 1 && command == 'E') finished = 1;
            else if(command >= 32 && command < 128) executeCommand(command);          
        }   
        drawBuffer(screenBuffer);
        redraw();
    }
    if(i == 9)
    {
        cls();
        print("Gammaplex Programming Language and Interpreter v0.3. (c) 2004 Lode Vandevenne. See included manual or go to http://www.student.kuleuven.ac.be/~m0216922/gammaplex/gammaplex.html for more information.",0,0,255,255,255,1);
        redraw();
        sleep();
        cls();
    }           


    drawBuffer(screenBuffer);
    redraw();
}    

inline void changeDC(int digit)
{
    if(dc == 1) 
    {
        push(digit); 
        dc = 0;
    }
    else if(dc == 0) 
    {
        st[sp] *= 10;
        st[sp] += digit;
    }    
    else //dc = 0.1 - 0.000000...000001
    {
        st[sp] += dc * digit;
        dc /= 10.0;
    }    
} 

inline void moveIP()
{
    switch(id)
    {
        case 0: iy--; break;
        case 1: ix++; break;
        case 2: iy++; break;
        case 3: ix--; break;
    };    
    ix = (ix + iw) % iw;
    iy = (iy + ih) % ih;
}  

void printDebugInfo()
{
    print("ix:",0,0,255,255,0,1); iprint(ix,24,0,255,255,255,1);
    print("iy:",0,9,255,255,0,1); iprint(iy, 24, 8,255,255,255,1);
    print("id:",0,16,255,255,0,1); iprint(id, 24, 16, 255, 255, 255, 1);
    print("instr:",0,24,255,255,0,1); cprint(currentInstruction, 48, 24,255,255,255,1);
    print("im:",64,24,255,255,0,1); iprint(instructionMode,88,24,255,255,255,1);
    print("ticks:",0,32,255,255,0,1); iprint(ticks, 48, 32,255,255,255,1);
    print("dc:",0,40,255,255,0,1);fprint(dc, 4, 24, 40, 255, 255, 255, 1);
    fprint(sc[0%RA], 4, 0, 48, 255, 0, 0,1);
    fprint(sc[1%RA], 4, 0, 56, 255, 0, 0,1);
    fprint(sc[2%RA], 4, 0, 64, 255, 0, 0,1);
    fprint(sc[3%RA], 4, 0, 72, 255, 0, 0,1);
    fprint(sc[4%RA], 4, 0, 80, 255, 0, 0,1);
    fprint(sc[5%RA], 4, 0, 88, 255, 0, 0,1);
    fprint(sc[6%RA], 4, 0, 96, 255, 0, 0,1);
    fprint(sc[7%RA], 4, 0, 104, 255, 0, 0,1);
    fprint(sc[8%RA], 4, 0, 112, 255, 0, 0,1);
    fprint(sc[9%RA], 4, 0, 120, 255, 0, 0,1);
    fprint(sc[10%RA], 4, 0, 128, 255, 0, 0,1);
    fprint(sc[11%RA], 4, 0, 136, 255, 0, 0,1);
    fprint(sc[12%RA], 4, 0, 144, 255, 0, 0,1);
    fprint(st[(sp-0)%SA], 4, 0, 152, 0, 255, 0,1);
    fprint(st[(sp-1)%SA], 4, 0, 160, 0, 255, 0,1);
    fprint(st[(sp-2)%SA], 4, 0, 168, 0, 255, 0,1);
    fprint(st[(sp-3)%SA], 4, 0, 176, 0, 255, 0,1);
    fprint(st[(sp-4)%SA], 4, 0, 184, 0, 255, 0,1);
    fprint(st[(sp-5)%SA], 4, 0, 192, 0, 255, 0,1);
    fprint(st[(sp-6)%SA], 4, 0, 200, 0, 255, 0,1);
    fprint(st[(sp-7)%SA], 4, 0, 208, 0, 255, 0,1);
    fprint(st[(sp-8)%SA], 4, 0, 216, 0, 255, 0,1);
    fprint(st[(sp-9)%SA], 4, 0, 224, 0, 255, 0,1);
    fprint(st[(sp-10)%SA], 4, 0, 232, 0, 255, 0,1);
    fprint(st[(sp-11)%SA], 4, 0, 240, 0, 255, 0,1);
}    

inline void moveIPBack()
{
    switch(id)
    {
        case 0: iy++; break;
        case 1: ix--; break;
        case 2: iy--; break;
        case 3: ix++; break;
    };    
    ix = (ix + iw) % iw;
    iy = (iy + ih) % ih;
}     

void push(Scalar value)
{
    sp++;
    sp%=SA;
    st[sp] = value;
}

Scalar pop()
{
    Scalar value = st[sp];
    sp--;
    sp%=SA;
    return value;
}        

/*
GAMMAPLEX PROCESSOR
instruction[256][256]: the instruction, all chars (0-255)
ix, iy: x and y coordinate of instruction pointer
id: direction of instruction pointer: 0=N, 1=E, 2=S, 3=W
sc[65536]: 65536 scalars = the "super big register", first 8 = function parameters
st[65536]: stack, here all the math etc... happens
rp: register pointer
dc: decimal counter: is altijd 1, maar wordt *10 gedaan als command nummer is, of /10 als command nummer is en dc < 1
dc wordt weer op 1 gezet als command alles is behalve 0-9, ., /, \, ;, #, (space), @
--> dankzij dc kan je bijna intuitief nummers geven: bv 256.23 moet als 652.23 worden gegeven :D

functions like pset use the first scalars as parameter, sc[0] to sc[7] are reserved for those

*rp, *sp: the value that rp and sp point to

the first 5 scalars from the registers are called: x, y, r, g, b, radius, x2, y2

GAMMAPLEX COMMANDS (explanation in C/C++ style)

----setting and getting rp and sp (see also stack: that one is supposed to be used for it too)
u rp++
d rp--

----program flow
? if stack = true, jump 1 forward (normally), if false jump two forward, e.g.  use like this: ----> ?v^ (will go up or down depending on if it was true or false)
/ rotate id 90�
\ rotate id 90� 
^ set id to 0 
> set id to 1 
v set id to 2 
< set id to 3 
G goto(x, y), get x and y from register
g set pointer pos to register
@ start here (if none is there, starts at 0,0, if multiple: the last one it encounters), anders: NOP
(space) NOP, can be put between numbers and they'll still be added with same DC
# NOP, will set DC back to 1 though
; jump over next command
E end
e sleep
X eXtended command

----stack
( put *rp on stack
) get *rp from stack
[ put rp on stack
] get rp from stack
D delete current stack value
w duplicate current stack value (the w from double u ;))
W duplicate the last 2 stack values
Y duplicate the last s stack values below s (if s is 2, s x y becomes x y x y)
s swap s and s+1 (i.e. swap the highest two stack values) = rolldown s+1
S swap s and s+2
$ swap s and s+s //s+s means: s + the current stack value, current stack value immediatly popped and not used in the actual swap process
z rolldown s+2
Z rolldown s+s //s+s means: s + the current stack value, current stack value immediatly popped and not used in the actual swap process
{ set the first 8 scalars to the stack (you know, the ones that are parameters)
} get the first 8 scalars from the stack
a set position A to stack
A get position A from stack
b set position B to stack
B get position B from stack
k set the color parameters to stack
K get the color parameters from stack (the K van kolor ;))




----math (most operators happen on the stack and pop things out, push back in); s = huidige stack value
+ add
- sub
* mul
: div
~ pow
V sqrt
T cos (de T van Trigonometry)
p push pi
% mod
& AND
| OR
x XOR
! NOT (nonzero becomes zero, zero becomes 1)
_ make negative
" increment
' decrement
N set s to 0 (for n: see under "stack")
0 doet niets, behalve de dc wijzigen volgend de regel van dc: *10 als dc >= 1, /10 als dc < 1 (en dc wordt altijd 1 als commando niet 0-9 of . is)
1 s += dc        !!!!!!!!These numbers PUSH to the stack if dc = 1, and otherwise they modify the top value
2 s += 2 * dc
3 s += 3 * dc
4 s += 4 * dc
5 s += 5 * dc
6 s += 6 * dc
7 s += 7 * dc
8 s += 8 * dc
9 s += 9 * dc
. dc = 0.1
= are last two stack values equal?
, is the last stack value smaller than the previous one?
t push the time to the stack
n push 255 to the stack
(HINT: multiplying with 2 can be done with w+, dividing through 2 with 2:, adding 0 to stack is done with #0 or just 0 if no number was in front of the 0)

----graphical
l change screen width and height to x, y, 64x64, maximum 1600x1200
P pset(x, y, r, g, b) 
r putchar(x, y, r, g, b, bg), and increments x with 8, or even y with 8 and x back to 0 if side was reached, char value gotten from stack
C circle(x, y, r, g, b, radius)
F filled circle (x, y, r, g, b, radius)
L line(x, y, r, g, b, x2, y2)
O rectangle(x, y, r, g, b, x2, y2)
H hsvtorgb(r, g, b)
R redraw
c clear screen
h put screenheight - 1 on the stack
y put screenwidth -1 on the stack
i will print integer and put x coordinate to position after number like it coes with T too you know
f print floating point number
HINT: (setting color to black is simple with nnnK)


----input
I set stack to input key (input char) (will pause and ask for key to press)
J input number
M set x and y (sc[0] and sc[1]) to the mouse position
m set stack to left mouse button pressed and right mb

----self modifying code possibilities
q get instruction (stack x, y, pop)
Q set instruction (stack x, y, push)

----debugging
U toggle debug mode (debug mode = slow!), 3 modes: with and without "sleep"
*/

       


/*
GAMMAPLEX PROCESSOR
instruction[256][256]: the instruction, all chars (0-255)
ix, iy: x and y coordinate of instruction pointer
id: direction of instruction pointer: 0=N, 1=E, 2=S, 3=W
sc[65536]: 65536 scalars = the "super big register", first 8 = function parameters
st[65536]: stack, here all the math etc... happens
rp: register pointer
dc: decimal counter: is altijd 1, maar wordt *10 gedaan als command nummer is, of /10 als command nummer is en dc < 1
dc wordt weer op 1 gezet als command alles is behalve 0-9, ., /, \, ;, #, (space), @
--> dankzij dc kan je bijna intuitief nummers geven: bv 256.23 moet als 652.23 worden gegeven :D

functions like pset use the first scalars as parameter, sc[0] to sc[7] are reserved for those

*rp, *sp: the value that rp and sp point to

the first 5 scalars from the registers are called: x, y, r, g, b, radius, x2, y2

GAMMAPLEX COMMANDS (explanation in C/C++ style)

----setting and getting rp and sp (see also stack: that one is supposed to be used for it too)
u rp++
d rp--

----program flow
? if stack = true, jump 1 forward (normally), if false jump two forward, e.g.  use like this: ----> ?v^ (will go up or down depending on if it was true or false)
/ rotate id 90�
\ rotate id 90� 
^ set id to 0 
> set id to 1 
v set id to 2 
< set id to 3 
G goto(x, y), get x and y from register
g set pointer pos to register
@ start here (if none is there, starts at 0,0, if multiple: the last one it encounters), anders: NOP
(space) NOP, can be put between numbers and they'll still be added with same DC
# NOP, will set DC back to 1 though
; jump over next command
E end
e sleep
X eXtended command

----stack
( put *rp on stack
) get *rp from stack
[ put rp on stack
] get rp from stack
D delete current stack value
w duplicate current stack value (the w from double u ;))
W duplicate the last 2 stack values
Y duplicate the last s stack values below s (if s is 2, s x y becomes x y x y)
s swap s and s+1 (i.e. swap the highest two stack values) = rolldown s+1
S swap s and s+2
$ swap s and s+s //s+s means: s + the current stack value, current stack value immediatly popped and not used in the actual swap process
z rolldown s+2
Z rolldown s+s //s+s means: s + the current stack value, current stack value immediatly popped and not used in the actual swap process
{ set the first 8 scalars to the stack (you know, the ones that are parameters)
} get the first 8 scalars from the stack
a set position A to stack
A get position A from stack
b set position B to stack
B get position B from stack
k set the color parameters to stack
K get the color parameters from stack (the K van kolor ;))




----math (most operators happen on the stack and pop things out, push back in); s = huidige stack value
+ add
- sub
* mul
: div
~ pow
V sqrt
T cos (de T van Trigonometry)
p push pi
% mod
& AND
| OR
x XOR
! NOT (nonzero becomes zero, zero becomes 1)
_ make negative
" increment
' decrement
N set s to 0 (for n: see under "stack")
0 doet niets, behalve de dc wijzigen volgend de regel van dc: *10 als dc >= 1, /10 als dc < 1 (en dc wordt altijd 1 als commando niet 0-9 of . is)
1 s += dc        !!!!!!!!These numbers PUSH to the stack if dc = 1, and otherwise they modify the top value
2 s += 2 * dc
3 s += 3 * dc
4 s += 4 * dc
5 s += 5 * dc
6 s += 6 * dc
7 s += 7 * dc
8 s += 8 * dc
9 s += 9 * dc
. dc = 0.1
= are last two stack values equal?
, is the last stack value smaller than the previous one?
t push the time to the stack
n push 255 to the stack
(HINT: multiplying with 2 can be done with w+, dividing through 2 with 2:, adding 0 to stack is done with #0 or just 0 if no number was in front of the 0)

----graphical
l change screen width and height to x, y, 64x64, maximum 1600x1200
P pset(x, y, r, g, b) 
r putchar(x, y, r, g, b, bg), and increments x with 8, or even y with 8 and x back to 0 if side was reached, char value gotten from stack
C circle(x, y, r, g, b, radius)
F filled circle (x, y, r, g, b, radius)
L line(x, y, r, g, b, x2, y2)
O rectangle(x, y, r, g, b, x2, y2)
H hsvtorgb(r, g, b)
R redraw
c clear screen
h put screenheight - 1 on the stack
y put screenwidth -1 on the stack
i will print integer and put x coordinate to position after number like it coes with T too you know
f print floating point number
HINT: (setting color to black is simple with nnnK)


----input
I set stack to input key (input char) (will pause and ask for key to press)
J input number
M set x and y (sc[0] and sc[1]) to the mouse position
m set stack to left mouse button pressed and right mb

----self modifying code possibilities
q get instruction (stack x, y, pop)
Q set instruction (stack x, y, push)

----debugging
U toggle debug mode (debug mode = slow!), 3 modes: with and without "sleep"
*/

//GAMMADRAW

void GgetRGB(int c, Uint8& R, Uint8& G, Uint8& B)
{
    R = (c / 65536) % 256;
    G = (c / 256) % 256;
    B = c % 256;
} 

void GsetRGB(int& c, Uint8 R, Uint8 G, Uint8 B)
{
    c = B + 256 * G + 65536 * R;
}   

void Gpset(int x, int y, bool textBG)
{
    x = abs(x) % w;
    y = abs(y) % h;
    
    int style = abs(int(sc[12]));    
    Uint8 r = Uint8(sc[2]);
    Uint8 g = Uint8(sc[3]); 
    Uint8 b = Uint8(sc[4]);
        
    //skip the rest if no style
    if(style == 0) 
    {
        GsetRGB(screenBuffer[h * x + y], r, g, b);
        return;
    }    
    Uint8 r2 = Uint8(sc[8]);
    Uint8 g2 = Uint8(sc[9]);
    Uint8 b2 = Uint8(sc[10]);
    
    //pure text bg
    if(style == 4096)
    {
        GsetRGB(screenBuffer[h * x + y], r2, g2, b2);
        return;        
    }    
    
    Uint8 T = Uint8(sc[11]);
    Uint8 r3, g3, b3;
    GgetRGB(screenBuffer[h * x + y], r3, g3, b3);
    Uint8 R, G, B; //the final R, G and B
    
    //text background color: swap color1 and color2
    if(textBG)
    {
        r += r2; r2 = r - r2; r -= r2;
        g += g2; g2 = g - g2; g -= g2;
        b += b2; b2 = b - b2; b -= b2;
    }    
    
    //make underlying pixels negative (style &4)
    if(style & 4)
    {
        r3 = 255 - r3;
        g3 = 255 - g3;
        b3 = 255 - b3;
    }    

    //gradients 
    if((style & 1024) && !(style & 2048)) 
    {
        Uint8 xmod = 255 - Uint8(256.0 * (w - x) / Scalar(w));
        r = (r * (255 - xmod) + r2 * xmod) / 256;
        g = (g * (255 - xmod) + g2 * xmod) / 256;
        b = (b * (255 - xmod) + b2 * xmod) / 256;
    }  
    if((style & 2048) && !(style & 1024))
    {
        Uint8 ymod = 255 - Uint8(256.0 * (w - y) / Scalar(w));
        r = (r * (255 - ymod) + r2 * ymod) / 256;
        g = (g * (255 - ymod) + g2 * ymod) / 256;
        b = (b * (255 - ymod) + b2 * ymod) / 256;
    } 
    if((style & 1024) && (style & 2048))
    {
        Uint8 mod = 255 - Uint8(256.0 * (w + h - x - y) / Scalar(w + h));
        r = (r * (255 - mod) + r2 * mod) / 256;
        g = (g * (255 - mod) + g2 * mod) / 256;
        b = (b * (255 - mod) + b2 * mod) / 256;
    }
    R = r; G = g; B = b; //has to be done after gradient calculations
    
    //transparency and blending styles
    if((style & 1) && !(style & 2)) //transparency
    {
        R = (r * (256 - T) + r3 * T) / 256;
        G = (g * (256 - T) + g3 * T) / 256;
        B = (b * (256 - T) + b3 * T) / 256;
    }  
    if((style & 2) && !(style & 1)) //multiply blending
    {
        R = (r * r3) / 256;
        G = (g * g3) / 256;
        B = (b * b3) / 256;
        //do transparency after multiply blending
        R = (R * (255 - T) + r3 * T) / 256;
        G = (G * (255 - T) + g3 * T) / 256;
        B = (B * (255 - T) + b3 * T) / 256;
    }
    if((style & 2) && (style & 1)) //mysterious blending (darken / lighten)
    {
        int rmod = (r - 128) * 2;
        R = max(0, min(255, r3 + rmod));
        int gmod = (g - 128) * 2;
        G = max(0, min(255, g3 + gmod));
        int bmod = (b - 128) * 2;
        B = max(0, min(255, b3 + bmod));
        //do transparency after mysterious blending
        R = (R * (255 - T) + r3 * T) / 256;
        G = (G * (255 - T) + g3 * T) / 256;
        B = (B * (255 - T) + b3 * T) / 256;
    }   
    
    //do and dont draw     
    if((style & 8) && !(style & 16)) 
    {
        if(r2 == r3 && g2 == g3 && b2 == b3)
        R = r3;
        G = g3;
        B = b3;
    }  
    if((style & 16) && !(style & 8))
    {
        if(!(r2 == r3 && g2 == g3 && b2 == b3))
        R = r3;
        G = g3;
        B = b3;
    } 
    if((style & 8) && (style & 16))
    {
        if(r2 == r3 && g2 == g3 && b2 == b3)
        R = (R + r3) / 2;
        G = (G + g3) / 2;
        B = (B + b3) / 2;
    }
    
    //dot and line patterns
    bool invertPattern = style & 512;
    if(style & 32)
    {
        if(((x + y) % 2 == 0) ^ invertPattern)
        {
            R = r3;
            G = g3;
            B = b3;            
        }    
    }    
    if(style & 64)
    {
        if((x % 3 == 0 && y % 3 == 0) ^ invertPattern)
        {
            R = r3;
            G = g3;
            B = b3;            
        }    
    }    
    if(style & 128)
    {
        if((y % 2 == 0) ^ invertPattern)
        {
            R = r3;
            G = g3;
            B = b3;            
        }    
    }    
    if(style & 256)
    {
        if((x % 2 == 0) ^ invertPattern)
        {
            R = r3;
            G = g3;
            B = b3;            
        }    
    }   
                 
    GsetRGB(screenBuffer[h * x + y], R, G, B);  
} 



bool Gline(int x1, int y1, int x2, int y2)
{
    if(x1 < 0 || x1 > w - 1 || x2 < 0 || x2 > w - 1 || y1 < 0 || y1 > h - 1 || y2 < 0 || y2 > h - 1) return 0;
    
    int deltax = abs(x2 - x1);        // The difference between the x's
    int deltay = abs(y2 - y1);        // The difference between the y's
    int x = x1;                     // Start x off at the first pixel
    int y = y1;                     // Start y off at the first pixel
    int xinc1, xinc2, yinc1, yinc2, den, num, numadd, numpixels, curpixel;

    if (x2 >= x1)                 // The x-values are increasing
    {
        xinc1 = 1;
        xinc2 = 1;
    }
    else                          // The x-values are decreasing
    {
        xinc1 = -1;
        xinc2 = -1;
    }
    if (y2 >= y1)                 // The y-values are increasing
    {
        yinc1 = 1;
        yinc2 = 1;
    }
    else                          // The y-values are decreasing
    {
        yinc1 = -1;
        yinc2 = -1;
    }
    if (deltax >= deltay)         // There is at least one x-value for every y-value
    {
        xinc1 = 0;                  // Don't change the x when numerator >= denominator
        yinc2 = 0;                  // Don't change the y for every iteration
        den = deltax;
        num = deltax / 2;
        numadd = deltay;
        numpixels = deltax;         // There are more x-values than y-values
    }
    else                          // There is at least one y-value for every x-value
    {
        xinc2 = 0;                  // Don't change the x for every iteration
        yinc1 = 0;                  // Don't change the y when numerator >= denominator
        den = deltay;
        num = deltay / 2;
        numadd = deltax;
        numpixels = deltay;         // There are more y-values than x-values
    }
    for (curpixel = 0; curpixel <= numpixels; curpixel++)
    {
        Gpset(x, y);  // Draw the current pixel
        num += numadd;              // Increase the numerator by the top of the fraction
        if (num >= den)           // Check if numerator >= denominator
        {
            num -= den;             // Calculate the new numerator value
            x += xinc1;             // Change the x as appropriate
            y += yinc1;             // Change the y as appropriate
        }
        x += xinc2;                 // Change the x as appropriate
        y += yinc2;                 // Change the y as appropriate
    }
    
    return 1;
}   


bool Gcircle(int xc, int yc, int radius)
{
    if(xc - radius < 0 || xc + radius >= w || yc - radius < 0 || yc + radius >= h) return 0;
    int x = 0;
    int y = radius;
    int p = 3 - (radius << 1);
    int a, b, c, d, e, f, g, h;
    while (x <= y)
    {
         a = xc + x; //8 pixels can be calculated at once thanks to the symmetry
         b = yc + y;
         c = xc - x;
         d = yc - y;
         e = xc + y;
         f = yc + x;
         g = xc - y;
         h = yc - x;
         Gpset(a, b);
         Gpset(c, d);
         Gpset(e, f);
         Gpset(g, f);
         if(x>0) //avoid drawing pixels at same position for correct transparency
         {
             Gpset(a, d);
             Gpset(c, b);
             Gpset(e, h);
             Gpset(g, h);
         }
         if(p < 0) p += (x++ << 2) + 6;
         else p += ((x++ - y--) << 2) + 10;
  }
  
  return 1;
}

bool GhorLine(int y, int x1, int x2)
{
    if(x2 < x1) {x1 += x2; x2 = x1 - x2; x1 -= x2;} //swap x1 and x2, x1 must be the leftmost endpoint   
    if(x2 < 0 || x1 > w - 1 || y < 0 || y > h - 1) return 0; //no single point of the line is on screen
    
    if(x1 < 0) x1 = 0;
    if(x2 >= w) x2 = w - 1;
    
    for(int x = x1; x < x2; x++)
    {
        Gpset(x, y);
    }
}

//Filled bresenham circle with center at (xc,yc) with radius and red green blue color
bool Gdisk(int xc, int yc, int radius)
{
    if(xc + radius < 0 || xc - radius >= w || yc + radius < 0 || yc - radius >= h) return 0; //every single pixel outside screen, so don't waste time on it
    int x = 0;
    int y = radius;
    int p = 3 - (radius << 1);
    int a, b, c, d, e, f, g, h;
    int pb, pd; //previous values: to avoid drawing horizontal lines multiple times, screwing up the transparency
    while (x <= y)
    {
         // write data
         a = xc + x;
         b = yc + y;
         c = xc - x;
         d = yc - y;
         e = xc + y;
         f = yc + x;
         g = xc - y;
         h = yc - x;
         if(b != pb) GhorLine(b, a, c);
         if(d != pd) GhorLine(d, a, c);
         if(f != b) GhorLine(f, e, g);
         if(h != d && h != f) GhorLine(h, e, g);
         pb = b;
         pd = d;
         if(p < 0) p += (x++ << 2) + 6;
         else p += ((x++ - y--) << 2) + 10;
  }
  
  return 1;
}

void Gcls()
{
    for(int x = 0; x < w; x++)
    for(int y = 0; y < w; y++)
    {
        screenBuffer[h * x + y] = 0;
    }    
}  

bool Grect(int x1, int y1, int x2, int y2)
{
    if(x1 < 0 || x1 > w - 1 || x2 < 0 || x2 > w - 1 || y1 < 0 || y1 > h - 1 || y2 < 0 || y2 > h - 1) return 0;
    
    for(int x = x1; x < x2; x++)
    for(int y = y1; y < y2; y++)
    {
        Gpset(x, y);
    }
    
    return 1;
}  

static void inline GdrawLetter(unsigned char n, int x, int y)
{
    int u, v;

    for (v = 0; v < 8; v++)
    for (u = 0; u < 8; u++)
    {
        if(font[n][v][u]) Gpset(x + u, y + v);
        else if(int(sc[12]) & 4096) Gpset(x + u, y + v, 1);
    }
}

//Draws a string of text
int Gprint(char *text, int x, int y)
{
  int pos=0;
  while(text[pos])
  {
       GdrawLetter(text[pos++], x, y);
       x += 8;
       if(x > w - 8) {x %= 8; y += 8;}
       if(y > h - 8) {y %= 8;}
  }
  return pos;
}

//Draws an integer number
int Giprint(int a, int x, int y, bool orderSigns)
{
  char text[255];
  sprintf(text, "%i", a);
  int negationSymbol = 0;
  if(a >= 0 && orderSigns) negationSymbol = 8;
  return Gprint(text, x + negationSymbol, y);
}

//Draws a floating point number
int Gfprint(double a, int length, int x, int y, bool orderSigns)
{
  char text[255];
  switch(length)
  {
      case 1: sprintf(text, "%.1f", a); break;
      case 2: sprintf(text, "%.2f", a); break;
      case 3: sprintf(text, "%.3f", a); break;
      case 4: sprintf(text, "%.4f", a); break;
      case 5: sprintf(text, "%.5f", a); break;
      case 6: sprintf(text, "%.6f", a); break;
      case 7: sprintf(text, "%.7f", a); break;
      case 8: sprintf(text, "%.8f", a); break;
      case 9: sprintf(text, "%.9f", a); break;
      case 10: sprintf(text, "%.10f", a); break;
      case 11: sprintf(text, "%.11f", a); break;
      case 12: sprintf(text, "%.12f", a); break;
      case 13: sprintf(text, "%.13f", a); break;
      case 14: sprintf(text, "%.14f", a); break;
      case 15: sprintf(text, "%.15f", a); break;
      default: sprintf(text, "%.16g", a); break; 
  }    
  int negationSymbol = 0;
  if(a >= 0 && orderSigns) negationSymbol = 8;
  return Gprint(text, x + negationSymbol, y);
}

//Draws a single character (actually the same as drawletter)
int Gcprint(unsigned char n, int x, int y)
{
   GdrawLetter(n, x, y);
   return 1;
}
