/*
QuickCG

Copyright (c) 2004, Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

*) Redistributions of source code must retain the above copyright notice, this 
list of conditions and the following disclaimer.
*) Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef _quickcg_h_
#define _quickcg_h_

#include <SDL/SDL.h>

////////////////////////////////////////////////////////////////////////////////
//MIN, MAX and Scalar///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif
#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#endif

//define Scalar either as float or as double, at your choice
//for GAMMAPLEX, the esoteric programming language code, int is supported too!!!
#define Scalar double

////////////////////////////////////////////////////////////////////////////////
//GLOBAL VARIABLES//////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

extern SDL_Surface *scr; //the single SDL surface used
extern int w;
extern int h;
extern Uint8 *inkeys;

////////////////////////////////////////////////////////////////////////////////
//BASIC SCREEN FUNCTIONS////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void screen(int width = 640, int height = 400, bool fullscreen = 0, char *text = " ");
void lock();
void unlock();
void redraw();
void cls(Uint8 R = 0, Uint8 G = 0, Uint8 B = 0);
void pset(int x, int y, Uint8 r, Uint8 g, Uint8 b);
void drawBuffer(int *buffer);
bool onScreen(int x, int y);

////////////////////////////////////////////////////////////////////////////////
//NON GRAPHICAL FUNCTIONS///////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void sleep();
void waitFrame(float oldTime, float mspf);
bool done();
void end();
void readKeys();
void getMouseState(int & mouseX, int & mouseY);
void getMouseState(int & mouseX, int & mouseY, bool & LMB, bool & RMB);
float getTime();

////////////////////////////////////////////////////////////////////////////////
//2D SHAPES/////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

bool horLine(int y, int x1, int x2, int r, int g, int b);
bool verLine(int x, int y1, int y2, int r, int g, int b);
bool line(int x1, int y1, int x2, int y2, int r, int g, int b);
bool circle(int xc, int yc, int radius, int red, int green, int blue);
bool disk(int xc, int yc, int radius, int red, int green, int blue);
bool rect(int x1, int y1, int x2, int y2, int r, int g, int b);
bool clipLine(int x1,int y1,int x2,int y2, int* x3, int* y3, int* x4, int* y4);

////////////////////////////////////////////////////////////////////////////////
//COLOR CONVERSIONS/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void RGBtoHSL(Uint8 R, Uint8 G, Uint8 B, Uint8& H, Uint8& S, Uint8& L);
void HSLtoRGB(Uint8 H, Uint8 S, Uint8 L, Uint8& R, Uint8& G, Uint8& B);
void RGBtoHSV(Uint8 R, Uint8 G, Uint8 B, Uint8& H, Uint8& S, Uint8& V);
void HSVtoRGB(Uint8 H, Uint8 S, Uint8 V, Uint8& R, Uint8& G, Uint8& B);

////////////////////////////////////////////////////////////////////////////////
//BMP FUNCTIONS/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

int loadBMP(char *filename, Uint8 *image, int w, int h);
int loadBMP(char *filename, int *image, int w, int h);

////////////////////////////////////////////////////////////////////////////////
//TEXT FUNCTIONS////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
extern const bool font[256][8][8];
static void inline drawLetter(unsigned char n, int x, int y, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0);
int print(char *text, int x = 0, int y = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0);
int cprint(unsigned char n, int x = 0, int y = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0);
int iprint(int a, int x = 0, int y = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0, bool orderSigns = 0);
int fprint(double a, int length = 0, int x = 0, int y = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0, bool orderSigns = 0);
int numberKey();
Uint8 getChar(int x = 0, int y = 0, int message = 0, char * text = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0);
Scalar getNumber(int x = 0, int y = 0, int message = 0, char * text = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0);
void getString(char text[256], int x = 0, int y = 0, int message = 0, Uint8 r = 255, Uint8 g = 255, Uint8 b = 255, bool bg = 0, Uint8 r2 = 0, Uint8 g2 = 0, Uint8 b2 = 0);
////////////////////////////////////////////////////////////////////////////////
//GAMMAPLEX DINGES//////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#define MAXSCREENU 1600
#define MAXSCREENV 1200
extern int screenBuffer[MAXSCREENU * MAXSCREENV]; //will contain the pixels

#endif


