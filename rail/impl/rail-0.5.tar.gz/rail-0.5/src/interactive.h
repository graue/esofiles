// interactive.h

#ifndef INTERACTIVE_H_RAIL_1
#define INTERACTIVE_H_RAIL_1

class Thread;

void runInteractive(Thread & program);

#endif
