
g++ -o rail src/*.cpp

