/*
Lode's PNG Decoder v0.12 07/09/05

Copyright (c) 2005 Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of Lode Vandevenne nor the names of his contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/ 

#include <vector>
#include "png.h"
#include <iostream>

//generate code tree out of code lengths
void LOPNG_genCodetree(int* codetree, int* bitlen, int numcodes, int maxbitlen)
{
    //step 1: count number of instances of each code length
    int blcount[maxbitlen + 1]; //number of instances of each bit length (bitlencount)
    int nextcode[maxbitlen + 1]; //the numerical value of the smallest code for each code length
    for(int bits = 0; bits < maxbitlen; bits++) blcount[bits] = nextcode[bits] = 0; //initialize it to all 0 (important for step 2)
    for(int bits = 0; bits < numcodes; bits++) blcount[bitlen[bits]]++; //fill in the bit length counts
    
    //step 2: generate the nextcode values
    int code = 0;
    for(int bits = 1; bits <= maxbitlen; bits++)
    {
        code = (code + blcount[bits-1]) << 1;
        nextcode[bits] = code;
    }
    
    //step 3: generate all the codes
    int temptree[numcodes];
    for(int n = 0; n < numcodes; n++) if (bitlen[n] != 0) temptree[n] = nextcode[bitlen[n]]++;
    
    //step 4: convert temptree[] to codetree[][]
    for(int n = 0;  n < (numcodes - 1); n++) codetree[2 * n + 0] = codetree[2 * n + 1] = -1; //-1 means the codetree isn't filled there yet
    int nodefilled = 0; //up to which node it is filled
    int treepos = 0; //position in the tree
    
    for(int n = 0;  n < numcodes; n++)
    for(int i = 0; i < bitlen[n]; i++)
    {
        int bit = (temptree[n] >> (bitlen[n] - i - 1)) & 1;
        if(codetree[2 * treepos + bit] == -1)
        {
            if(i == bitlen[n] - 1)
            {
                codetree[2 * treepos + bit] = n; //put the current code in it
                treepos = 0;
            } 
            else //put address of the next step in here, first that address has to be found of course (it's just nodefilled + 1)...
            {
                nodefilled++;
                codetree[2 * treepos + bit] = nodefilled + numcodes; //adressen geencodeerd met NUMCODES erbij opgeteld!
                treepos = nodefilled;
            }
        }
        else treepos = codetree[2 * treepos + bit] - numcodes;
    }
}

//decode a single symbol from given list of bits with given code tree
int LOPNG_huffmanDecodeSymbol(int &out, unsigned char* in, int &bp, int* codetree, int numcodes, int inlength)
{
    int treepos = 0;
    out = -1;

    while(out < 0)
    {
        if(bp / 8 > inlength) return -10; //error: end of input memory reached without endcode
        int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
        if(codetree[2*treepos+bit] < numcodes) out = codetree[2*treepos+bit]; 
        else treepos = codetree[2*treepos+bit] - numcodes;
        if(treepos < 0 || treepos >= numcodes) return -11; //error: you appeared outside the codetree
    }

    return 0;
}

//get the tree of a deflate block with fixed tree, as specified in the deflate specification
int LOPNG_getTreeDeflateFixed(int* tree, int* treeD)
{
    int bitlen[288]; //288 possible codes: 0-255=literals, 256=endcode, 257-285=lengthcodes, 286-287=unused
    int bitlenD[32]; //there are 32 distance codes, but 30-31 are unused
    for(int i = 0; i <= 143; i++) bitlen[i] = 8;
    for(int i = 144; i <= 255; i++) bitlen[i] = 9;
    for(int i = 256; i <= 279; i++) bitlen[i] = 7;
    for(int i = 280; i <= 287; i++) bitlen[i] = 8;
    for(int i = 0; i < 32; i++) bitlenD[i] = 5;
    
    LOPNG_genCodetree(tree, bitlen, 288, 16);
    LOPNG_genCodetree(treeD, bitlenD, 32, 16);
    
    return 0;
}

//get the tree of a deflate block with dynamic tree,
int LOPNG_getTreeDeflateDynamic(int* tree, int* treeD, unsigned char* in, int &bp, int inlength)
{
    int pot; //power of two
    
    int HLIT = 257; //number of literal/length codes. Unlike the spec, the value 257 is added to it
    pot = 1;
    while(pot < 32)
    {
        int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
        HLIT += bit * pot;
        pot *= 2;
    }
    
    int HDIST = 1; //number of distance codes. Unlike the spec, the value 1 is added to it
    pot = 1;
    while(pot < 32)
    {
        int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
        HDIST += bit * pot;
        pot *= 2;
    }

    int HCLEN = 4; //number of code length codes. Unlike the spec, the value 4 is added to it
    pot = 1;
    while(pot < 16)
    {
        int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
        HCLEN += bit * pot;
        pot *= 2;
    }
    
    static int order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15}; //the order in which "code length alphabet code lengths" are stored (and that's not a typo)
    int codelengthcode[19];
    
    //read the code length codes out of 3 * (amount of code length codes) bits
    for(int i = 0; i < 19; i++)
    {
        codelengthcode[order[i]] = 0;
        if(i < HCLEN) //if not, it must stay 0
        {
            pot = 1;
            while(pot < 8)
            {
                int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
                codelengthcode[order[i]] += bit * pot;
                pot *= 2;
            }
        }
    }
    
    //turn the code lengths in the code length alphabet tree
    int codelengthcodetree[18][2];
    LOPNG_genCodetree(codelengthcodetree[0], codelengthcode, 19, 7);
    
    //now we can use this tree to read the lengths for the tree that this function will return
    
    int bitlen[288]; //288 possible codes: 0-255=literals, 256=endcode, 257-285=lengthcodes, 286-287=unused
    int bitlenD[32]; //er zijn 32 distance codes, maar 30-31 worden nooit gebruikt
    
    int i = 0;
    while(i < HLIT + HDIST) //i is the current symbol we're reading in the part that contains the code lengths of lit/len codes and dist codes
    {
        int code;
        
        int error = LOPNG_huffmanDecodeSymbol(code, in, bp, codelengthcodetree[0], 19, inlength);
        if(error < 0) return error; //some error happened in the above function
        
        if(code >= 0 && code <= 15) //a length code
        {
            if(i < HLIT) bitlen[i] = code;
            else bitlenD[i - HLIT] = code;
            i++;
        }
        else if(code == 16) //repeat previous
        {
            int replength = 3; //read in the 2 bits that indicate repeat length (3-6)
            pot = 1;
            while(pot < 4)
            {
                int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
                replength += bit * pot;
                pot *= 2;
            }
            int value; //set value to the previous code
            if((i - 1) < HLIT) value = bitlen[i - 1];
            else value = bitlenD[i - HLIT - 1];
            //repeat this value in the next lengths
            for(int n = 0; n < replength; n++)
            {
                if(i >= HLIT + HDIST) return -13; //error: i is larger than the amount of codes
                if(i < HLIT) bitlen[i] = value;
                else bitlenD[i - HLIT] = value;
                i++;
            }
        }
        else if(code == 17) //repeat "0" 3-10 times
        {
            int replength = 3; //read in the bits that indicate repeat length
            pot = 1;
            while(pot < 8)
            {
                int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
                replength += bit * pot;
                pot *= 2;
            }
            //repeat this value in the next lengths
            for(int n = 0; n < replength; n++)
            {
                if(i >= HLIT + HDIST) return -14; //error: i is larger than the amount of codes
                if(i < HLIT) bitlen[i] = 0;
                else bitlenD[i - HLIT] = 0;
                i++;
            }
        }
        else if(code == 18) //repeat "0" 11-138 times
        {
            int replength = 11; //read in the bits that indicate repeat length
            pot = 1;
            while(pot < 128)
            {
                int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
                replength += bit * pot;
                pot *= 2;
            }
            //repeat this value in the next lengths
            for(int n = 0; n < replength; n++)
            {
                if(i >= HLIT + HDIST) return -15; //error: i is larger than the amount of codes
                if(i < HLIT) bitlen[i] = 0;
                else bitlenD[i - HLIT] = 0;
                i++;
            }
        }
        else return -16; //error: somehow an unexisting code appeared. This can never happen.
    }
    
    //the other bitlen en bitlenD values must be 0, or a wrong tree will be generated
    for(int i = HLIT; i < 288; i++) bitlen[i] = 0;
    for(int i = HDIST; i < 32; i++) bitlenD[i] = 0;
    
    //now we've finally got HLIT and HDIST, so generate the code trees, and the function is done
    LOPNG_genCodetree(tree, bitlen, 288, 16);
    LOPNG_genCodetree(treeD, bitlenD, 32, 16);
    
    return 0;
}

//deflate a block with dynamic of fixed huffman tree
int LOPNG_deflateHuffmanBlock(unsigned char* out, unsigned char* in, int &bp, int &pos, int outlength, int inlength, int btype) 
{
    int codetree[287][2]; //the code tree for huffman codes
    int codetreeD[31][2]; //the code tree for distance codes
    
    if(btype == 2) LOPNG_getTreeDeflateFixed(codetree[0], codetreeD[0]);
    if(btype == 1)
    {
        int error = LOPNG_getTreeDeflateDynamic(codetree[0], codetreeD[0], in, bp, inlength);
        if(error < 0) return error;
    }

    int lengthbase[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
    int lengthextra[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
    int distancebase[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
    int distanceextra[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};
    
    bool endreached = false;
    while(!endreached)
    {
        int code;
        int error = LOPNG_huffmanDecodeSymbol(code, in, bp, codetree[0], 288, inlength);
        if(error < 0) return error; //some error happened in the above function
        
        if(code == 256) //end code
        {
            endreached = true;
        }
        else if(code >= 0 && code <= 255) //literal symbol
        {
            if(pos >= outlength) return -17; //error: end of out buffer memory reached
            out[pos] = code;
            pos++;
        }
        else if(code >= 257 && code <= 285) //length code
        {
            //part 1: get length base
            int length = lengthbase[code - 257];
            
            //part 2: get extra bits and add the value of that to length
            int numextrabits = lengthextra[code - 257];
            int pot = 1; //"pot" = power of two; dit is in de overtuiging dat de MSB eerst komt in de rij bits!
            while(pot < (1 << numextrabits))
            {
                int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
                length += pot * bit;
                pot *= 2;
            }
            
            //part 3: get distance code
            int codeD;
            error = LOPNG_huffmanDecodeSymbol(codeD, in, bp, codetreeD[0], 32, inlength);
            if(error < 0) return error;
            if(codeD < 0 || codeD > 29) return -18; //error: invalid distance code (30-31 are never used)
            int distance = distancebase[codeD];
            
            //part 4: get extra bits from distance
            int numextrabitsD = distanceextra[codeD];
            int potD = 1; //"pot" = power of two
            while(potD < (1 << numextrabitsD))
            {
                int bit = (in[bp / 8] >> (bp % 8)) & 1; bp++;
                distance += potD * bit;
                potD *= 2;
            }
            
            //part 5: fill in all the out[n] values based on the length and dist
            int start = pos;
            int backward = start - distance;
            for(int forward = 0; forward < length; forward++)
            {
                if(pos >= outlength) return -19; //error: end of out buffer memory reached
                out[pos] = out[backward];
                pos++;
                backward++;
                if(backward >= start) backward = start - distance;
            }
        }
    }
    return 0;
}

//deflate given data (see deflate spec)
int LOPNG_deflate(unsigned char* out, unsigned char* in, int inlength, int outlength)
{
    int bp = 0; //bit pointer in the "in" data, current byte is bp / 8, current bit is bp % 8 (from lsb to msb of the byte)
    //int bit;
    int BFINAL = 0;
    int pos = 0; //position in the out buffer
    
    while(!BFINAL)
    {
        BFINAL = (in[bp / 8] >> (bp % 8)) & 1; bp++;
        int BTYPE = 2 * ((in[bp / 8] >> (bp % 8)) & 1) + ((in[(bp + 1) / 8] >> ((bp + 1) % 8)) & 1); bp += 2;
        
        if(BTYPE == 3) return -20; //error: invalid BTYPE
        else if(BTYPE == 0) //no compression
        {
            //go to first boundary of byte
            while(bp % 8 != 0) bp++;
            
            //read LEN (2 bytes) and NLEN (2 bytes)
            int LEN = 256 * in[bp / 8] + in[bp / 8 + 8]; bp += 16;
            int NLEN = 256 * in[bp / 8] + in[bp / 8 + 8]; bp += 16;
            
            //check if NLEN is really the one's complement of LEN ("&" with 1111111111111111 because it's 16 bit ones complement)
            if( LEN & 65535 != ((~NLEN) & 65535) ) return -21; //error: NLEN is not one's complement of LEN
            
            //read the literal data: LEN bytes are now stored in the out buffer
            for(int n = 0; n < LEN; n++)
            {
                if(pos > outlength) return -22; //error! we're reading outside of out buffer!
                if(bp / 8 > inlength) return -23; //error! we're reading outside of in buffer!
                out[pos] = in[bp / 8]; bp += 8;
                pos++;
            }
        }
        else //compression, BTYPE 01 or 10
        {
            int error = LOPNG_deflateHuffmanBlock(out, in, bp, pos, outlength, inlength, BTYPE);
            if(error < 0) return error;
        }
    }
    return 0;
}

//decompress the zlib data of the png
int LOPNG_pngzlib(unsigned char* out, unsigned char* in, int outlength, int inlength)
{
    //read information from zlib header
    if((in[0] * 256 + in[1]) % 31 != 0) return -24; //error: 256 * in[0] + in[1] must be a multiple of 31, the FCHECK value is supposed to be made that way

    int CM = in[0] & 15;
    int CINFO = (in[0] >> 4) & 15;
    
    int FCHECK = in[1] & 31;
    int FDICT = (in[1] >> 5) & 1;
    int FLEVEL = (in[1] >> 6) & 3;
    
    int ADLER32 = 16777216 * in[inlength - 4] + 65536 * in[inlength - 3] + 256 * in[inlength - 2] + in[inlength - 1];
    
    if(CM != 8 || CINFO > 7) return -25; //error: only compression method 8: deflate with sliding window of 32k is supported
    if(FDICT != 0) return -26; //error: the specification of png sais about the zlib stream: "The additional flags shall not specify a preset dictionary."
    
    int error = LOPNG_deflate(out, &in[2], inlength - 2, outlength);
    if(error < 0) return error;

    return 0;
}

//read the information from the header
int LOPNG_readpngheader(unsigned char* in, int inlength, int &width, int &height, int &bitDepth, int &colorType, int &compressionMethod, int &filterMethod, int &interlaceMethod)
{
    if(inlength < 29) return -27; //error: the data length is smaller than the length of the header

    if(in[0] != 137 || in[1] != 80 || in[2] != 78 || in[3] != 71 || in[4] != 13 || in[5] != 10 || in[6] != 26 || in[7] != 10) return -28; //error: the first 8 bytes are not the correct png signature
    if(in[12] != 73 || in[13] != 72 || in[14] != 68 || in[15] != 82) return -29; //error: it doesn't start with a IHDR chunk!
    
    //read the values given in the header
    width = 256 * 256 * 256 * in[16] + 256 * 256 * in[17] + 256 * in[18] + in[19];
    height = 256 * 256 * 256 * in[20] + 256 * 256 * in[21] + 256 * in[22] + in[23];
    bitDepth = in[24];
    colorType = in[25];
    compressionMethod = in[26];
    filterMethod = in[27];
    interlaceMethod = in[28];
    //The 4 CRC bytes are ignored
    
    if(compressionMethod != 0) return -32; //only compression method 0 is allowed in the specification
    if(filterMethod != 0) return -33; //only filter method 0 is allowed in the specification
    if(interlaceMethod < 0 || interlaceMethod > 1) return -34; //only interlace methods 0 and 1 exist in the specification
    
    //check if bit depth is valid for this color type
    switch(colorType)
    {
        case 0: if(bitDepth != 1 && bitDepth != 2 && bitDepth != 4 && bitDepth != 8 && bitDepth != 16) return -37; break;
        case 2: if(bitDepth != 8 && bitDepth != 16) return -37; break;
        case 3: if(bitDepth != 1 && bitDepth != 2 && bitDepth != 4 && bitDepth != 8) return -37; break;
        case 4: if(bitDepth != 8 && bitDepth != 16) return -37; break;
        case 6: if(bitDepth != 8 && bitDepth != 16) return -37; break;
        default: return -31; break; //invalid color type
    }
    
    return 0;
}

//paeth predicter
int LOPNG_paethPredictor(int a, int b, int c)
{
    int Pr;
    int p = a + b - c;
    int pa = p - a; if(pa < 0) pa = -pa;
    int pb = p - b; if(pb < 0) pb = -pb;
    int pc = p - c; if(pc < 0) pc = -pc;
    if(pa <= pb && pa <= pc) Pr = a;
    else if(pb <= pc) Pr = b;
    else Pr = c;
    return Pr;
}

//filter a png image scanline by scanline
int LOPNG_pngfilter(unsigned char* recon, unsigned char* scanline, unsigned char* precon, bool top, int bytewidth, int filtertype, int length)
{
    unsigned char a, b, c, filtx;
    //when x is the current pixel, here are the positions of pixels a, b and c in the image:
    // c  b
    // a  x
    //when the pixels are smaller than 1 byte, the filter works byte per byte (bytewidth = 1)
    
    for(int i = 0; i < length; i++)
    {
        filtx = scanline[i];
        a = i < bytewidth ? 0 : recon[i - bytewidth];
        b = top ? 0 : precon[i];
        c = top ? 0 : i < bytewidth ? 0 : precon[i - bytewidth];

        switch(filtertype)
        {
            case 0: recon[i] = filtx; break;
            case 1: recon[i] = filtx + a; break;
            case 2: recon[i] = filtx + b; break;
            case 3: recon[i] = filtx + ((a + b) / 2); break;
            case 4: recon[i] = filtx + LOPNG_paethPredictor(a, b, c); break;
            default: return -36; break; //error: unexisting filter type given
        }
    }

    return 0;
}

//filter and reposition the pixels into the output when the image is Adam7 interlaced
int LOPNG_adam7pass(unsigned char* out, unsigned char* in, unsigned char* &scanlinen, unsigned char* &scanlineo, int w, int h, int bytewidth, int passleft, int passtop, int spacex, int spacey, int passw, int passh, int bpp)
{
    for(int s = 0; s < passh; s++)
    {
        int linelength = 1 + (bpp * passw + 7) / 8;
        int linestart = s * linelength; //position where we read the filtertype: at the start of the scanline
        int filtertype = in[linestart];
        
        int error = LOPNG_pngfilter(scanlinen, &in[linestart + 1], scanlineo, (s < 1), bytewidth, filtertype, (w * bpp + 7) / 8);
        if(error < 0) return error;
        
        //put the filtered pixels in the output image
        if(bpp >= 8)
        {
            for(int i = 0; i < passw; i++)
            for(int b = 0; b < bytewidth; b++) //b = current byte of this pixel
            {
                out[bytewidth * w * (passtop + spacey * s) + bytewidth * (passleft + spacex * i) + b] = scanlinen[bytewidth * i + b];
            }
        }
        else
        {
            for(int i = 0; i < passw; i++)
            {
                int outbitp = bpp * w * (passtop + spacey * s) + bpp * (passleft + spacex * i);
                for(int b = 0; b < bpp; b++) //b = current bit of this pixel
                {
                    int obp = outbitp + b;
                    int obitpos = 7 - (obp % 8); //where bitpos 0 refers to the LSB, bitpot 7 to the MSB of a byte
                    int bp = i * bpp + b;
                    int bitpos = 7 - (bp % 8); //where bitpos 0 refers to the LSB, bitpot 7 to the MSB of a byte
                    int bit = (scanlinen[bp / 8] >> bitpos) & 1;
                    out[obp / 8] = (out[obp / 8] & ~(1 << obitpos)) | (bit << obitpos);
                }
            }
        }

        //swap the two buffer pointers "scanline old" and "scanline new"
        unsigned char* temp = scanlinen;
        scanlinen = scanlineo;
        scanlineo = temp;
    }
    return 0;
}

//read a png, the result will be in the same color type as the PNG
int loadPNG(std::vector<unsigned char> &out, std::vector<unsigned char> in, std::vector<int> &info)
{

    int w; //width of the image
    int h; //height of the image
    int bitDepth; //bits per color channel
    int colorType; //color type used in this image
    int compressionMethod; //compression method must be 0
    int filterMethod; //filter method must be 0
    int interlaceMethod; //interlace method: 0 (none) or 1 (Adam7)

    int error = LOPNG_readpngheader(&in[0], in.size(), w, h, bitDepth, colorType, compressionMethod, filterMethod, interlaceMethod);
    if(error < 0) return error;

    int pos = 33; //first byte of the first chunk after the header
    int dataPos = 0; //at this position in the in buffer the new data will be stored.
    
    int paletteSize = 0;
    unsigned char* paletteValues = new unsigned char[1024];
    bool colorKey = 0; //for color type 0 or 2 a color key (transparent color) can be given in the tRNS chunk, if so, this is set to true
    int keyR = 0; //used for both greyscale color key, and red component of RGB color key, note: each sample is 2 bytes even if it's 1 byte per sample
    int keyG = 0;
    int keyB = 0;
    bool background = 0; //wheter or not there's a background color given in a bKGD chunk
    int bgR = 0; //also used as greyscale (colortype 0 or 4) or indexed background (colortype 3), the G and B then are not used
    int bgG = 0;
    int bgB = 0;
    
    //loop through the vareous chunks, ignoring unknown chunks and stopping at IEND chunk, and putting the IDAT data in the in buffer
    bool IEND = 0;

    while(!IEND)
    {
        //get chunk length
        if(pos + 8 >= in.size()) return -30; //error: size of the buffer too small!
        int chunkLength = 256 * 256 * 256 * in[pos] + 256 * 256 * in[pos + 1] + 256 * in[pos + 2] + in[pos + 3]; pos += 4;
        if(pos + chunkLength >= in.size()) return -35; //error: size of the buffer too small!

        //IDAT chunk, containing compressed image data
        if(in[pos + 0] == 'I' && in[pos + 1] == 'D' && in[pos + 2] == 'A' && in[pos + 3] == 'T')
        {
            pos += 4;
            for(int i = 0; i < chunkLength; i++) in[dataPos++] = in[pos++];
        }
        //IEND chunk
        else if(in[pos + 0] == 'I' && in[pos + 1] == 'E' && in[pos + 2] == 'N' && in[pos + 3] == 'D')
        {
            IEND = 1;
        }
        //palette chunk
        else if(in[pos + 0] == 'P' && in[pos + 1] == 'L' && in[pos + 2] == 'T' && in[pos + 3] == 'E')
        {
            pos += 4; //go after the 4 letters
            paletteSize = chunkLength / 3;
            if(paletteSize > 256) return -38; //error: palette too big
            for(int i = 0; i < paletteSize; i++)
            {
                paletteValues[i * 4 + 0] = in[pos++]; //R
                paletteValues[i * 4 + 1] = in[pos++]; //G
                paletteValues[i * 4 + 2] = in[pos++]; //B
                paletteValues[i * 4 + 3] = 255; //alpha
            }
        }
        //palette transparency chunk
        else if(in[pos + 0] == 't' && in[pos + 1] == 'R' && in[pos + 2] == 'N' && in[pos + 3] == 'S')
        {
            pos += 4; //go after the 4 letters
            if(colorType == 3)
            {
                if(chunkLength > paletteSize) return -39; //error: more alpha values given than there are palette entries
                for(int i = 0; i < chunkLength; i++) paletteValues[i * 4 + 3] = in[pos++];
            }
            else if(colorType == 0)
            {
                if(chunkLength != 2) return -40; //error: this chunk must be 2 bytes for greyscale image
                colorKey = 1;
                keyR = 256 * in[pos] + in[pos + 1]; pos += 2;
            }
            else if(colorType == 2)
            {
                if(chunkLength != 6) return -41; //error: this chunk must be 6 bytes for RGB image
                colorKey = 1;
                keyR = 256 * in[pos] + in[pos + 1]; pos += 2;
                keyG = 256 * in[pos] + in[pos + 1]; pos += 2;
                keyB = 256 * in[pos] + in[pos + 1]; pos += 2;
            }
            else return -42; //error: tRNS chunk not allowed for other color models
        }
        //background color chunk
        else if(in[pos + 0] == 'b' && in[pos + 1] == 'K' && in[pos + 2] == 'G' && in[pos + 3] == 'D')
        {
            pos += 4; //go after the 4 letters
            if(colorType == 3)
            {
                if(chunkLength != 1) return -43; //error: this chunk must be 1 byte for indexed color image
                background = 1;
                bgR = in[pos++];
            }
            else if(colorType == 0 || colorType == 4)
            {
                if(chunkLength != 2) return -44; //error: this chunk must be 2 bytes for greyscale image
                background = 1;
                bgR = 256 * in[pos] + in[pos + 1]; pos += 2;
            }
            else if(colorType == 2 || colorType == 6)
            {
                if(chunkLength != 6) return -45; //error: this chunk must be 6 bytes for greyscale image
                background = 1;
                bgR = 256 * in[pos] + in[pos + 1]; pos += 2;
                bgG = 256 * in[pos] + in[pos + 1]; pos += 2;
                bgB = 256 * in[pos] + in[pos + 1]; pos += 2;
            }
        }
        else //it's not an idat and not an iend chunk, so ignore it: skip over the data and the CRC
        {
            pos += 4; //skip the 4 letters
            pos += chunkLength; //skip unknown data of unknown chunk
        }
        pos += 4; //skip CRC
    }
    int bpp = 0; //bits per pixel
    int colorChannels = 0; //numbers of channels (e.g. RGBA has 4 channels, indexed color has 1 channel)
    switch(colorType)
    {
        case 0: bpp = bitDepth; colorChannels = 1; break; //grey
        case 2: bpp = bitDepth * 3; colorChannels = 3; break; //RGB
        case 3: bpp = bitDepth; colorChannels = 1; break; //palette
        case 4: bpp = bitDepth * 2; colorChannels = 2; break; //grey + alpha
        case 6: bpp = bitDepth * 4; colorChannels = 4; break; //RGBA
        default: break; //can never happen since colorType is always one of the above
    }

    //now we can allocate info, because we know the size of the palette
    info.clear();
    info.resize(18 + paletteSize * 4);
    info[0] = w;
    info[1] = h;
    info[2] = bitDepth;
    info[3] = colorType;
    info[4] = bpp;
    info[5] = colorChannels;
    info[6] = compressionMethod;
    info[7] = filterMethod;
    info[8] = interlaceMethod;
    info[9] = colorKey;
    info[10] = keyR;
    info[11] = keyG;
    info[12] = keyB;
    info[13] = background;
    info[14] = bgR;
    info[15] = bgG;
    info[16] = bgB;
    info[17] = paletteSize;
    
    for(int i = 0; i < paletteSize * 4; i++) info[18 + i] = paletteValues[i];
    
    delete[] paletteValues;
    
    int scanlength = (w * (h * bpp + 7) / 8) + h * 8; //scanline buffer length is larger than final image size because up to h * 7 filter type codes can still be in it!
    unsigned char* scanlines = new unsigned char[scanlength]; //now the out buffer will be filled
    
    //decompress the data
    error = LOPNG_pngzlib(scanlines, &in[0], scanlength, dataPos); //dataPos is given as in.size(): size of the new data in the in buffer
    if(error < 0) return error;
    
    //filter and interlace
    
    int bytewidth = (bpp + 7) / 8; //bytewidth is used for filtering
    int outlength = (h * w * bpp + 7) / 8;
    
    out.clear();
    out.resize(outlength); //time to fill the out buffer

    if(interlaceMethod == 0)
    {
        unsigned char* templine = new unsigned char[(w * bpp + 7) / 8]; //only used of bpp < 8
        int linestart = 0; //start of current scanline
        int obp = 0; //out bit pointer, only used if bpp < 8
        for(int s = 0; s < h; s++)
        {
            int filtertype = scanlines[linestart];
            if(bpp >= 8) //byte per byte
            {
                error = LOPNG_pngfilter(&out[linestart - s], &scanlines[linestart + 1], &out[(s - 1) * w * bytewidth], (s < 1), bytewidth, filtertype,  (w * bpp + 7) / 8);
                if(error < 0) return error;
            }
            else //less than 8 bits per pixel, so fill it up bit per bit
            {
                error = LOPNG_pngfilter(templine, &scanlines[linestart + 1], &out[(s - 1) * w * bytewidth], (s < 1), bytewidth, filtertype,  (w * bpp + 7) / 8);
                if(error < 0) return error;

                for(int bp = 0; bp < w * bpp; bp++) //bp is here bit pointer in templine
                {
                    int obitpos = 7 - (obp % 8);
                    int bitpos = 7 - (bp % 8);
                    int bit = (templine[bp / 8] >> bitpos) & 1;
                    out[obp / 8] = (out[obp / 8] & ~(1 << obitpos)) | (bit << obitpos); //set current bit
                    obp++;
                }
            }
            linestart += 1 + (w * bpp + 7) / 8; //go to start of next scanline
        }
        delete[] templine;
    }
    else //interlaceMethod is 1 (Adam7)
    {
        int pass1w = (w + 7) / 8, pass1h = (h + 7) / 8;
        int pass2w = (w + 3) / 8, pass2h = (h + 7) / 8;
        int pass3w = (w + 3) / 4, pass3h = (h + 3) / 8;
        int pass4w = (w + 1) / 4, pass4h = (h + 3) / 4;
        int pass5w = (w + 1) / 2, pass5h = (h + 1) / 4;
        int pass6w = (w + 0) / 2, pass6h = (h + 1) / 2;
        int pass7w = (w + 0) / 1, pass7h = (h + 0) / 2;
        
        int pass1start = 0;
        int pass2start = pass1h * ((pass1w * bpp + 7) / 8) + pass1h;
        int pass3start = pass2start + pass2h * ((pass2w * bpp + 7) / 8) + pass2h;
        int pass4start = pass3start + pass3h * ((pass3w * bpp + 7) / 8) + pass3h;
        int pass5start = pass4start + pass4h * ((pass4w * bpp + 7) / 8) + pass4h;
        int pass6start = pass5start + pass5h * ((pass5w * bpp + 7) / 8) + pass5h;
        int pass7start = pass6start + pass6h * ((pass6w * bpp + 7) / 8) + pass6h;
        
        unsigned char* scanlineo = new unsigned char[w * bpp]; //"old" scanline
        unsigned char* scanlinen = new unsigned char[w * bpp]; //"new" scanline
        
        LOPNG_adam7pass(&out[0], &scanlines[pass1start], scanlinen, scanlineo, w, h, bytewidth, 0, 0, 8, 8, pass1w, pass1h, bpp);
        LOPNG_adam7pass(&out[0], &scanlines[pass2start], scanlinen, scanlineo, w, h, bytewidth, 4, 0, 8, 8, pass2w, pass2h, bpp);
        LOPNG_adam7pass(&out[0], &scanlines[pass3start], scanlinen, scanlineo, w, h, bytewidth, 0, 4, 4, 8, pass3w, pass3h, bpp);
        LOPNG_adam7pass(&out[0], &scanlines[pass4start], scanlinen, scanlineo, w, h, bytewidth, 2, 0, 4, 4, pass4w, pass4h, bpp);
        LOPNG_adam7pass(&out[0], &scanlines[pass5start], scanlinen, scanlineo, w, h, bytewidth, 0, 2, 2, 4, pass5w, pass5h, bpp);
        LOPNG_adam7pass(&out[0], &scanlines[pass6start], scanlinen, scanlineo, w, h, bytewidth, 1, 0, 2, 2, pass6w, pass6h, bpp);
        LOPNG_adam7pass(&out[0], &scanlines[pass7start], scanlinen, scanlineo, w, h, bytewidth, 0, 1, 1, 2, pass7w, pass7h, bpp);
        
        delete[] scanlineo;
        delete[] scanlinen;
    }

    return 0;
}

//read a PNG, the result will always be in 8-bit RGBA color, no matter what color type the PNG image had
int loadPNG32(std::vector<unsigned char> &out, std::vector<unsigned char> in, std::vector<int> &info)
{
    std::vector<unsigned char> buffer;
    buffer.clear();

    int error = loadPNG(buffer, in, info);
    if(error < 0) return error;

    int w = info[0];
    int h = info[1];
    int bitDepth = info[2];
    int colorType = info[3];
    int colorKey = info[9];
    int keyR = info[10];
    int keyG = info[11];
    int keyB = info[12];
    int paletteSize = info[17];
    
    out.clear();

    out.resize(w * h * 4);

    for(int i = 0; i < w * h; i++)
    {
        out[4 * i + 3] = 255;
        switch(colorType)
        {
            case 0: //greyscale color
                if(bitDepth == 8)
                {
                    out[4 * i + 0] = out[4 * i + 1] = out[4 * i + 2] = buffer[i];
                    if(colorKey == 1)
                    if(buffer[i] == keyR) out[4 * i + 3] = 0;
                }
                else if(bitDepth == 16)
                {
                    out[4 * i + 0] = out[4 * i + 1] = out[4 * i + 2] = buffer[2 * i + 1];
                    if(colorKey == 1)
                    if(256 * buffer[i] + buffer[i + 1] == keyR) out[4 * i + 3] = 0;
                }
                else
                {
                    int bp = bitDepth * i;
                    int value = 0;
                    int pot = 1 << bitDepth; //power of two
                    for(int j = 0; j < bitDepth; j++) 
                    {
                        pot /= 2;
                        int bit = (buffer[bp / 8] >> (7 - (bp % 8))) & 1;
                        value += pot * bit;
                        bp++;
                    }
                    if(colorKey == 1)
                    if(value && ((1 << bitDepth) - 1) == keyR && ((1 << bitDepth) - 1)) out[4 * i + 3] = 0;
                    value = (value * 255) / ((1 << bitDepth) - 1); //scale value from 0 to 255
                    out[4 * i + 0] = out[4 * i + 1] = out[4 * i + 2] = value;
                }
                break;
            case 2: //RGB color
                if(bitDepth == 8)
                {
                    for(int c = 0; c < 3; c++) out[4 * i + c] = buffer[3 * i + c];
                    if(colorKey == 1)
                    if(buffer[3 * i + 0] == keyR && buffer[3 * i + 1] == keyG && buffer[3 * i + 2] == keyB) out[4 * i + 3] = 0;
                }
                else if(bitDepth == 16)
                {
                    for(int c = 0; c < 4; c++) out[4 * i + c] = buffer[6 * i + 1 + 2 * c];
                    if(colorKey == 1)
                    if(256 * buffer[6 * i + 0] + buffer[6 * i + 1] == keyR
                    && 256 * buffer[6 * i + 2] + buffer[6 * i + 3] == keyG
                    && 256 * buffer[6 * i + 4] + buffer[6 * i + 5] == keyB) out[4 * i + 3] = 0;
                }
                break;
            case 3: //indexed color (palette)
                if(bitDepth == 8)
                {
                    int value = buffer[i];
                    if(value >= paletteSize) return -46;
                    for(int c = 0; c < 4; c++) out[4 * i + c] = info[18 + c + 4 * value]; //get rgb colors from the palette, which is stored in info
                }
                else if(bitDepth < 8)
                {
                    int bp = bitDepth * i;
                    int value = 0;
                    int pot = 1 << bitDepth; //power of two
                    for(int j = 0; j < bitDepth; j++) 
                    {
                        pot /= 2;
                        int bit = (buffer[bp / 8] >> (7 - (bp % 8))) & 1;
                        value += pot * bit;
                        bp++;
                    }
                    if(value >= paletteSize) return -47;
                    for(int c = 0; c < 4; c++) out[4 * i + c] = info[18 + c + 4 * value]; //get rgb colors from the palette, which is stored in info
                }
                break;
            case 4: //greyscale with alpha
                if(bitDepth == 8)
                {
                    out[4 * i + 0] = out[4 * i + 1] = out[4 * i + 2] = buffer[i * 2 + 0];
                    out[4 * i + 3] = buffer[i * 2 + 1];
                }
                else if(bitDepth == 16)
                {
                    out[4 * i + 0] = out[4 * i + 1] = out[4 * i + 2] = buffer[i * 4 + 1];
                    out[4 * i + 3] = buffer[i * 4 + 3];
                }
                break;
            case 6: //RGB with alpha
                if(bitDepth == 8) for(int c = 0; c < 4; c++) out[4 * i + c] = buffer[4 * i + c];
                else if(bitDepth == 16) for(int c = 0; c < 4; c++) out[4 * i + c] = buffer[8 * i + 1 + 2 * c];
                break;
            default: break;
        }
    }
    return 0;
}
