/*
Lode's PNG Decoder v0.12 07/09/05

Copyright (c) 2005 Lode Vandevenne
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of Lode Vandevenne nor the names of his contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/ 

#ifndef PNG_H
#define PNG_H

#include <vector>

int loadPNG(std::vector<unsigned char> &out, std::vector<unsigned char> in, std::vector<int> &info);
int loadPNG32(std::vector<unsigned char> &out, std::vector<unsigned char> in, std::vector<int> &info);

#endif

/*
Documentation:
--------------

Lode's PNG Decoder is a png decoder according to the Portable Network Graphics (PNG) Specification (Second Edition) - W3C Recommendation 10 November 2003. The specification can be found online at http://www.w3.org/TR/2003/REC-PNG-20031110

PNG is a file format to store raster images losslessly with good compression, supporting different color types, and patent-free.

Unlike other png decoders, this png decoder exists only out of a single .cpp file and this .h file. The .cpp file has no external dependencies, is shorter than 900 lines of standard C++ code and does all that is needed to decompress a .png image. You only have to use one of the 2 functions included in this header, and there are no weird datatypes involved.

Because this software is BSD licenced, you're allowed to use these source files in your project, as long as you include some credits to me and the above copyright message somewhere in the release of your program. You're not required to dynamically link to this png decoder and your software doesn't have to be open source.

The intended use of this software is for games that want to load textures, sprites or tilesets from png files, and for simple programs that want to read png images without linking to external libraries.

This png decoder is also educational: if you read the functions in the right order, the code shows step by step how a png file is built up, how the zlib decompression works, what data elements there are in the headers, and so on.

The following features of png are supported:
-decoding pngs with any color type and bit depth
-decoding of Adam7 interlaced pngs
-reading the suggested background color if one is included
-full support for translucent png's, including translucent palettes and color keys
-zlib decompression
-the following chunks are interpreted:
--IHDR
--PLTE
--IDAT
--IEND
--tRNS
--bKGD

The following features of png are *not* supported
-creating, saving or editing a png
-CRC checks of chunks: they are ignored
-ADLER32 checksum of zlib data: it's ignored
-the following chunk types are ignored:
--cHRM
--gAMA
--iCCP
--sBIT
--sRGB
--tEXt
--zTXt
--iTXt
--hIST
--pHYs
--sPLT
--tIME

This png decoder is very easy to use. Use a .png file from your harddisk as texture in your game in 4 steps:

step 1: load the png image from harddisk using your own load-file-from-harddisk code and store the contents of the file in an unsigned char* buffer with the same length as the file
step 2: declare the std::vectors that will contain the image data and the info
step 3: call the loadPNG or the loadPNG32 function with the above buffers as the parameters
step 4: the uncompressed image data in the out vector can now easily be used to create an OpenGL texture, to blit to the screen, to get color values of arbitrary pixels, and so on


functions:
----------

int loadPNG(std::vector<unsigned char> &out, unsigned char* in, std::vector<int> &info, int inlength):

  -This function converts the given compressed png data into uncompressed image data.
  -Return value: 0 if everything went ok, a negative value if an error happened. See below for error codes.
  -Parameters:
  --out: the uncompressed image data will be stored in this std::vector buffer. A buffer of the correct size will be generated inside the function. The image data will be of the same color type as the png image. 1-bit images will be stored bit per bit, scanlines don't necessarily start at the boundary of a byte.
  --in: the contents of a png file, as unsigned char buffer. This buffer will be overwritten with intermediate data.
  --info: in this std::vector integer buffer, information about the png and, if it has one, the palette will be stored. See below for the contents of this buffer.
  --inlength: the size of the in buffer, this is the filesize of the png file.

int loadPNG32(std::vector<unsigned char> &out, unsigned char* in, std::vector<int> &info, int inlength):

  -This function does the same as loadPNG, but the resulting image will always in RGBA form with 32 bits per pixel.
  -Return value: 0 if everything went ok, a negative value if an error happened. See below for error codes.
  -Parameters:
  --out: the uncompressed image data will be stored in this std::vector buffer. A buffer of the correct size will be generated inside the function. The image data will be in RGBA form with 32 bits per pixel, and the size of the buffer in bytes will be 4 * width * height of the image. Pixels are stored starting with the top scanline, starting with the left pixel of it.
  --in: the contents of a png file, as unsigned char buffer. This buffer will be overwritten with intermediate data.
  --info: in this std::vector integer buffer, information about the png and, if it has one, the palette will be stored. See below for the contents of this buffer.
  --inlength: the size of the in buffer, this is the filesize of the png file.


info[] values:
--------------

The size of the info buffer will be 18 + 4 * paletteSize.

-info[0]: width of the image in pixels
-info[1]: height of the image in pixels
-info[2]: bit depth: for indexed-colour images, the number of bits per palette index. For other images, the number of bits per sample in the image.
-info[3]: color type: 0 = greyscale, 2 = RGB, 3 = indexed color (palette), 4 = greyscale with alpha, 6 = RGBA
-info[4]: bpp: bits per pixel
-info[5]: color channels: amount of color channels, for example RGBA has 4 color channels
-info[6]: compression method, always 0
-info[7]: filter method, always 0
-info[8]: interlace method: 0 = no interlace, 1 = Adam7 interlace
-info[9]: color key enabled: 0 if there's no color key, 1 if there's a color key. A color key is a color that will be drawn invisible, and can only appear if the png image has no alpha channel.
-info[10]: the red component of the color key, or the color key value if the image is greyscale.
-info[11]: the green component of the color key
-info[12]: the blue component of the color key
-info[13]: background color enabled: 0 if there's no background color given, 1 if a background color is given.
-info[14]: the red component of the background color, or the value of the background color for greyscale or indexed color images.
-info[15]: the green component of the background color
-info[16]: the blue component of the background color
-info[17]: paletteSize: 0 if there's no palette, a value from 2 to 256 if there's a palette.

-info[18]: red component of palette color 0
-info[19]: green component of palette color 0 
-info[20]: blue component of palette color 0
-info[21]: alpha component of palette color 0
-info[18]: red component of palette color 1
-info[19]: green component of palette color 1
-info[20]: blue component of palette color 1
-info[21]: alpha component of palette color 1
-etc...


errors:
-------

All errors are negative values

-10: while huffman decoding: end of input memory reached without endcode
-11: while huffman decoding: error in code tree made it jump outside of tree
-12:
-13: while processing dynamic deflate block
-14: while processing dynamic deflate block
-15: while processing dynamic deflate block
-16: unexisting code while processing dynamic deflate block
-17: while deflating: end of out buffer memory reached
-18: while deflating: invalid distance code
-19: while deflating: end of out buffer memory reached
-20: invalid deflate block BTYPE encountered
-21: NLEN is not one's complement of LEN in a deflate block
-22: while deflating: end of out buffer memory reached
-23: while deflating: end of in buffer memory reached
-24: invalid FCHECK in zlib header
-25: invalid compression method in zlib header
-26: FDICT encountered in zlib header while it's not used for png
-27: png file is smaller than a png header
-28: incorrect png signature (the first 8 bytes of the png file)
-29: first chunk is not the header chunk
-30: chunk length too large, chunk broken off at end of file
-31: illegal png color type
-32: illegal png compression method
-33: illegal png filter method
-34: illegal png interlace method
-35: chunk length of a chunk is too large or the chunk too small
-36: illegal png filter type encountered
-37: illigal bit depth for this color type given
-38: the palette is too big (more than 256 colors)
-39: more palette alpha values given in tRNS, than there are colors in the palette
-40: tRNS chunk has wrong size for greyscale image
-41: tRNS chunk has wrong size for RGB image
-42: tRNS chunk appeared while it was not allowed for this color type
-43: bKGD chunk has wrong size for palette image
-44: bKGD chunk has wrong size for greyscale image
-45: bKGD chunk has wrong size for RGB image
-46: value encountered in indexed image is larger than the palette size (bitdepth == 8)
-47: value encountered in indexed image is larger than the palette size (bitdepth < 8)


Copyright (c) 2005 Lode Vandevenne
*/


