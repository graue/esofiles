//Compiles with "g++ *.cpp", manual at bottom

/*
Copyright (c) 2005 by Lode Vandevenne.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of Lode Vandevenne nor the names of his contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "png.h"

#include <vector>

#include <iostream>
#include <fstream>

using namespace std;

//returns the size of the file
int getFilesize(const char * filename)
{
    basic_ifstream<unsigned char> file(filename, ios::in|ios::binary|ios::ate);
    
    //get filesize
    file.seekg(0, ios::end);
    int size = file.tellg();
    file.seekg(0, ios::beg);
    size -= file.tellg();
    
    file.close();
    
    return size;    
}

//write given buffer to the file, overwriting the file, it doesn't append to it.
void writeFile(const char * filename, std::vector<unsigned char> &buffer)
{
    ofstream file(filename, ios::out|ios::binary);
    file.write((char*)(&buffer[0]), buffer.size());
    file.close();
}


//Read given file and store into given buffer. Returns filesize if OK, or 0 if the file doesn't exist
int readFile(const char * filename, std::vector<unsigned char> &buffer)
{
    buffer.clear();
    int size = getFilesize(filename);
    buffer.resize(size);
    
    ifstream file(filename, ios::in|ios::binary|ios::ate);
    //read the file into the buffer    
    file.seekg(0, ios::beg);
    file.read((char*)(&buffer[0]), size);
    file.close();
    return size;
}

void moveIP(int &ipx, int &ipy, int dir)
{
    switch(dir)
    {
        case 0: ipx++; break;
        case 1: ipy++; break;
        case 2: ipx--; break;
        case 3: ipy--; break;
    }
}

void moveIPBack(int &ipx, int &ipy, int dir)
{
    switch(dir)
    {
        case 0: ipx--; break;
        case 1: ipy--; break;
        case 2: ipx++; break;
        case 3: ipy++; break;
    }
}

int wrapmod(int i, int n) //wraps i between 0 and n, using the modulo operator
{
    if(i >= n) i = i % n;
    if(i < 0) i = (n - ((-i) % n)); //modulo division on negative values
    
    return i;
}

void moveIP(int &ipx, int &ipy, int dir, int times)
{
    switch(dir)
    {
        case 0: ipx += times; break;
        case 1: ipy += times; break;
        case 2: ipx -= times; break;
        case 3: ipy -= times; break;
    }
}

//rotate IP to the right
void rotright(int &dir)
{
    dir++;
    if(dir > 3) dir = 0;
}

//rotate IP to the left
void rotleft(int &dir)
{
    dir--;
    if(dir < 0) dir = 3;
}

int pop(std::vector<int> &stack)
{
    if(stack.size() <= 0) return 0;
    int i = stack[stack.size() - 1];
    stack.pop_back();
    return i;
}

int main(int argc, char *argv[]) 
{
    //read the file

    if(!argv[1])
    {
        cout << "please specify a file\n";
        return 0;
    }

    
    std::vector<unsigned char> buffer;
    std::vector<int> info; //will contain the information
    std::vector<unsigned char> image;
    
    readFile(argv[1], buffer);

    int error = loadPNG32(image, buffer, info);
    if(error < 0)
    {
        cout << "png decoder sais: error " << error << "\n";
        return -1;
    }
    
    int w = info[0]; //width of the code
    int h = info[1]; //height of the code
    
    //convert the image code into intermediate code
    
    std::vector<unsigned char> code; //the converted code
    code.resize(w * h, 0);
    std::vector<int> jumpv[4]; //value belonging to this code (one for each direction)
    std::vector<int> jumpx[4]; //other x position belonging to this code (one for each direction)
    std::vector<int> jumpy[4]; //other y position belonging to this code (one for each direction)
    std::vector<int> jumpd[4]; //other direction belonging to this code (one for each direction)
    for(int i = 0; i < 4; i++)
    {
        jumpv[i].resize(w * h, -1);
        jumpx[i].resize(w * h, -1);
        jumpy[i].resize(w * h, -1);
        jumpd[i].resize(w * h, -1);
    }

    //begin the interpretation
    #define MEMORYSIZE 1024 //the memory allocation will increase by this size everytime it's full

    std::vector<int> memory;
    std::vector<int> stack;
    std::vector<int> gosubx; //the gosub-return stack
    std::vector<int> gosuby;
    std::vector<int> gosubd;
    memory.resize(MEMORYSIZE);
    stack.clear();
    int p = 0; //pointer in the array a
    int ipx = 0, ipy = 0, ipd = 0; //instruction pointer location and direction
    int mp = 0; //memory pointer
    
    int R, G, B;
    
    bool done = false;
    while(!done)
    {
        R = image[ipy * w * 4 + ipx * 4 + 0];
        G = image[ipy * w * 4 + ipx * 4 + 1];
        B = image[ipy * w * 4 + ipx * 4 + 2];
        
        { //debug
            /*cout << "  ipx:" << ipx << "\n";
            cout << "  ipy:" << ipy << "\n";
            int blah = pop(stack);
            int blah2 = pop(stack);
            int blah3 = pop(stack);
            cout << "  stack 0: " << blah << "\n";
            cout << "  stack 1: " << blah2 << "\n";
            cout << "  stack 2: " << blah3 << "\n";
            stack.push_back(blah3);
            stack.push_back(blah2);
            stack.push_back(blah);
            cout << "  command: " << R % 16 << "\n";*/
        }
        
        switch(R % 16)
        {
            case 0: //NOP
                break;
            case 1: //set IP dir
                ipd = B % 4;
                break;
            case 2: //jump over commands
                moveIP(ipx, ipy, ipd, 256 * G + B);
                break;
            case 3: //if
                if(pop(stack) == 0) moveIP(ipx, ipy, ipd, 256 * G + B);
                break;
            case 4: //translocation
                switch(B % 8)
                {
                    case 0: 
                        ipy = pop(stack);
                        ipx = pop(stack);
                        moveIPBack(ipx, ipy, ipd);
                        break;
                    case 1:
                        gosubx.push_back(ipx);
                        gosuby.push_back(ipy);
                        gosubd.push_back(ipd);
                        ipy = pop(stack);
                        ipx = pop(stack);
                        moveIPBack(ipx, ipy, ipd);
                        break;
                    case 2: //return
                        ipx = pop(gosubx);
                        ipy = pop(gosuby);
                        ipd = pop(gosubd);
                        break;
                    case 3: 
                        ipy += (pop(stack) - 128);
                        ipx += (pop(stack) - 128);
                        moveIPBack(ipx, ipy, ipd);
                        break;
                    case 4:
                        gosubx.push_back(ipx);
                        gosuby.push_back(ipy);
                        gosubd.push_back(ipd);
                        ipy += (pop(stack) - 128);
                        ipx += (pop(stack) - 128);
                        moveIPBack(ipx, ipy, ipd);
                        break;
                    default: break;
                }
                break;
            case 5: //memory command
                switch(B % 8)
                {
                    case 0:
                        memory[mp] = pop(stack);
                        break;
                    case 1:
                        stack.push_back(memory[mp]);
                        break;
                    case 2:
                        mp = pop(stack);
                        if(mp < 0) mp = 0;
                        if(mp > memory.size()) memory.resize(mp + MEMORYSIZE);
                        break;
                    case 3:
                        stack.push_back(mp);
                        break;
                    case 4: 
                        mp++;
                        if(mp > memory.size()) memory.resize(mp + MEMORYSIZE);
                        break;
                    case 5: 
                        mp--;
                        if(mp < 0) mp = 0;
                        break;
                    default: break;
                }
                break;
            case 6: //self modifying code
                {
                    int value = pop(stack);
                    int y = pop(stack);
                    int x = pop(stack);
                    int c = pop(stack);
                    c = wrapmod(c, 3);
                    if(x >= 0 && x < w && y >= 0 && y < h)
                    {
                        image[y * w * 4 + x * 4 + c] = value;
                    }
                    break;
                }
                break;
            case 7: //get data from code
                {
                    int y = pop(stack);
                    int x = pop(stack);
                    int c = pop(stack);
                    c = wrapmod(c, 3);
                    if(x >= 0 && x < w && y >= 0 && y < h)
                    {
                        stack.push_back(image[y * w * 4 + x * 4 + c]);
                    }
                    else stack.push_back(0);
                }
                break;
            case 8: //push constant
                stack.push_back(256 * G + B);
                break;
            case 9: //push two constants
                stack.push_back(G);
                stack.push_back(B);
                break;
            case 10: //stack commands
                switch(B % 4)
                {
                    case 0: pop(stack); break;
                    case 1: //dup
                        {
                            int i = pop(stack);
                            stack.push_back(i);
                            stack.push_back(i);
                        }
                        break;
                    case 2: //swap
                        {
                            int i = pop(stack);
                            int j = pop(stack);
                            stack.push_back(i);
                            stack.push_back(j);
                        }
                        break;
                    case 3: //dup2
                        {
                            int i = pop(stack);
                            int j = pop(stack);
                            stack.push_back(j);
                            stack.push_back(i);
                            stack.push_back(j);
                            stack.push_back(i);
                        }
                        break;
                }
                break;
            case 11: //math commands
             //B % 32 selects the math operator, respectively: 0:+, 1:-, 2:*, 3:/, 4:%, 5:|, 6:&, 7:^, 8:~, 9: >>, 10: <<, 11:==, 12:!=, 13:>, 14:<, 15:>=, 16:<=, 17:&&, 18:||, 19:!, rest:undefined.
                {
                    int a, b;
                    b = pop(stack);
                    a = pop(stack);
                    switch(B % 32)
                    {
                        case 0: stack.push_back(a + b); break;
                        case 1: stack.push_back(a - b); break;
                        case 2: stack.push_back(a * b); break;
                        case 3: stack.push_back(b == 0 ? 0 : a / b); break;
                        case 4: stack.push_back(b == 0 ? 0 : a % b); break;
                        case 5: stack.push_back(a | b); break;
                        case 6: stack.push_back(a & b); break;
                        case 7: stack.push_back(a ^ b); break;
                        case 8: stack.push_back(~a); break;
                        case 9: stack.push_back(a >> b); break;
                        case 10: stack.push_back(a << b); break;
                        case 11: stack.push_back(a == b); break;
                        case 12: stack.push_back(a != b); break;
                        case 13: stack.push_back(a > b); break;
                        case 14: stack.push_back(a < b); break;
                        case 15: stack.push_back(a >= b); break;
                        case 16: stack.push_back(a <= b); break;
                        case 17: stack.push_back(a && b); break;
                        case 18: stack.push_back(a || b); break;
                        case 19: stack.push_back(!a); break;
                        default: stack.push_back(0); break;
                    }
                }
                break;
            case 12: //i/o
                switch(B % 4)
                {
                    case 0: cout << char(pop(stack)); break;
                    case 1: stack.push_back(getchar()); break;
                    case 2: cout << pop(stack); break;
                    default: break;
                }
                break;
            default:
                break;
        }
        
        moveIP(ipx, ipy, ipd);
        if(ipx < 0 || ipx >= w || ipy < 0 || ipy >= h) done = true;
    }



    cout << "\n";
    return 0;
}
/*
Mycelium is an image based programming language where the commands are read from a png image. Only the png format is allowed, to make sure all interpreters use the same format, and because it's an open, loslessly compressed image format. There are enough possible colors per command to encode the commands in an image, though the effect will sometimes be very noticable.

Mycelium has both memory and a stack. Stack and Memory consist out of signed integers of at least 32 bits and are of arbitrary size.

IP = Instruction Pointer, has an x location, an y location and a direction.
MP = Memory Pointer

Commands: 
---------

Commands are read from the RGB pixels of a .png image. R, G and B are values from 0 to 255. First, R % 16 is used to select the command. Depending on the command, G and B are used to provide data, select the effect of the command or choose the behaviour of the command. For the commands where G and B are not mentioned, the values of G and B don't matter.

R % 16:

-0: NOP

-1: set IP dir to B % 4 (0: east, 1: south, 2: west, 3: north)

-2: jump over next 256 * G + B commands

-3: if (!value), jump over next 256 * G + B commands. value is popped from stack.

-4: translocation command, B % 4 selects the translocation command: 0:goto x, y where y and x are popped from the stack, 1: gosub x, y where y and x are popped from the stack, 2: return to last position stored on the gosub stack by the last gosub command, 3: relative goto x, y (x - 128 and y - 128 added to current IP pos), 4: relative gosub x, y.

-5: Memory command, B % 8 selects the command: 0: set *MP top value popped from stack, 1: push *MP to stack, 2: set MP to value popped from stack (<0 becomes 0), 3: push MP to stack, 4: increment MP, 5: decrement MP (will stay at 0 if it's 0), rest: undefined

-6: set colorchannel of code pixel at position x, y to value popped from stack. the value, y, x and the channel are popped. If x or y are outside the code, nothing happens. c is wrapped to a value from 0 to 2, 0 = red channel, 1 = green channel, 2 = blue channel.

-7: push to the stack: colorchannel of code pixel at position x, y. y, x and the channel are popped. If x or y are outside the code, 0 is pushed instead. c is wrapped to a value from 0 to 2, 0 = red channel, 1 = green channel, 2 = blue channel.

-8: push constant. The constant is a value from 0 to 65536, calculated as: 256 * G + B

-9: push two constants: first G is pushed (0-255), then B is pushed (0-255).

-10: stack command. Which stack command it is is determined by B % 4, respectively: 0: pop, 1: dup (duplicate top value), 2: swap (swap the two top values), 3: dup2 (both top values are duplicated)

-11: math commands performed on the top two values of the stack. Those values are popped (all math commands pop two values, the unary operators will perform their operation on the last value popped and the other will be lost; for binary commands, first the second operand, then the first operand, are popped so you push them on the stack in the correct order), and the result is pushed.. B % 32 selects the math operator, respectively: 0:+, 1:-, 2:*, 3:/, 4:%, 5:|, 6:&, 7:^, 8:~, 9: >>, 10: <<, 11:==, 12:!=, 13:>, 14:<, 15:>=, 16:<=, 17:&&, 18:||, 19:!, rest: undefined but will also pop two values and push one value. These operators have the same effect on signed integers as defined in the C language specification.

-12: io commands, B % 4 selects the command, respectively: 0:output char, 1: input char, 2: output integer, 3: undefined

-rest: undefined


Shorter Mycelium Command Overview:
----------------------------------
R % 16:

-0: NOP
-1: set IP dir (0: east, 1:south, 2: west, 3: north)
-2: jump
-3: if
-4: translocation (0: goto, 1: gosub, 2: return, 3: rel. goto, 4: rel. gosub)
-5: memory (0: set *MP, 1: get *MP, 2: set MP, 3: get MP, 4: MP++, 5: MP--)
-6: set code pixel color channel (first push value, c, x, y)
-7: get code pixel color channel (first push c, x, y)
-8: push 256 * G + B
-9: push G, push B
-10: stack command (0: pop, 1: dup, 2: swap, 3: dup2)
-11: math (0:+ 1:- 2:* 3:/ 4:% 5:| 6:& 7:^ 8:~ 9:>> 10:<< 11:== 12:!= 13:> 14:< 15:>= 16:<= 17:&& 18:|| 19:!)
-12: i/o (0: output char, 1: input char, 2: output integer)
*/
