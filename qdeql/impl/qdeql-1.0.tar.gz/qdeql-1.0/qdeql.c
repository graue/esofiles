#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

typedef unsigned char byte;
typedef struct byteqnode
{
	byte qdata [1000];
	int start, end;
	struct byteqnode *next;
} byteqnode;
typedef struct
{
	int len;
	byteqnode *head, *tail;
} bytequeue;

void error(char *complaint)
{
	fprintf(stderr, "%s\n", complaint);
	exit(1);
}

bytequeue *queue_create(void)
{
	bytequeue *myq;
	myq = malloc(sizeof (bytequeue));
	if (!myq)
		error("Out of memory");
	myq->len = 0;
	myq->head = myq->tail = malloc(sizeof (byteqnode));
	if (!myq->head)
		error("Out of memory");
	myq->tail->next = NULL;
	myq->tail->start = myq->tail->end = 0;
	return myq;
}

void queue_enqueue(bytequeue *q, byte val)
{
	byteqnode *node;
	if ((node = q->tail)->end == 1000)
	{
		node = q->tail = node->next = malloc(sizeof (byteqnode));
		if (!node)
			error("Out of memory");
		node->next = NULL;
		node->start = node->end = 0;
	}
	node->qdata [node->end++] = val;
	q->len++;
}

byte queue_dequeue(bytequeue *q)
{
	if (!q->len)
		return 0;
	if (q->head->start == 1000)
	{
		byteqnode *node = q->head->next;
		free(q->head);
		q->head = node;
	}
	q->len--;
	return q->head->qdata [q->head->start++];
}

void queue_delete(bytequeue *q)
{
	byteqnode *node;
	while (q->head)
	{
		node = q->head->next;
		free(q->head);
		q->head = node;
	}
	free(q);
}

#ifdef DEBUGGING
void queue_debug(bytequeue *q)
{
	int i;
	i = q->len;
	if (i > 0)
	{
		byte b;
		b = queue_dequeue(q);
		printf("%d", b);
		queue_enqueue(q, b);
	}
	for (i--; i > 0; i--)
	{
		byte b;
		b = queue_dequeue(q);
		printf(", %d", b);
		queue_enqueue(q, b);
	}
	putchar('\n');
}
#endif

typedef enum
{
	IN_NEXT   = 0x01,
	IN_DEC    = 0x02,
	IN_INPUT  = 0x03,
	IN_OUTPUT = 0x04,
	IN_BEGIN  = 0x10,
	IN_END    = 0x11
#ifdef DEBUGGING
	,IN_DEBUG  = 0xff
#endif
} qdeql_intype;

typedef struct
{
	qdeql_intype in;
	int r;
} qdeql_instruction;

typedef struct
{
	qdeql_instruction *code;
	int len;
} qdeql_program;

qdeql_intype qdeql_getinstruction(FILE *f)
{
	static qdeql_intype uc2i [UCHAR_MAX + 1] = { IN_BEGIN };
	int c;
	qdeql_intype i;
	if (uc2i [0] == IN_BEGIN)
	{
		uc2i [0] = 0;
		for (c = 1; c <= UCHAR_MAX; c++)
		{
			i = 0;
			if (c == '\\')
				i = IN_BEGIN;
			else if (c == '/')
				i = IN_END;
			else if (c == '=')
				i = IN_NEXT;
			else if (c == '-')
				i = IN_DEC;
			else if (c == '&')
				i = IN_INPUT;
			else if (c == '*')
				i = IN_OUTPUT;
#ifdef DEBUGGING
			else if (c == '`')
				i = IN_DEBUG;
#endif
			uc2i [c] = i;
		}
	}
	for (;;)
	{
		c = fgetc(f);
		if (c < 0 || c > 255)
			return 0;
		if ((i = uc2i [c]))
			break;
	}
	return i;
}

void qdeql_load(qdeql_program *p, FILE *f)
{
	qdeql_instruction *code;
	qdeql_intype in;
	unsigned long filesize;
	int last = 0, depth = 0, begin [1000];

	fseek(f, 0, SEEK_END);
	filesize = ftell(f);
	if (filesize > INT_MAX)
		error("File too long");
	fseek(f, 0, SEEK_SET);

	code = p->code = malloc(filesize * sizeof (qdeql_instruction));
	if (!code)
		error("Not enough memory");

	if (!(in = qdeql_getinstruction(f)))
		error("Program contains no instructions");
	if (in == IN_END)
		error("Unbalanced slashes");
	if (in == IN_BEGIN)
		begin [depth++] = 0;
	code [0].in = in;
	code [0].r = 1;

	while ((in = qdeql_getinstruction(f)))
	{
		if (in == IN_BEGIN)
		{
			last++;
			if (depth < 1000)
				begin [depth] = last;
			depth++;
		}
		else if (in == IN_END && depth <= 1000)
		{
			if (!depth)
				error("Unbalanced slashes");
			last++;
			code [last].r = last - begin [--depth];
			code [begin [depth]].r = code [last].r + 1;
		}
		else if (in == IN_END)
		{
			int mydepth = depth, start;
			for (start = last++; start >= 0; start--)
			{
				if (code [start].in == IN_BEGIN)
				{
					if (mydepth == depth)
						break;
					mydepth--;
				}
				else if (code [start].in == IN_END)
					mydepth++;
			}
			code [last].r = last - start;
			code [start].r = code [last].r + 1;
			depth--;
		}
		else
		{
			if (in == code [last].in)
			{
				code [last].r++;
				continue;
			}
			code [++last].r = 1;
		}
		code [last].in = in;
	}
	fclose(f);
	if (depth)
		error("Unbalanced slashes");
	p->len = last + 1;
}

void qdeql_run(qdeql_program *p)
{
	bytequeue *q;
	qdeql_instruction *ip, *end;

	ip = p->code;
	end = ip + p->len; 

	q = queue_create();

	do
	{
		register qdeql_intype in;
		register int r;
		in = ip->in; r = ip->r;
		if (in == IN_NEXT)
		{
			register byte b;
			for (; r; r--)
			{
				b = queue_dequeue(q);
				queue_enqueue(q, b);
			}
		}
		else if (in == IN_DEC)
		{
			register byte b;
			for (; r; r--)
			{
				b = queue_dequeue(q);
				queue_enqueue(q, b - 1);
			}
		}
		else if (in == IN_OUTPUT)
		{
			register int c;
			for (; r; r--)
			{
				c = queue_dequeue(q);
				putchar(c);
			}
		}
		else if (in == IN_INPUT)
		{
			register int c;
			for (; r; r--)
			{
				c = getchar();
				if (c == EOF)
					c = 0;
				queue_enqueue(q, c);
			}
		}
		else if (in == IN_BEGIN)
		{
			register byte b;
			if (!(b = queue_dequeue(q)))
			{
				ip += r;
				continue;
			}
			queue_enqueue(q, b);
			queue_enqueue(q, 0);
			queue_enqueue(q, 0);
		}
#ifdef DEBUGGING
		else if (in == IN_DEBUG)
			queue_debug(q);
#endif
		else /* in == IN_END */
		{
			ip -= r;
			continue;
		}
		ip++;
	} while (ip < end);

	queue_delete(q);
}

void qdeql_freeup(qdeql_program *p)
{
	free(p->code);
}

void qdeql_do(FILE *f)
{
	qdeql_program prog;
	qdeql_load(&prog, f);
	qdeql_run(&prog);
	qdeql_freeup(&prog);
}

int main(int argc, char *argv[])
{
	FILE *codesrc = stdin;
	if (argc < 2 || !(codesrc = fopen(argv[1], "r")))
		error("Unable to open file");
	qdeql_do(codesrc);
	return 0;
}
