/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/


import java.io.*;


public abstract class Interpreter {
  protected InputStream in;
  protected OutputStream out;
  protected PrintStream err;
  public static final String VERSION = "";
  
  public abstract boolean interpret(String source);
  
    
  public Interpreter() {
    this(System.in, System.out, System.err);
  }

  public Interpreter(InputStream in, OutputStream out, OutputStream err) {
    this.in = in;
    this.out = out;
    this.err = new PrintStream(err);      
  }
  

} // class Interpreter