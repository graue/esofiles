/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

import java.util.Stack;
import java.io.PrintStream;

public class Operator {
  
  char operator;
  public Operand operand1, operand2;
  Operator nextOperator, loopOperator=null;
  boolean jump = false;
  PrintStream err;

  public Operator(char operator, Operand operand1, Operand operand2, Stack loopStack, PrintStream err){
    this.operator = operator;
    this.operand1 = operand1;
    this.operand2 = operand2;
    this.err = err;
    //this.nextOperator = nextOperator;
    if (operator == '(') loopStack.push(this);

    if (operator == ')') {
      loopOperator = (Operator)(loopStack.pop());
      loopOperator.setLoopOperator(this);

    }
  }

  public void execute() throws StackException {
    switch(operator) {
      case '<': operand1.push(operand2.pop());                
                break;
      case '>': operand2.push(operand1.pop());                
                break;
      case '-': operand1.push(operand1.peek() - operand2.pop());
                break;
      case '+': operand1.push(operand1.peek() + operand2.pop());
                break;
      case '?': if (operand1.peek()==0) operand1.clear();                  
                break;
      case '(': jump = operand2.empty();//!continueLoop();      
                break;
      case ')': jump = !loopOperator.operand2.empty();      
                break;
      case '&': err.println(" " + operand1.toString() + ": " + operand1.getStack().toString());                  
                break;
      case '%': err.println(" " + operand1.toString() + ": " + operand1.getStack().peek());                  
                break;
    }
  }

  /*public boolean continueLoop() throws StackException{
    return !operand2.empty();
  }*/

  public void setLoopOperator(Operator loopOperator) {
    this.loopOperator = loopOperator;
  }

  public Operator next() {
    return nextOperator;
  }

  public void setNext(Operator next){
    nextOperator = next;
  }

  public Operator conditionalNext() throws StackException {
    if ((loopOperator != null) && (jump)) {
      return loopOperator;
    }else{
      return nextOperator;
    }
  }

  public String toString() {
    String op1 = "", op2 = "";
    if (operand1 != null) op1 = operand1.toString();
    if (operand2 != null) op2 = operand2.toString();
    return op1 + operator + op2;
  }

}