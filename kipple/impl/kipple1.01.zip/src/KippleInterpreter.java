/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

import java.util.Stack;
import java.io.*;

public class KippleInterpreter extends Interpreter implements KippleLanguage{ 
  public static final char[] DEBUG_OPERATORS = "&%".toCharArray();
  public static final String VERSION = "1.0";
  protected IntegerStack[] A;
  

  
  public KippleInterpreter() {
    this(System.in, System.out, System.err);
  }
  
  public KippleInterpreter(InputStream in, OutputStream out, OutputStream err) {
    super(in, out, err);
    
  }
  
  public IntegerStack getStack(char identifier) throws StackException{
    
    if (isASCIILetter(identifier)) {
      return A[Character.toLowerCase(identifier)-97];
    }else{
      for (int i = 0; i < SPECIAL_STACKS.length; i++) {
        if (SPECIAL_STACKS[i]==identifier) return A[NUM_ORD_STACKS + i];
        else throw new StackException("" + identifier + " is not a valid stack identifier");
      }
    }
    return null;
  }
  
  public boolean interpret(String source) {   
    
    A = new IntegerStack[NUM_ORD_STACKS + SPECIAL_STACKS.length];
    for (int i = 0; i < NUM_ORD_STACKS; i++) A[i] = new IntegerStack();
    A[NUM_ORD_STACKS] = new AlphaStack();
      
    source = new StringPreprocessor().preprocess(source); 

    try {

     //Fill inputStack:
      try { 
        int b;        
        IntegerStack is = getStack('i');
        while ((b = in.read()) >= 0) is.push(b);
      } catch (IOException e) { err.println(e); }     //IntegerStack outputStack = getStack('o');


      //Run program:
      Operator o = tokenize(source); 
      try {
        while (o != null) {        
          o.execute();      
          o = o.conditionalNext();
        }
      } catch (StackException e) {err.println(e);}

      //Output outputStack:
      try {
        IntegerStack os = getStack('o');
        while (!os.empty()) out.write((byte)os.pop());
        out.flush();
      }catch (IOException e) { err.println(e); }



    }catch (StackException e) { err.println(e); }

    return true;     
  }//interpret()

  /*public void reportError(String e, int i) {
    int ln=1;
    for (int p = 0; p <= i; p++) if (S[p]==KI.EOL) ln++;
    err.println(e + " (Line " + ln + ")");
  }*/

  
  public String removeComments(String source) {
    StringBuffer buf = new StringBuffer(source);
    int pos = 0, cStart=-1;
    while (pos < buf.length()) {
      if ((buf.charAt(pos)==COMMENT_START) && (cStart < 0)) cStart=pos;
      if ((buf.charAt(pos)==COMMENT_END) && (cStart >= 0)) {
        buf.delete(cStart, pos);
        pos = cStart;
        cStart=-1;
      }
      pos++;
    }   
    if (cStart>0) buf.delete(cStart, buf.length());    
    return buf.toString();
  }//removeComments
  
  public static boolean isOperator(char ch) {
    for (int i = 0; i < KIPPLE_OPERATORS.length; i++) if (KIPPLE_OPERATORS[i] == ch) return true;
    for (int i = 0; i < DEBUG_OPERATORS.length;  i++) if (DEBUG_OPERATORS[i]  == ch) return true;
    return false;
  }
  
  public static boolean isSpecialStack(char ch) {
    for (int i = 0; i < SPECIAL_STACKS.length; i++) if (SPECIAL_STACKS[i] == ch) return true;
    return false;
  }

  public static boolean isValidStackIdentifier(char ch) {
    return ((isASCIILetter(ch)) || (isSpecialStack(ch)));
  }

  public static boolean isASCIINumber(char ch) {
    return ((ch >= '0') && (ch <= '9'));
  }

  public static boolean isASCIILetter(char ch) {
    return (((ch >= 'a') && (ch <= 'z')) || ((ch >= 'A') && (ch <= 'Z')));
  }
  
  public Operator tokenize(String str) throws StackException{
    char[] source = removeComments(str).toCharArray();
    Stack loopStack = new Stack();
    Operator operator = null, firstOperator = null;;

    for (int i = 0; i < source.length; i++) {           
      if (isOperator(source[i])) {
        if (firstOperator == null) {
          firstOperator = new Operator(source[i], findOperand(source, i, -1), findOperand(source, i, +1), loopStack, err);
          operator = firstOperator;
        }else{
          operator.setNext(new Operator(source[i], findOperand(source, i, -1), findOperand(source, i, +1), loopStack, err));
          operator = operator.next();
        }
      }      
    }
    return firstOperator;
  }//tokenize()
  
  public Operand findOperand(char[] S, int pos, int dir) throws StackException {
    Operand result = null;
    int p, len;

    if (!(((pos <= 0) && (dir < 0)) || ((pos >= (S.length - 1)) && (dir > 0)))) {
      if (isValidStackIdentifier(S[pos + dir])) {
        result = new Operand(S[pos + dir], this);
      }

      if ((isASCIINumber(S[pos + dir]))){ 
        p = pos + dir;
        while (((p + dir)>=0) && ((p + dir)<=(S.length - 1)) && (isASCIINumber(S[p + dir]))) p += dir;
        if (p > pos){
          len = p - pos;
          p = pos + 1;
        }else{
          len = pos - p;
        }
        result = new Operand(new Integer(new String(S, p, len)).intValue());
      }
    }
    return result;
  }//findOperand()
  

  public void setInputStream(InputStream in) {
    this.in = in;
  }

  public InputStream getInputStream() {
    return in;
  }

  public void setOutputStream(OutputStream out) {
    this.out = out;
  }

  public OutputStream getOutputStream() {
    return out;
  }

  public void setErrorStream(OutputStream err) {
    this.err = new PrintStream(err);
  }

  public OutputStream setErrorStream() {
    return err;
  }
}//Class
