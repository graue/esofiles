/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

public class StringPreprocessor implements Preprocessor{
  public static final char STRING_DELIMITER = '\"';
  
  public String preprocess(String S) {
    StringBuffer buf = new StringBuffer();
    boolean inString = false;
    int p0 = 0, p1 = -1, p2 = -1;
    String string, temp = "";
    char stackID = 0;
    
    for (int i = 0; i < S.length(); i++) {
      if (S.charAt(i) == KippleInterpreter.COMMENT_START) while (S.charAt(i) != KippleInterpreter.COMMENT_END) i++;
      
      if (S.charAt(i) == STRING_DELIMITER) {
        inString = false;
        p1 = i; i++;
        while((i < S.length()) && (S.charAt(i) != STRING_DELIMITER)) i++;
        p2 = i;
        string = new String(S.toCharArray(), p1 + 1, p2 - p1 - 1);        
        
        if (p1 >= 2) {
          if ((S.charAt(p1 - 1) == '<') && (KippleInterpreter.isValidStackIdentifier(S.charAt(p1 - 2)))) {
            inString = true;
            stackID = S.charAt(p1 - 2);
            temp = "";
            buf.append(S.substring(p0, p1 - 1) + " ");

            if (string.length() > 0) {      
              for (int j = 0; j < string.length(); j++) temp += stackID + "<" + new Integer(string.charAt(j)).intValue()+ " ";
            }else{
              temp += stackID; // + "<0";  
            }
            buf.append(temp);
          }
        }
        
        if (S.length() > (p2 + 2)) {
          if ((S.charAt(p2+1) == '>') && (KippleInterpreter.isValidStackIdentifier(S.charAt(p2 + 2)))) {
            stackID = S.charAt(p2 + 2);
            temp = "";
            if ((!inString) && (p1 > 0))  buf.append(S.substring(p0, p1 - 1));
            inString = true;

            if (string.length() > 0) {      
              for (int j = string.length()-1; j >= 0; j--) temp += " " + new Integer(string.charAt(j)).intValue() + ">" + stackID;
            }else{
              temp += stackID; // + "<0";  
            }
            buf.append(temp + " ");
          }
        }
        if (inString) {
          p0 = p2 + 2;
          i = p0;
        }
      }
    }
    if (p0 < S.length()) buf.append(S.substring(p0, S.length()));
    //System.out.println(buf);
    
    return new String(buf);
  }
  
}