/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

import java.util.Stack;

public class IntegerStack {
  protected Stack stack;

  public IntegerStack() {
    stack = new Stack();
  }

  public IntegerStack(Stack s) {
    stack = s;
  }

  public void clear() {
    stack.clear();
  }

  public boolean empty() {
    return stack.empty();
  }

  public int peek() {
    if (empty()) return 0;
    else return ((Integer)stack.peek()).intValue();
  }

  public int pop() {
    if (empty()) return 0;
    else return ((Integer)stack.pop()).intValue();
  }

  public int push(int value) {
    return ((Integer)stack.push(new Integer(value))).intValue();
  }

  public String toString() {
    return stack.toString();
  }

  public Object clone() {
    return new IntegerStack((Stack)stack.clone());
  }


} // class IntegerStack