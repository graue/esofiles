/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

public class Operand{
  public static final int TYPE_UNDEFINED = -1;
  public static final int TYPE_STACK_INDENTIFIER = 0;
  public static final int TYPE_INTEGER = 1;

  protected int type = TYPE_UNDEFINED;
  protected int intValue;
  protected IntegerStack stack;
  protected char stackIdentifier;

  public Operand(char stackIdentifier, KippleInterpreter KI) throws StackException{


    type = TYPE_STACK_INDENTIFIER;  
    this.stackIdentifier = stackIdentifier;
    this.stack = KI.getStack(stackIdentifier);
  }

  public Operand(int intValue) {
    type = TYPE_INTEGER;
    this.intValue = intValue;
  }

  public String toString() {
    switch(type) {
      case TYPE_STACK_INDENTIFIER: return "" + stackIdentifier;
      case TYPE_INTEGER:  return "" + intValue;
      default: return "";
    }
  }

  public IntegerStack getStack() {
    return stack;
  }

  public int pop() throws StackException {
    switch(type) {
      case TYPE_STACK_INDENTIFIER: return stack.pop();
      case TYPE_INTEGER:  return intValue;
      default: throw new StackException("Error in Operand.pop()");
    }
  }

  public void push(int value) throws StackException{
    switch(type) {
      case TYPE_STACK_INDENTIFIER: stack.push(value);
                                   break;
      default: throw new StackException("Operator is not a valid stack identifier");
    }
  }

  public int peek() throws StackException {
    switch(type) {
      case TYPE_STACK_INDENTIFIER: return stack.peek();
      case TYPE_INTEGER:  return intValue;
      default: throw new StackException("Error in Operand.peek()");
    }
  }  

  public boolean empty() throws StackException{
    switch(type) {
      case TYPE_STACK_INDENTIFIER: return stack.empty();
      default: throw new StackException("Operator is not a valid stack identifier");
    }
  } 

  public void clear() throws StackException{
    switch(type) {
      case TYPE_STACK_INDENTIFIER: stack.clear();
                                   break; 
      default: throw new StackException("Operator is not a valid stack identifier");
    }
  }

}//class
