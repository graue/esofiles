/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

import java.io.*;

public class Kipple {
  KippleInterpreter KI;
  
  public static void displayError(String msg) {
    System.err.println(msg);
    System.exit(0);
  }
  
  public static void main(String[] args) {
    StringBuffer source = new StringBuffer();
    InputStream in = System.in;
    OutputStream out = System.out;
    OutputStream err = System.err;
    boolean preprocessOnly = false;
    
    
    if (args.length==0) displayUsage();
    
    for (int i = 0; i < args.length; i++) {
      if (args[i].charAt(0) == '-') {
        switch (args[i].charAt(1)) {
          case 'i': if ((i++) < (args.length - 1))           
                      try { 
                        in = new FileInputStream(args[i]); 
                      }catch (FileNotFoundException e) { displayError("File not found: " + args[i]); }
                    else displayError("Missing input filename");
                    break;  
          case 'o': if ((i++) < (args.length - 1)) 
                      try { 
                        out = new FileOutputStream(args[i]); 
                      }catch (FileNotFoundException e) { displayError("Unable to write to " + args[i]); }
                    else displayError("Missing output filename");
                    break;
          case 'e': if ((i++) < (args.length - 1)) 
                      try { 
                        err = new FileOutputStream(args[i]); 
                      }catch (FileNotFoundException e) { displayError("Unable to write to " + args[i]); }
                    else displayError("Missing error filename");
                    break;       
          case 'h': displayUsage();
          case 'n': in = new ByteArrayInputStream(new byte[0]);
                    break;
          case 'p': preprocessOnly = true;
                    break;
          default:  displayError("Invalid argument: " + args[i]);
                    
        }
        
      }
    }
    
    if (args.length <= 0) displayError("Error: No source file specified!");
    
    if (args.length >= 1) {      
      try {
        FileInputStream src = new FileInputStream(args[args.length-1]);
        int b=-1;

        b = src.read();
        while (b>=0)  {
          source.append((char)b);
          b = src.read(); 
        } 
        
      } catch (FileNotFoundException e) { displayError("File not found: " + args[args.length-1]); }
      catch (IOException e) { displayError(e.toString());}
      
      if (preprocessOnly) {
        char[] res = new StringPreprocessor().preprocess(source.toString()).toCharArray();
        try {
          for (int i = 0; i < res.length; i++) out.write((byte)res[i]);
          out.flush();
        }catch (IOException e) { displayError(e.toString());}
      }else{
        new Kipple(source.toString(), in, out, err);
      }
    }   

  }//main()
  
  public static void displayUsage() {
    System.out.println("Kipple Interpreter version " + KippleInterpreter.VERSION);
    System.out.println("Copyright (C) 2003 Rune Berge  -  http://rune.krokodille.com/lang/kipple");
    System.out.println("This is free software by the terms of the GNU General Public License");
    System.out.println("");
    System.out.println("Usage: Kipple [OPTIONS] [filename]");
    System.out.println("");
    System.out.println("Options:");
    System.out.println("  -i <filename>   Read input from this file (default is standard input)");
    System.out.println("  -o <filename>   Write output to this file (default is standard output)");
    System.out.println("  -e <filename>   Write error messages to this file (default is standard output)");
    System.out.println("  -n              No input (i.e. don't block for user input");
    System.out.println("  -h              Display this information");
    System.out.println("  -p              Only perform preprocessing (don't run the program)");
    System.out.println("");
    System.out.println("");
    System.out.println("Please report any bugs to rune@krokodille.com");
    
    System.exit(0);
  }
  
  public Kipple(String source, InputStream in, OutputStream out, OutputStream err) {
    KI = new KippleInterpreter(in, out, err);
    KI.interpret(source);
  }  
  
}