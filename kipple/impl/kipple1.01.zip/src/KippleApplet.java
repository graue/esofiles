/*

Copyright (C) 2003 Rune Berge

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version. 
See http://www.gnu.org/copyleft/gpl.html for details.

*/

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class KippleApplet extends Applet implements ItemListener, ActionListener{
  String sourcePath = "samples/";
  String[] srcFiles = {"beer.k", "beer2.k", "bfi.k", "cat.k", "fib.k", "hello.k", "hello2.k", "reverse.k"};
  
  TextArea[] textAreas;
  static final int SOURCE = 0, INPUT = 1, OUTPUT = 2;
  Panel mainPanel, buttonPanel;
  Choice programChoice;
  Checkbox sourceCheckbox, inputCheckbox, outputCheckbox;
  CheckboxGroup cg;
  CardLayout mainLayout;
  Button runButton;
  Label sampleLabel;
  
  KippleInterpreter KI;
  
  public void init() {
    
    cg = new CheckboxGroup();
    sourceCheckbox = new Checkbox("Source", cg, true);
    inputCheckbox  = new Checkbox("Input",  cg, false);
    outputCheckbox = new Checkbox("Output", cg, false);
    sourceCheckbox.addItemListener(this);
    inputCheckbox.addItemListener(this);
    outputCheckbox.addItemListener(this);
    
    runButton = new Button("Run!");
    runButton.setActionCommand("Interpret");
    runButton.addActionListener(this);
    
    sampleLabel = new Label("Sample programs:", Label.RIGHT);    
    
    programChoice = new Choice();
    programChoice.add("- none -");
    for (int i = 0; i < srcFiles.length; i++) programChoice.add(srcFiles[i]);
    programChoice.addItemListener(this);
    
    
    buttonPanel = new Panel();    
    buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
    buttonPanel.add(runButton);
    buttonPanel.add(sourceCheckbox);
    buttonPanel.add(inputCheckbox );
    buttonPanel.add(outputCheckbox);
    buttonPanel.add(sampleLabel);
    buttonPanel.add(programChoice);
    
    
    
    mainPanel = new Panel();
    mainLayout = new CardLayout(); 
    mainPanel.setLayout(mainLayout);
    textAreas = new TextArea[3];
    
    for (int i = 0; i < textAreas.length; i++) {
      textAreas[i] = new TextArea();
      textAreas[i].setFont(new Font("Monospaced", Font.PLAIN, this.getFont().getSize()));
      mainPanel.add("" + i, textAreas[i]);
    }    
        
    mainLayout.addLayoutComponent(textAreas[SOURCE], "Source");
    mainLayout.addLayoutComponent(textAreas[INPUT],  "Input");
    mainLayout.addLayoutComponent(textAreas[OUTPUT], "Output");    
    mainLayout.show(mainPanel, "Source");
    
    setLayout(new BorderLayout());
    add("North", buttonPanel);
    add("Center", mainPanel);
    
    KI = new KippleInterpreter(null, new TextAreaOutputStream(textAreas[OUTPUT]), System.err);
    
  }

  public void itemStateChanged(ItemEvent e) {
    
    if (e.getItemSelectable() instanceof Checkbox) {
      mainLayout.show(mainPanel, ((Checkbox)e.getItemSelectable()).getLabel() );
    }
    
    if (e.getItemSelectable() instanceof Choice) {
     String filename = ((Choice)e.getItemSelectable()).getSelectedItem();
     if (filename == "- none -") {
       textAreas[SOURCE].setText("");
     }else{
       try {
         int ch = -1;
         StringBuffer buf = new StringBuffer();
         DataInputStream in = new DataInputStream(new URL(getCodeBase() , sourcePath + filename).openStream());
         while ((ch = in.read()) > 0) buf.append((char)ch);
         textAreas[SOURCE].setText(buf.toString());
       }catch (IOException ie) { System.err.println(ie);}
      }
    }
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand() == "Interpret") interpret();
  }
  
  private void interpret() {
    setCursor(new Cursor(Cursor.WAIT_CURSOR));
    textAreas[OUTPUT].setText(""); 
    KI.setInputStream(new TextAreaInputStream(textAreas[INPUT]));
    KI.interpret(textAreas[SOURCE].getText());
    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }
  
  public void start() {}

  public void stop() {}

  public class TextAreaOutputStream extends OutputStream {
    TextArea target;
    StringBuffer temp;
    
    public TextAreaOutputStream(TextArea target) {
      this.target = target;  
      temp = new StringBuffer();
    }
    
    public void write(int b) {
      temp.append((char)b);
    }
    
    public void flush() {
      target.setText(target.getText() + temp.toString());
      temp = new StringBuffer();
    }
  }
  
  public class TextAreaInputStream extends InputStream {
    char[] text;
    int index;
    
    
    public TextAreaInputStream(TextArea source) {
      text = source.getText().toCharArray();
      index = 0;
    }

    public int read() {
      index++;
      if (index <= text.length) return text[index-1];
      else return -1;
    }
  }

}