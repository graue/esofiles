
KIPPLE INTERPRETER v.1.01
--------------------------------------------------------------------------------
Copyright (C) 2003 Rune Berge
Kipple home page: http://rune.krokodille.com/lang/kipple
This software is licensed under the GNU General Public License (see license.txt)
--------------------------------------------------------------------------------

* Introduction

Kipple is a minimalistic programming language where all data manipulation is done with stacks of integers. Kipple's only features are the stacks, four operators and one control structure, but it is nonetheless Turing-complete. My primary source of inspiration for creating Kipple was the programming language Brainfuck which introduced me to the wonderful world of Esoteric programming languages. For details about the language see the included kipple.html file.

A couple of sample Kipple programs are located in the samples directory. Full source code for the interpreter is located in the src directory.

Questions, comments, bug reports etc. can be sent to me at rune@krokodille.com


* Using the interpreter

There are two ways of running the interpreter. The easiest way is to just run interpreter.html in a Java-enabled web-browser. 

You can also use the interpreter at the command line. You must have a Java Virtual Machine installed for this to work (see http://java.sun.com). To use the interpreter run "java -jar Kipple.jar <OPTIONS> filename" at the command line. Running "java -jar Kipple.jar" will display all available options. To execute the hello.k program in the samples directory run "java -jar Kipple.jar -n samples/hello.k" 


* Release notes

Kipple 1.01 (18.11.2003)
------------------------

- Fixed a bug in the interpreter which caused the applet version to not clear the stacks between executions.


Kipple 1.0 (01.10.2003)
-----------------------

First release.

