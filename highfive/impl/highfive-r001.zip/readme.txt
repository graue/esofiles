HighFive Interpreter - alpha release 1
(C) thematrixeatsyou, 2006

 ------------------------------------------------------------------------------

Hello! This is the first official interpreter for HighFive!
To use it, type these parameters into the command line:
  highfive /i <filename>
Replace <filename> with the name of the file you would like to compile.
(Gee, that rhymes :D) Actually, it just interprets it.

The /c switch is used to compile stuff but that's not supported yet, so it just
interprets it instead.

If you just supply the filename it'll interpret it anyway.
What other program lets you interpret HighFive in 3 different ways?
Doesn't change the end result.

 ------------------------------------------------------------------------------

HighFive Architecture 1.0 specification:

The HighFive command set goes as such:
 + = increase what's at the pointer, or if pointer = 7, get input.
 - = decrease what's at the pointer, including if pointer = 7.
 / = increase the pointer. If pointer goes past 7, reset it to 0.
 * = if the last value modified is not 0, relative jump:
     - whatever's at the pointer, move Program Counter (PC)
       forward or backward that number of steps.
 . = output whatever's at the pointer.

What's at each pointer:

0  memory slot #0
   1  memory slot #1
      2  memory slot #2
         3  memory slot #3
            4  memory slot #4
               5  segment
                  6  I/O address
                     7  input

It's not too dissimilar to a CPU architecture.

I/O address list:
 - 0 = CON (keyboard / screen)

That's the only one so far. Any requests, just email me (address below).

How the segments work:
Just change slot #5. Values are shown in hex.
00: 000 001 002 003 004
01: 005 006 007 008 009
02: 00A 00B 00C 00D 00E
03: 00F 010 011 012 013
... ... ... ... ... ...
FE: 4F6 4F7 4F8 4F9 4FA
FF: 4FB 4FC 4FD 4FE 4FF

So you have 1280 bytes of RAM. If someone needs more then I'll rig up a mapper
over one of the I/O ports, else it'll stay as-is. Just one 8-bit value can
boost it up to 327680 bytes (320KB), which is more than Brainf*ck's 44000B.

 ------------------------------------------------------------------------------

There are two sample programs supplied.
 - HELLO.HF    - prints "Hello World!"
 - COPYTXT.HF  - copies exactly what you type, e.g. "II''mm  ffaatt"
I was working on GETLINE.HF which is meant to repeat the line you type, but it
was such a pain that I just deleted it. Managed to load up two characters and
that's it. If anyone can do it then they get big credit.
What GETLINE.HF is meant to do:
- Abuse the I/O register to put the length of the first loop in.
- The first loop:
  - Put the length of the second loop in the #4 slot of each segment.
- Reset the I/O register to zero.
- The second loop:
  - Increase the segment.
  - Get a character.
  - Loop 2.1:
    - Move it to slot #1.
  - Decrease it by 13 (enter). If enter is pressed, move on, else loop.
- Abuse
- The third loop:
Want some BF source for inspiration? Here:
----------[++++++++++>,----------]<[<]>[.>]
It'll most likely be at least 5 times the size.

 ------------------------------------------------------------------------------

Any comments, code suggestions (no body suggestions please), email me at:
  th ema t ri x eat sy ou @y ah o o. co . n z
Unless it's pharma spam. I'm happy with my body as it is, so piss off.
Just remove the spaces and voila! There's my address.

Have fun! Even if it's frustrating fun, it's still fun!
- thematrixeatsyou, 07-07-2006