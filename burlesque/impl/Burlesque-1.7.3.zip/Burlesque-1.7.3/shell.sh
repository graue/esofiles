runghc main.hs --shell
