/* brfd.h - Br*inFuck Debugger, Copyright (c) 2001 Pedro Gimeno Fortea. */

/* Common header file for the various modules */
#ifndef __BRFD_H__
#define __BRFD_H__

#include <stdio.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Configuration */
#define ErrUnknownChar 0 /* set to 1 to give an error on unknown characters */
#define DollarIsEOP 0 /* set to 0 to let '$' be just an end-of-file char */

#ifndef MAX_PATH
#  define MAX_PATH 255
#endif

#define FALSE 0
#define TRUE 1
#define FF 12 /* ASCII Form Feed */
#define PROGNAME "brfd"
#define VERSION "1.0"
#define COPYRIGHT "Copyright (c) 2001 Pedro Gimeno Fortea." \
  " All rights reserved."
#define local static
#define global

#define DataSize 80000
#define ProgSize 80000

#define LineSize 80

typedef unsigned long ulong;
typedef unsigned char uchar;
typedef signed char schar;
typedef unsigned int uint;
typedef int bool;
typedef int idx_t;
typedef char progtype;
typedef uchar datatype;

extern char errline[LineSize]; /* Error line composed at runtime */

/* Command-line flags */
extern char fname[MAX_PATH];
extern bool verbose;
extern bool superquiet;
extern bool prgoutput;
extern bool debugmode;
extern bool cont_stdin;
extern bool slow;
extern char * infname;
extern char * outfname;

/* Program / Data segments and pointers */
extern progtype * progseg;
extern datatype * dataseg;
extern idx_t progptr;
extern idx_t dataptr;

extern FILE * infile;
extern FILE * outfile;

#if UINT_MAX > 999999999 /* optimize to using unsigned int if possible */
typedef unsigned PetraH;
typedef unsigned PetraL;
#define PetraFmt "u"
#else
typedef ulong PetraH;
typedef ulong PetraL;
#define PetraFmt "lu"
#endif

extern PetraH CountH;
extern PetraL CountL;

/* To avoid complex calculations for displaying a 64-bit counter in a
   portable way we wrap countl when it reaches 10^9, so the full
   counter will wrap to zero after reaching 4294967295999999999
   (assuming ulongs). I call this "petradecimal". */
#define inccount do {\
    if (CountL++ == 999999999UL) {CountL = 0; CountH++;} \
  } while (FALSE)

extern void Run(void);
extern void Debug(void);
extern int LoadProg(void);
extern void ResetProg(void);
extern int SetInputFile(char * fname);
extern int SetOutputFile(char * fname);
extern uchar ToPrintable(uchar c);
extern void freeandnil(void ** p);
extern void PetraToAscii(char * dest, ulong h, ulong l);
extern void print(char * s);
extern void printerr(char * err);
extern void outchar(datatype c);
extern datatype inpchar(void);
extern char LowerCase(char c);
extern void HitStart(void);
extern void HitEnd(void);

#ifdef __cplusplus
}
#endif

#endif /* __BRFD_H__ */
