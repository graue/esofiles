#include <stdlib.h>
#include <string.h>

#include "brfd.h"

local void ShowStats(void)
{
  char line[80];
  char line2[80];
  PetraToAscii(line2, CountH, CountL);
  sprintf(line, "\nProgram stopped. PP=%d; DP=%d \n", progptr, dataptr);
  print(line);
  sprintf(line, "Instructions executed: %s\n", line2);
  print(line);
}

global void Run(void)
{
  /* Assumes good nesting of [ and ] (checked on load) to improve speed */
  int Level = 0;

  do {
    switch (progseg[progptr++]) {
    case '$':
      progptr--;
      goto ExitLoop;
    case '+':
      dataseg[dataptr]++;
      break;
    case '-':
      dataseg[dataptr]--;
      break;
    case '<':
      if (dataptr > 0) dataptr--;
      else HitStart();
      break;
    case '>':
      if (dataptr < DataSize-1) dataptr++;
      else HitEnd();
      break;
    case ',':
      dataseg[dataptr] = inpchar();
      break;
    case '.':
      outchar(dataseg[dataptr]);
      break;
    case '[':
      if (!dataseg[dataptr]) {
        Level++;
        do {
          switch(progseg[progptr++]) {
          case '[':
            Level++;
            break;
          case ']':
            Level--;
          }
        } while (Level);
      }
      break;
    case ']':
      if (dataseg[dataptr]) {
        Level++;
        progptr--;
        do {
          switch(progseg[--progptr]) {
          case ']':
            Level++;
            break;
          case '[':
            Level--;
          }
        } while (Level);
        progptr++;
      }
    }
    if (verbose) inccount;
  } while (TRUE);

ExitLoop:
  if (verbose) ShowStats();
}
