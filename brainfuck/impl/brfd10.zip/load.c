#include <string.h>

#include "brfd.h"

/* Syntax of a BrainFuck program, according to this parser:
  % : Starts/ends a comment. Any character except % can
      appear within a comment, including [],.+-<>$#
      The character was chosen after muMATH, the math package
      by The Soft Warehouse which Derive made obsolete.
  # : Starts a single-line comment. Like BASIC's ', C++'s //,
      Assembler's ; and Ada's --. Useful for scripts. Beware
      that this character is used by some authors for other
      purposes such as a program stop or EOF.
  $ : End-of-file. Prevents further processing. Other authors
      use # and @ as the EOF character. I use # as a comment
      for convenience wrt using this program in scripts.
      Currently, this is not allowed to halt a program but it
      can be done using DollarIsEOP below. Remember that
      Turing machines have an extra 'Halt' state which can
      appear anywhere any times, so this might be considered
      legal (except for the fact that it's not part of the
      specifications for the language).
      The symbol was chosen for two reasons: 1. try to use a
      symbol which is not too frequent in normal writing, and
      2. it's the EOL mark in regular expressions (often used
      in compiler theory text as an EOF mark too).
  ! : End processing the file, and take the rest of the file
      as input to the program.
  [],.+-<> : BrainFuck commands
  Rest : Ignored. Beware that in the future these might cause
      an error.
*/

global void ResetProg(void)
{
  progptr = 0;
  dataptr = 0;
  CountH = 0;
  CountL = 0;
  memset(dataseg, 0, DataSize);
}

global int LoadProg(void)
{
  FILE * f;
  char buf[80];
  int r,i;
  int Result = 0;
  bool CommentMode = FALSE;
  bool SingleLineComment = FALSE;
  bool StartOfData = FALSE;

  idx_t Nesting = 0;
  idx_t p = 0;
  ResetProg();

  f = fopen(fname, "rb");
  if (f == NULL) return -4;

  do {
    r=fread(buf, 1, 1, f);
    for (i = 0; i < r; i++) {
      switch(buf[i]) {
      case '+': case '-': case '<':  case '>':
      case ',': case '.': case '[':  case ']':
        if (!CommentMode && !SingleLineComment) {
          if (buf[i] == '[') Nesting++;
          if (buf[i] == ']') {
            if (Nesting > 0) Nesting--;
            else Result = -6;
          }
          if (!Result) {
            if (p < ProgSize) progseg[p++] = buf[i];
            else Result = -7;
          }
        }
        break;
      case '%':
        if (!SingleLineComment) CommentMode = !CommentMode;
        break;
      case '!':
        if (!CommentMode && !SingleLineComment) StartOfData = TRUE;
        break;
#if DollarIsEOP
      case '$':
        if (p < ProgSize) progseg[p++] = buf[i];
        else Result = -7;
        break;
#endif
      case '\r':
      case '\n':
        if (SingleLineComment) SingleLineComment = FALSE;
        break;
      case '#':
        if (!CommentMode) SingleLineComment = TRUE;
#if ErrUnknownChar
        break;
      case ' ':
      case '\t':
        break;
      default:
        if (!CommentMode && !SingleLineComment)
          Result = -8;
#endif
      }
      if (Result || StartOfData) break;
    }
  } while (r > 0 && !StartOfData && !Result);

  /* Mark end-of-program. We always allocate 1 more byte for
     the program segment, so this should cause no problem. */
  progseg[p] = '$';

  if (StartOfData) {
    if (infile != stdin) fclose(infile);
    infile = f;
  } else fclose(f);

  if (!Result) {
    if (Nesting != 0) Result = -6;
    else if (CommentMode) Result = -5;
  }
  return Result;
}
