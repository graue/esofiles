#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "brfd.h"

char errline[LineSize];
char fname[MAX_PATH];
bool verbose = FALSE;
bool superquiet = FALSE;
bool prgoutput = TRUE;
bool debugmode = FALSE;
bool cont_stdin = FALSE;
bool slow = FALSE;
char * infname = NULL;
char * outfname = NULL;

progtype * progseg = NULL;
datatype * dataseg = NULL;
idx_t progptr;
idx_t dataptr;
FILE * infile;
FILE * outfile;
PetraH CountH;
PetraL CountL;


global void freeandnil(void ** p)
{
  void * q;
  q = *p;
  *p = NULL;
  free(q);
}

global void PetraToAscii(char * dest, PetraH h, PetraL l)
{
  /* Convert h/l in "petradecimal" format to ASCII */
  if (h == 0) sprintf(dest, "%" PetraFmt, l);
  else sprintf(dest, "%" PetraFmt "%09" PetraFmt, h, l);
}

global void print(char * s)
{
  fputs(s, stdout);
  fflush(stdout);
}

global void printerr(char * err)
{
  if (!superquiet) {
    fputs(err, stderr);
    fflush(stderr);
  }
}

global void outchar(datatype c)
{
  if (prgoutput) {
    putc(c, outfile);
    fflush(outfile);
  }
}

global datatype inpchar(void)
{
  int c = getc(infile);

  if (cont_stdin && infile != stdin && c == EOF) {
    fclose(infile);
    infile = stdin;
    c = getc(infile);
  }
  return c;
}

global char LowerCase(char c)
{
  return c >= 'A' && c <= 'Z' ? c+('a'-'A') : c;
}

global uchar ToPrintable(uchar c)
{
  return (c >= ' ' && c <= '~') ? c : '.';
}

global int SetInputFile(char * fname)
{
  if (infile != stdin) {
    fclose(infile);
    infile = stdin;
  }
  if (fname[0] != '\0') {
    infile = fopen(fname, "rb");
    return (infile == NULL) ? -13 : 0;
  } else return 0;
}

global int SetOutputFile(char * fname)
{
  if (outfile != stdout) {
    fclose(outfile);
    outfile = stdout;
  }
  if (fname[0] != '\0') {
    outfile = fopen(fname, "wb");
    return (outfile == NULL) ? -14 : 0;
  } else return 0;
}

global void HitStart(void)
{
  printerr("\nHit the start of the data segment\n");
}

global void HitEnd(void)
{
  printerr("\nHit the end of the data segment\n");
}

local int GetOptions(int argc, char * argv[])
{
  int i;
  int Result = 0;

  fname[0]='\0';

  for (i = 1; i < argc && !Result; i++) {
    if (argv[i][0] == '-') {
      if (argv[i][1] == '-') if ((i+1) < argc) {
        if (fname[0] || i+2 != argc) {
          Result = -3;
        } else {
          strncpy(fname, argv[i+1], MAX_PATH-1);
          fname[MAX_PATH-1]='\0';
          break;
        }
      }
      switch (argv[i][1]) {
      case 'h':
      case 'H':
      case '?':
        Result = 1;
        break;
      case 'q':
        prgoutput = FALSE;
        break;
      case 'Q':
        superquiet = TRUE;
        break;
      case 'v':
        verbose = TRUE;
        break;
      case 's':
        slow = TRUE;
        break;
      case 'd':
        debugmode = TRUE;
        break;
      case 'c':
        cont_stdin = TRUE;
        break;
      case 'r':
        if ((i+1) < argc) infname = argv[++i];
        else Result = -11;
        break;
      case 'w':
        if ((i+1) < argc) outfname = argv[++i];
        else Result = -12;
        break;
      case '-':
        break;
      default:
        Result = -2;
      }
    } else {
      if (fname[0]) Result = -3;
      else {
        strncpy(fname, argv[i], MAX_PATH-1);
        fname[MAX_PATH-1]='\0';
      }
    }
  }
  if (!Result && !fname[0]) Result = -1;

  return Result;
}

local int ReportErr(int Result)
{
  bool ShowUsage = FALSE;
  char s[80];

  switch (Result) {
  case 1:
    ShowUsage = TRUE;
    break;
  case 0:
  case 2:
    break;
  case -1:
    ShowUsage = TRUE;
    printerr("File name missing\n");
    break;
  case -2:
    ShowUsage = TRUE;
    printerr("Unknown option\n");
    break;
  case -3:
    ShowUsage = TRUE;
    printerr("Too many files specified\n");
    break;
  case -4:
    sprintf(s, "Can't open %-.65s\n", fname);
    printerr(s);
    break;
  case -5:
    printerr("End-of-file reached within a comment\n");
    break;
  case -6:
    printerr("Nesting [] error in input file\n");
    break;
  case -7:
    printerr("Program too big to fit in memory\n");
    break;
  case -8:
    printerr("Invalid character in input file\n");
    break;
  case -9: /* assertion error */
    printerr(errline);
    break;
  case -10:
    printerr("Not enough memory for program or data segments\n");
    break;
  case -11:
    printerr("Missing input file name\n");
    break;
  case -12:
    printerr("Missing output file name\n");
    break;
  case -13:
    printerr("Can't open input file\n");
    break;
  case -14:
    printerr("Can't open output file\n");
    break;
  default:
    Result = (Result < -32000 ? -32000 : (Result > 32000 ? 32000 : Result));
    sprintf(s, "Unknown internal result code: %d\n", Result);
    printerr(s);
  }

  if (ShowUsage) {
    printerr("Usage:\n"
             "  " PROGNAME " [-option -option ...] filename\n"
             "Options:\n"
    );
    printerr("  -h         Show this help\n");
    printerr("  -d         Enter debug mode\n");
    printerr("  -q         Supress BF program output\n");
    printerr("  -Q         Be quiet (no errors)\n");
    printerr("  -v         Verbose (Show statistics after run)\n");
    printerr("  -s         Force slow mode when running (avoid optimizer)\n");
    printerr("  -w fname   Write program's output to given file\n");
    printerr("  -r fname   Read program's input from given file\n");
    printerr("  -c         Continue reading input from stdin when the program's\n");
    printerr("             input file ends\n");
    printerr("  --         End options (allows filenames starting with dashes)\n");
    printerr(PROGNAME " " VERSION " " COPYRIGHT "\n");
  }
  return Result < 0 ? -Result: 0;
}

global int main(int argc, char * argv[])
{
  int Result;

  dataseg = NULL;
  progseg = NULL;

  infile = stdin;
  outfile = stdout;

  Result = GetOptions(argc, argv);
  if (!Result) {
    dataseg = (datatype *)malloc(DataSize*sizeof(datatype));
    if (dataseg == NULL) Result = -10;
  }
  if (!Result) {
    progseg = (progtype *)malloc((ProgSize+1)*sizeof(progtype));
    if (progseg == NULL) Result = -10;
  }
  if (!Result) memset(progseg, '$', ProgSize+1);
  if (!Result) {
    if (infname != NULL) Result = SetInputFile(infname);
  }
  if (!Result) {
    if (outfname != NULL) Result = SetOutputFile(outfname);
  }
  if (!Result) Result = LoadProg();
  if (!Result) {
    if (debugmode) Debug();
    else Run();
  }

  if (dataseg != NULL) freeandnil((void *)&dataseg);
  if (progseg != NULL) freeandnil((void *)&progseg);

  if (infile != stdin) fclose(infile);
  if (outfile != stdout) fclose(outfile);

  return ReportErr(Result);
}
