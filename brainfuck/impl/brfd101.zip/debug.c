/* debug.c - Br*inFuck Debugger, Copyright (C) 2001 Pedro Gimeno Fortea */

/* Debugging functions for brfd */

#include <string.h>

#include "brfd.h"

local char inp[LineSize];

local void Step(void)
{
  idx_t Level = 1;
  int Result = 0;

  switch (progseg[progptr++]) {
  case '$':
    progptr--;
    printerr("End of program reached\n");
    Result = -2;
    break;
  case '+':
    dataseg[dataptr]++;
    break;
  case '-':
    dataseg[dataptr]--;
    break;
  case '<':
    if (dataptr > 0) dataptr--;
    else printerr("Hit the start of the data segment\n");
    break;
  case '>':
    if (dataptr < DataSize-1) dataptr++;
    else printerr("Hit the end of the data segment\n");
    break;
  case ',':
    dataseg[dataptr] = inpchar();
    break;
  case '.':
    outchar(dataseg[dataptr]);
    break;
  case '[':
    if (!dataseg[dataptr]) {
      while (Level > 0 && !Result) {
        switch(progseg[progptr++]) {
        case '[':
          Level++;
          break;
        case ']':
          Level--;
          break;
        case '$': /* Be careful here: might be a ']' just before ProgSize */
          if (progptr > ProgSize) {
            Result = -1;
            while (progseg[--progptr]=='$')
              ;
            progptr++;
          }
        }
      }
    }
    break;
  case ']':
    if (dataseg[dataptr]) {
      progptr--;
      while (Level > 0 && progptr > 0) {
        switch(progseg[--progptr]) {
        case ']':
          Level++;
          break;
        case '[':
          Level--;
        }
      }
      if (progptr == 0 && Level > 0) Result = -1;
      else progptr++;
    }
  }
  if (Result == -1) printerr("Wrong nesting of '[' and ']'\n");
  if (Result != -2) inccount;
}

local void ShowDebugState(void)
{
#define MemTot 9
#define MemPrev 4
  int p;
  char line[80];

  print("Mem:");
  for (p = -MemPrev; p < MemTot-MemPrev; p++) {
    if (p > 0 && p + dataptr >= DataSize) break;
    if (p < 0 && dataptr < -p) strcpy(line, "    ");
    else sprintf(line, "  %02X", dataseg[p+dataptr]);
    if (p == 0) line[1] = '*';
    print(line);
  }
  print("\n");
  sprintf(line, "Data ptr: %6d     Asc : ", dataptr);
  print(line);

  line[1] = '\0';
  for (p = -MemPrev; p < MemTot-MemPrev; p++) {
    if (p > 0 && p + dataptr >= DataSize) break;
    if (p < 0 && dataptr < -p) line[0] = ' ';
    else line[0] = ToPrintable(dataseg[p+dataptr]);
    print(line);
  }

  sprintf(line, "\nProg ptr: %6d     Prog: ", progptr);
  print(line);

  line[1] = '\0';
  for (p = -MemPrev; p < MemTot-MemPrev; p++) {
    if (p > 0 && p + progptr > ProgSize) break;
    if (p < 0 && progptr < -p) line[0] = ' ';
    else line[0] = progseg[p + progptr];

    print(line);
  }

  print("\nSteps:");
  PetraToAscii(line, CountH, CountL);
  for (p = strlen(line); p < 20; p++) print(" ");
  print(line);
  print("     ^\n");

#undef MemTot
#undef MemPrev
}

local void ShowPrompt(void)
{
  print("h for help :");
}

local void GetInputLine(void)
{
  int p;
  do {
    fgets(inp, LineSize, stdin);
    p = strlen(inp);
    if (p > 0) {
      if (inp[p-1] == '\n' || inp[p-1] == '\r') inp[p-1] = '\0';
      else {
        printerr("Line too long\n");
        p = -1;
      }
    }
  } while (p == -1);
}

local bool AskSure(char * line)
{
  print(line);
  do {
    print(" (y/N) ");
    GetInputLine();
  } while (LowerCase(inp[0]) != 'y' && LowerCase(inp[0]) != 'n'
    && inp[0] != '\0');
  return (LowerCase(inp[0]) == 'y');
}

local void ShowHelp(void)
{
  print("\n");
  print("    h, ?         Show this help\n");
  print("    q            Quit\n");
  print("    qy           Quit (without confirmation)\n");
  print("    r            Redraw state\n");
  print("    z            Reset program\n");
  print("    zy           Reset program (without confirmation)\n");
  print("    t [n]        Trace [n times]\n");
  print("    g [n]        Go [and stop at position n]\n");
  print("    l            Go until end of current loop\n");
  print("    p <n>        Set program pointer (p.p.) to n\n");
  print("    d <n>        Set data pointer (d.p.) to n\n");
  print("    a <x>        Alter instruction in current p.p. to <x>\n");
  print("    e <n>        Enter value <n> (decimal) in current d.p.\n");
  print("    o            Toggle show program output on/off\n");
  print("    i <xxx...>   Insert a string before the current instruction\n");
  print("    k <n>        Kill (delete) n instructions from current p.p.\n");
  print("    m [n]        Show memory [starting at position n]\n");
  print("    v [n]        View program [starting at position n]\n");
  print("    f [fname]    Read program's input from stdin [or given file]\n");
  print("    w [fname]    Write program's output to stdout [or given file]\n");
  print("    s [fname]    Save (uncommented) program [with new name \"fname\"]\n");
  print("    <>+-,.       Immediate execution of given instruction\n");
}

local bool IsSpace(char c)
{
  return (c == ' ' || c == '\t' || c == FF);
}

local void SkipSpaces(int * p)
{
  while (IsSpace(inp[*p])) (*p)++;
}

local int ParseFilename(char * Path, int * p)
{
  int q = *p;
  int r = 0;

  SkipSpaces(&q);
  if (inp[q] == '"') {
    /* Quoted filename - process quotes */
    do {
      q++;
      if (inp[q] == '"') {
        q++;
        if (inp[q] != '"') {
          /* close quotes */
          Path[r] = '\0';
          *p = q+1;
          return 0;
        }
      } else if (inp[q] == '\0') {
        Path[0] = '\0'; /* Invalid filename */
        printerr("Missing right quote\n");
        return -1;
      }
      Path[r++] = inp[q];
    } while (TRUE);
  } else {
    do {
      if (inp[q] == '\0' || IsSpace(inp[q])) break;
      Path[r++] = inp[q++];
    } while (TRUE);
    Path[r] = '\0';
    *p = q;
    return 0;
  }
}

local long GetLongArg(int * p)
{
  long val;

  SkipSpaces(p);
  if (inp[*p] == '\0') return -1; /* EOL */

  val = -2; /* quick'n'dirty check for presence of at least one digit */
  while (inp[*p] >= '0' && inp[*p] <= '9') {
    if (val > 214748364L || (val == 214748364L && inp[*p] > '7')) {
      printerr("Argument overflow\n");
      return -3; /* Overflow */
    }
    if (val == -2) val = 0;
    val = val * 10 + inp[*p] - '0';
    (*p)++;
  }

  if (val == -2) printerr("Invalid argument\n");
  return val;
}

local void CheckMissing(long arg)
{
  if (arg == -1) printerr("Parameter expected\n");
}

local void CheckLastArg(int * p, long * arg)
{
  if (*arg < 0) return;
  SkipSpaces(p);
  if (inp[*p]) {
    printerr("Extra characters on line\n");
    *arg = -4;
  }
  return;
}

local void SaveProgram(void)
{
  FILE * f;
  idx_t p = ProgSize;
  idx_t i;

  while (p > 0 && progseg[p] == '$') p--;
  if (p == 0 && progseg[p] == '$') {
    printerr("Program is empty\n");
  } else {
    f = fopen(fname, "wt");
    if (f == NULL) {
      printerr("Can't open output file\n");
    } else {
      for (i = 0; i <= p; i++) {
        putc(progseg[i], f);
        if (i % 60 == 59) putc('\n', f);
      }
      fclose(f);
    }
  }
}

global void Debug(void)
{
  int Result;
  int p;
  idx_t i;
  long arg;
  long Steps;
  idx_t BreakAddr = -1; /* disabled */
  bool repaint = TRUE;
  idx_t Level;
  char Path[MAX_PATH];
  static int LastDataDump = 0;
  static int LastProgDump = 0;
  char cmd;

  do {
    if (repaint) {
      ShowDebugState();
    }
    ShowPrompt();
    GetInputLine();

    repaint = FALSE;

    p = 0;
    SkipSpaces(&p);
    switch ((cmd = LowerCase(inp[p++]))) {

    case 'r':
      repaint = TRUE;
      break;

    case 'q':
      if (LowerCase(inp[p]) == 'y') return;
      else {
        arg = 0;
        CheckLastArg(&p, &arg);
        if (arg == 0) {
          if (AskSure("Are you sure you want to quit?")) return;
        }
      }
      break;

    case 'z':
      if (LowerCase(inp[p]) == 'y') {
        ResetProg();
        repaint = TRUE;
      } else {
        arg = 0;
        CheckLastArg(&p, &arg);
        if (arg >= 0) {
          if (AskSure("Are you sure you want to reset the program?")) {
            ResetProg();
            repaint = TRUE;
          }
        }
      }
      break;

    case 't':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg == -1) arg = 1;
      if (arg > 0) {
        for (Steps = 0; Steps < arg; Steps++) {
          if (progseg[progptr] == '$') break; /* Stop on EOP */
          Step();
        }
        if (Steps < arg) Step(); /* Force one single EOP error */
        LastProgDump = progptr;
        repaint = TRUE;
      }
      break;

    case 'g':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg >= -1) {
        BreakAddr = arg;
        do {
          Step();
        } while (progptr != BreakAddr && progseg[progptr] != '$');
        if (progptr == BreakAddr) print("Breakpoint reached\n");
        BreakAddr = -1;
        repaint = TRUE;
      }
      break;

    case 'p':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg >= 0) {
        if (arg >= ProgSize) printerr("Invalid program pointer value\n");
        else {
          progptr = (int)arg;
          repaint = TRUE;
        }
      } else CheckMissing(arg);
      break;

    case 'd':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg >= 0) {
        if (arg >= DataSize) printerr("Invalid data pointer value\n");
        else {
          dataptr = (int)arg;
          repaint = TRUE;
        }
      } else CheckMissing(arg);
      break;

    case 'a':
      SkipSpaces(&p);
      switch (inp[p]) {
      case '[': case ']': case '<': case '>':
      case '+': case '-': case ',': case '.':
      case '$':
        arg = inp[p++];
        CheckLastArg(&p, &arg);
        if (arg >= 0) {
          if (progptr < ProgSize) {
            progseg[progptr] = arg;
            repaint = TRUE;
          } else printerr("Program pointer out of range\n");
        }
        break;
      case '\0':
        CheckMissing(-1);
        break;
      default:
        printerr("Invalid input character\n");
      }
      break;

    case 'e':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg > 255) printerr("Data value out of range\n");
      else if (arg >= 0) {
        dataseg[dataptr] = arg;
        repaint = TRUE;
      } else CheckMissing(arg);
      break;

    case 'o':
      arg = 0;
      CheckLastArg(&p, &arg);
      if (arg == 0) {
        prgoutput = !prgoutput;
        if (prgoutput) print("Program output has been turned ON\n");
        else print("Program output has been turned OFF\n");
        break;
      }

    case 'i':
      {
        int q, r, j;

        Result = 0;
        SkipSpaces(&p);
        q = p;
        do {
          switch (inp[q]) {
          case '\0':
            if (q == p) {
              CheckMissing(-1);
              Result = -1;
            } else Result = 1;
            break;
          case '<': case '>': case '[': case ']':
          case '+': case '-': case ',': case '.':
          case '$':
            q++;
            break;
          case ' ': case '\t':
            r = q;
            arg = 0;
            CheckLastArg(&r, &arg);
            if (arg == 0) Result = 1;
            else Result = -1;
            break;
          default:
            printerr("Invalid character to insert\n");
            Result = -2;
          }
        } while (!Result);
        if (q-p > ProgSize-progptr) Result = -3;
        if (Result > 0) {
          Result = 0;
          for (j = ProgSize - 1; j >= ProgSize - (q-p); j--) {
            if (progseg[j] != '$') {
              Result = -3;
              break;
            }
          }
          if (!Result) {
            if (ProgSize-progptr > q-p) /* avoid moving 0 bytes */
              memmove((void *)&progseg[progptr+(q-p)],
                (void *)&progseg[progptr],
                ProgSize - progptr - (q-p));
            memcpy((void *)&progseg[progptr], (void *)&inp[p], q-p);
            repaint = TRUE;
          }
        }
        if (Result == -3) printerr("No room for the string to insert\n");
      }
      break;

    case 'k':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg >= 1) {
        if (arg > ProgSize - progptr) arg = ProgSize - progptr;
        if (arg < ProgSize - progptr) {
          memmove((void *)&progseg[progptr], (void *)&progseg[progptr+arg],
            ProgSize-progptr-arg);
        }
        memset((void *)&progseg[ProgSize-arg], '$', arg);
        repaint = TRUE;
      } else CheckMissing(arg);
      break;

    case 'm':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg >= DataSize) {
        printerr("Invalid data memory address\n");
        arg = -3;
      }
      if (arg >= 0) LastDataDump = arg;
      if (arg >= -1) {
        char txt[80];
        sprintf(txt, "%6d:  ", LastDataDump);
        print(txt);
        for (i = LastDataDump; i < LastDataDump + 16; i++) {
          if (i < DataSize) {
            sprintf(txt, "%02X ", dataseg[i]);
            if (i == dataptr) txt[2] = '<';
          } else strcpy(txt, "   ");
          print(txt);
        }
        print(" ");
        for (i = LastDataDump; i < LastDataDump + 16; i++) {
          if (i < DataSize) txt[i - LastDataDump] = ToPrintable(dataseg[i]);
          else break;
        }
        txt[i - LastDataDump] = '\n';
        txt[i - LastDataDump + 1] = '\0';
        print(txt);
        if (i < DataSize) LastDataDump += 16;
      }
      break;

    case 'v':
      arg = GetLongArg(&p);
      CheckLastArg(&p, &arg);
      if (arg >= DataSize) {
        printerr("Invalid program address\n");
        arg = -3;
      }
      if (arg >= 0) LastProgDump = arg;
      if (arg >= -1) {
        char txt[80];
        sprintf(txt, "%6d:  ", LastProgDump);
        print(txt);
        for (i = LastProgDump; i < LastProgDump + 40; i++) {
          if (i < ProgSize) txt[i - LastProgDump] = progseg[i];
          else break;
        }
        txt[i - LastProgDump] = '\n';
        txt[i - LastProgDump + 1] = '\0';
        print(txt);
        if (i < ProgSize) LastProgDump += 40;
      }
      break;

    case 'l':
      arg = 0;
      CheckLastArg(&p, &arg);
      if (arg == 0) {
        Level = 1;
        BreakAddr = progptr;
        /* Find the address to put a breakpoint in */
        do {
          switch (progseg[BreakAddr++]) {
          case '[':
            Level++;
            break;
          case ']':
            Level--;
          }
        } while (Level && BreakAddr < ProgSize);
        if (Level) print("No end-of-loop found; use \"g\" to go\n");
        else {
          do {
            Step();
          } while (progptr != BreakAddr && progseg[progptr] != '$');
          if (progptr == BreakAddr) print("Loop end reached\n");
          repaint = TRUE;
        }
        BreakAddr = -1;
      }
      break;

    case 'f': case 'w':
      Result = ParseFilename(Path, &p);
      if (Result >= 0) {
        arg = 0;
        CheckLastArg(&p, &arg);
        if (cmd == 'f') SetInputFile(Path);
        else SetOutputFile(Path);
      }
      break;

    case 's':
      Result = ParseFilename(Path, &p);
      if (Result >= 0) {
        arg = 0;
        CheckLastArg(&p, &arg);
        if (Path[0] != '\0') strcpy(fname, Path);
        SaveProgram();
      }
      break;

    case '<': case '>': case '+': case '-': case ',': case '.':
      p--;
      /* Syntax check pass */
      arg = 0;
      do {
        switch(inp[p++]) {
        case '<': case '>': case '+': case '-': case ',': case '.':
          break;
        default:
          arg = 1;
          p--;
          CheckLastArg(&p, &arg);
        }
      } while (arg == 0);
      Result = arg;
      if (Result == 1) {
        p = 0;
        SkipSpaces(&p);
        /* Execution pass */
        Result = 0;
        repaint = TRUE;
        do {
          switch (inp[p++]) {
          case '<':
            if (dataptr > 0) dataptr--;
            else printerr("Hit the start of the data segment\n");
            break;
          case '>':
            if (dataptr < DataSize-1) dataptr++;
            else printerr("Hit the end of the data segment\n");
            break;
          case '+':
            dataseg[dataptr]++;
            break;
          case '-':
            dataseg[dataptr]--;
            break;
          case ',':
            dataseg[dataptr] = inpchar();
            break;
          case '.':
            outchar(dataseg[dataptr]);
            break;
          default:
            Result = 1;
          }
        } while (!Result);
      }
      break;

    case 'h':
    case '?':
      ShowHelp();
      break;

    case '\0':
      break;

    default:
      printerr("\nInvalid debugger command\n");
    }
  } while (TRUE);
}
