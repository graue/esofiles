/* esoldos.h */
/* esolplat.h: DOS and conio version */
/* Public domain, by Alex Smith 2006. */
#define ESOLINIT do {_setcursortype(_NOCURSOR); textmode(C4350);} while(0)
#define ESOLEXIT do {_setcursortype(_NORMALCURSOR); textmode(C80);} while(0)
#define ESOLCLEAR clrscr()
#define ESOLHOME gotoxy(1,1)
#define ESOLPUTCH(x) putch(x)
#define ESOLGETCH esolgetch()
#define ESOLDELAY(x) delay(x)
#define ESOLKBHIT kbhit()
#define ESOLPRINTF cprintf
#define ESOLGETMAXYX(y,x) do {y=50; x=80;} while(0)
#define ESOLKPMSG "any key"
#define ESOLXMSG "'x'"
#define ESOLKHABLE 1
#define ESOLREFRESH
#include <dos.h>
#include <conio.h>
int esolgetch(void)
{
  int c=getch();
  while(kbhit()) getch();
  return c;
}
/* end of esoldos.h */
