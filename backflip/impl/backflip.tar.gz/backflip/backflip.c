/* backflip.c */
/* BackFlip interpreter. Public domain, by Alex Smith 2006. */
/*
 * BackFlip is a 2D language. It only has two commands, apart from NOP (space):
 * / or \:  Flipping mirror. The IP bounces off it, and changes the mirror to
 *          the other orientation.
 * < > ^ V: Backtracking direction change. The IP moves in the direction shown,
 *          and then the direction change points to where the IP came from.
 *
 * An output command also exists in this version.
 * Any digit causes a rebound and outputs that digit.
 * The output command represented by 'N' causes a rebound and outputs a
 * newline.
 * (The output commands are extensions to the language; the language itself
 * has no output.)
 */
#include "esolplat.h"
#include <stdio.h>
#include <stdlib.h>
char           *play(int, int);
void            deallocate(void);
void            playdraw(int, int);
char          **playfield=0;
int             playwidth=1, playheight=0;
int             deblev=0;
enum dirs
{
  left, up, right, down
};
enum dirs       backslashmap[] = {up, left, down, right};
enum dirs       slashmap[] = {down, right, up, left};
enum dirs       reboundmap[] = {right, down, left, up};
void sdatexit(void) {ESOLEXIT;}
int 
main(int argc, char **argv)
{
  FILE *in;
  int             i, j, c1;
  enum dirs       dir = right;
  if (argc != 2 && argc != 3)
  {
    fprintf(stderr, "Usage: backflip <input file> [debug level]\n\n");
    fprintf(stderr, "Debug levels:\n");
    fprintf(stderr, "0: Run without debugging. (default)\n");
    fprintf(stderr, "1: Animate program fullspeed.\n");
    fprintf(stderr, "2: Animate program with delays.\n");
    fprintf(stderr, "3: Animate program, pressing " ESOLKPMSG
            " to delay.\n\n");
#if ESOLKHABLE
    fprintf(stderr, "On debug levels 1 and 2, press any key to abort.\n");
#endif
    fprintf(stderr, "On debug level 3, type " ESOLXMSG " to abort.");
    return argc == 1 ? 0 : EXIT_FAILURE;
  }
  if(argv[2])
  {
    deblev=*argv[2]-'0';
    if(deblev<0||deblev>3) deblev=0;
  }
  in = fopen(argv[1], "r");
  if (!in)
  {
    perror(argv[1]);
    return EXIT_FAILURE;
  }
  i = 0;
  for (;;)
  {
    j = 0;
    for (;;)
    {
      c1 = getc(in);
      if (c1 == EOF)
      {
        if (ferror(in))
        {
          perror(argv[1]);
          fclose(in);
          return EXIT_FAILURE;
        }
        break;
      }
      if (!c1 || c1 == '\n')
        break;
      *play(i, j) = c1;
      j++;
    }
    j--;
    while (++j < playwidth)
    {
      *play(i, j) = ' ';
    }
    i++;
    if (c1 == EOF)
      break;
  }
  fclose(in);
  if(deblev>0) {ESOLINIT; atexit(sdatexit);}
  if(deblev>0) ESOLCLEAR;
  /* Playfield has now been read in. i is the row (y), j is the column (x). */
  i = 0;
  j = 0;
  while (i >= 0 && i < playheight && j >= 0 && j < playwidth &&
         (deblev==0 || deblev==3 || !ESOLKBHIT))
  {
    char           *c = play(i, j);
    switch (*c)
    {
    case '<':
      *c = dir[">V<^"];
      dir = left;
      break;
    case '^':
      *c = dir[">V<^"];
      dir = up;
      break;
    case '>':
      *c = dir[">V<^"];
      dir = right;
      break;
    case 'V':
      *c = dir[">V<^"];
      dir = down;
      break;
    case '\\':
      *c = '/';
      dir = backslashmap[dir];
      break;
    case '/':
      *c = '\\';
      dir = slashmap[dir];
      break;
    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':
      dir = reboundmap[dir];
      if(deblev==0) putchar(*c); else ESOLPUTCH(*c);
      if(deblev==1||deblev==2) ESOLDELAY(2000);
      if(deblev==3) ESOLGETCH;
      break;
    case 'N':
      dir = reboundmap[dir];
      if(deblev==0) putchar('\n'); else {ESOLPRINTF("<newline>\n\r"); ESOLREFRESH;}
      if(deblev==1||deblev==2) ESOLDELAY(2000);
      if(deblev==3) ESOLGETCH;
      break;
    }
    switch (dir)
    {
    case left:
      j--;
      break;
    case up:
      i--;
      break;
    case right:
      j++;
      break;
    case down:
      i++;
      break;
    }
    if(deblev>0) playdraw(i, j);
  }
  deallocate();
  return 0;
}
char           *
play(int row, int col)
{
  void           *temp;
  while (row >= playheight) /* normally happens 0 times */
  {
    playheight++;
    temp = realloc(playfield, sizeof(*playfield) * playheight);
    if (!temp)
    {
      playheight--;
      deallocate();
      fprintf(stderr, "Out of memory.\n");
      exit(EXIT_FAILURE);
    }
    playfield = temp;
    playfield[playheight - 1] = malloc(sizeof(**playfield) * playwidth);
    if (!playfield[playheight - 1])
    {
      playheight--;
      deallocate();
      fprintf(stderr, "Out of memory.\n");
      exit(EXIT_FAILURE);
    }
  }
  if (col >= playwidth)
  {
    if (playheight != 1)
    {
      deallocate();
      fprintf(stderr, "The first line is not the longest.\n");
      exit(EXIT_FAILURE);
    }
    temp = realloc(*playfield, sizeof(**playfield) * (col + 1));
    if (!temp)
    {
      deallocate();
      fprintf(stderr, "Out of memory.\n");
      exit(EXIT_FAILURE);
    }
    *playfield = temp;
    playwidth = col + 1;
  }
  return (playfield[row]) + col;
}
void
deallocate(void)
{
  if (!playfield)
    return;
  while (playheight--)
    free(playfield[playheight]);
  free(playfield);
}
void 
playdraw(int cx, int cy)
{
  int             i, j;
  int             phmin, phmax, pwmin, pwmax;
  int             maxy, maxx;
  phmin=pwmin=0;
  phmax=playheight;
  pwmax=playwidth;
  ESOLGETMAXYX(maxy,maxx);
  while(phmax-phmin>maxy-4)
  {
    if(phmax-cx>cx-phmin) phmax--; else phmin++;
  }
  while(pwmax-pwmin>maxx-1)
  {
    if(pwmax-cy>cy-pwmin) pwmax--; else pwmin++;
  }
  ESOLPRINTF("           \n\r");
  ESOLHOME;
  for (i = phmin; i < phmax; i++)
  {
    for (j = pwmin; j < pwmax; j++)
      ESOLPUTCH(i == cx && j == cy ? 'O' : *play(i, j));
    ESOLPUTCH('\n'); ESOLPUTCH('\r');
  }
  ESOLPUTCH('\n');
  ESOLREFRESH;
  if(deblev==2) ESOLDELAY(100);
  if(deblev==3) if(ESOLGETCH=='x') exit(0);
}
/* end of backflip.c */
