/* esolunix.h */
/* esolplat.h: UNIX and curses version */
/* Public domain, by Alex Smith 2006 */
#define ESOLINIT do {esolwind=initscr(); cbreak();} while(0)
#define ESOLEXIT do {endwin();} while(0)
#define ESOLCLEAR clear()
#define ESOLHOME do {int y,x; getbegyx(esolwind,y,x); move(y,x);} while(0)
#define ESOLPUTCH(x) echochar(x)
#define ESOLGETCH esolgetch()
#define ESOLDELAY(x) usleep((x)*1000L)
#define ESOLKBHIT esolkbhit()
#define ESOLPRINTF printw
#define ESOLGETMAXYX(y,x) do {getmaxyx(esolwind,y,x);} while(0)
#define ESOLKPMSG "any key"
#define ESOLXMSG "'x'"
#define ESOLKHABLE 1
#define ESOLREFRESH refresh()
#include <unistd.h>
#include <curses.h>
WINDOW* esolwind;
int esolgetch(void)
{
  int d;
  int c=getch();
  d='x';
  nodelay(esolwind,1);
  while(d!=ERR) d=getch();
  nodelay(esolwind,0);
  return c;
}
int esolkbhit(void)
{
  int c;
  nodelay(esolwind,1);
  c=getch();
  nodelay(esolwind,0);
  return c!=ERR;
}
/* end of esolunix.h */
