/* esolansi.h */
/* esolplat.h: ANSI C89 standard version */
/* Public domain, by Alex Smith 2006 */
#define ESOLINIT
#define ESOLEXIT
#define ESOLCLEAR printf("\n\n\n\n\n")
#define ESOLHOME
#define ESOLPUTCH(x) putchar(x)
#define ESOLGETCH getchar()
#define ESOLDELAY(x) do {int esold=x/1000; time_t esolt=time(NULL);\
                         if(!esold) esold=1; while(esolt+esold>time(NULL));\
                         } while(0);
#define ESOLKBHIT 0
#define ESOLPRINTF printf
#define ESOLGETMAXYX(y,x) do {y=25; x=80;} while(0)
#define ESOLKPMSG "[Return]"
#define ESOLXMSG "'x', then [Return]"
#define ESOLKHABLE 0
#define ESOLREFRESH
#include <stdio.h>
#include <time.h>
/* end of esolansi.h */
