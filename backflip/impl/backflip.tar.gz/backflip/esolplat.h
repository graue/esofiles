/* esolplat.h */
/* Public domain, by Alex Smith 2006. */
#error Please copy an appropriate esol*.h file over esolplat.h.
/* end of esolplat.h */
