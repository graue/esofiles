/*
 * SnuspI.java
 *
 * Snuspi SNUSP Interpreter 0.1
 * Copyright (C) 2009 Alex Wiegand
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import java.io.*;
import java.util.*;

public class SnuspI extends Thread {
	public static final int MODULAR = 1;
	public static final int BLOATED = 6;
	public static final int RANDOM = 4;
	public static final int FORKING = 8;
	public static final int TOROIDAL = 16;
	public static final int LITERAL = 32;
	public static final int SELF_MULTIPLYING = 32;

	public static final int SNUSP_EXEC = 1;
	public static final int ARB_EXEC = 2;

	private PipeNode pipeNode;
	private Reader codeIn; //= new InputStreamReader(System.in);
	private boolean loadingFromIOChain = false;
	// the input and output streams for the SNUSP program
	private InputStream runIn = null;
	private OutputStream runOut = null;
	// the SNUSP program's memory
	private byte[] mem = new byte[30000];
	// the memory position
	private int pos = 0;
	// the SNUSP program
	private String[] program;
	// the code position
	int curX = 0;
	int curY = 0;
	// the current direction
	int[] forward = new int[] {1, 0};
	// the call-stack in modular SNUSP
	Stack<Call> callStack = new Stack<Call>();
	// whether a muliptlier is being used
	boolean multiplying = false;
	int multiplier = 0;
	private SnuspI parent = null;
	private SnuspI child = null;
	public int forkDepth;
	// brackety command support
	private int bracketyMode = 0;
	private String bracketText = null;
	private SnuspI insertOutputPipeTo = null;

	// modes
	private Mode mode = new Mode();
	static boolean pipeDebug = false;

	public static void main(String[] args) {
		PipeNode node1 = new PipeNode("main");
		SnuspI main = new SnuspI(args, node1);
		main.run();
	}

	public SnuspI(byte[] mem, int pos, String[] program, int[] codePos, 
			int[] forward, Stack<Call> callStack, Mode modeIn,
			SnuspI parent, int bracketyMode, String bracketText,
			PipeNode pipeNodeIn) {
		this.mem = mem.clone();
		this.pos = pos;
		this.program = program;
		this.curX = codePos[0];
		this.curY = codePos[1];
		this.forward = forward.clone();
		// caution: This is only a shallow copy.
		// This is fine as long as no-one edits the co-ordinates inside the
		// entries in the call-stack.
		this.callStack = castToCallStack(callStack.clone());
		this.mode = modeIn.clone();

		this.parent = parent;
		if (parent != null) {
			forkDepth = parent.forkDepth + 1;
			child = parent.getChild();
		}
		this.bracketyMode = bracketyMode;
		this.bracketText = bracketText;
		setPipeNode(pipeNodeIn);
	}

	public long multiplyByBoolean(long a, boolean b) {
		if (!b) {
			return 0;
		}
		return a;
	}

	/**
 	 * Not-zero.
 	 */
	private boolean nz(long l) {
		return l != 0;
	}

	@SuppressWarnings("unchecked")
	private Stack<Call> castToCallStack(Object o) {
		return (Stack<Call>) o;
	}

	public SnuspI(String[] args, PipeNode pipeNodeIn) {
		// prepare to extract command options
		List<String> argList = new LinkedList<String>();
		List<String> optList = new ArrayList<String>();
		String[] paramOpts = {};
		Map<String, String> optArgMap = new HashMap<String, String>();
		for (String arg : args) {
			argList.add(arg);
		}
		// extract command options
		extractCommandOptions(argList, optList, paramOpts, optArgMap);

		setPipeNode(pipeNodeIn);
		if (optList.contains("-pd")) {
			pipeDebug = true;
			pipeNodeIn.setPipeDebug(true);
		}
		if (optList.contains("-d")) {
			mode.debug = true;
		}

		// load the program
		String inFn = "-";
		if (argList.size() > 0) {
			inFn = argList.get(0);
		}
		try {
			load(inFn);
		} catch (IOException e) {
			System.err.println("Problem reading input file:");
			e.printStackTrace(System.err);
		}

		// initialise the program
		initProgram();

		forkDepth = 0;
	}

	public void load(String fn) throws IOException {
		// read input filename
		// "-" means stdin
		if (!fn.equals("-")) {
			codeIn = new FileReader(fn);
		} else {
			codeIn = new InputStreamReader(runIn);
			loadingFromIOChain = true;
		}
	}

	public String programToString() {
		StringBuilder sb = new StringBuilder();
		for (int y = 0; y < program.length; y++) {
			sb.append(program[y]);
			sb.append('\n');
		}
		return sb.toString();
	}

	public void initProgram() {
		String line;
		int x;

		// copy the program into memory
		if (loadingFromIOChain) {
			pipeNode.setStickyEOF(true);
		}
		program = readProgram();
		if (loadingFromIOChain) {
			pipeNode.setStickyEOF(false);
		}
		loadingFromIOChain = false;
		// get the starting position
		// the starting position is the first occurrence of '$',
		// or otherwise (0, 0)
		for (int y = 0; y < program.length; y++) {
			line = program[y];
			x = line.indexOf('$');
			if (x != -1) {
				curX = x;
				curY = y;
				break;
			}
		}
	}

	public void run() {
		boolean exit;
		if (program == null) {
			return;
		}
		// execute the program
		do {
			exit = step();
		} while (!exit);
		if (pipeDebug) {
			System.err.println(forkDepth + ": finished executing");
		}

		try {
			runOut.flush();
			runOut.close();
		} catch (IOException e) {
			e.printStackTrace(System.err);
		}
	}

	public SnuspI getChild() {
		return child;
	}

	/**
	 * @return <code>true</code> if the command says to exit.
	 */
	public boolean step() {
		boolean exit;
		// an effect I (deschutron) call choking:
		// when the current line is empty (ie length == 0),
		// terminate the program
		if (program[curY].length() == 0) {
			System.err.println("\nempty line reached");
			return true;
		}
		exit = doOp(charAt(curX, curY));
		curX += forward[0];
		curY += forward[1];
		if (mode.toroidal) {
			if (program.length == 0) {
				exit = true;
				System.err.println("empty program");
				return exit;
			}
			curY = mod(curY, program.length);
			if (program[curY].length() > 0) {
				curX = mod(curX, program[curY].length());
			}
		} else if (outOfBounds(curX, curY)) {
			exit = true;
		}
		return exit;
	}

	/**
	 * @param base the base of the modulo operation. Must be positive.
	 */
	public int mod(int num, int base) {
		int b = Math.abs(base);
		int n = num;
		if (b != 0) {
			while (n < 0) {
				n += b;
			}
		}
		return n % b;
	}

	public boolean outOfBounds(int x, int y) {
		if (y >= program.length) {
			return true;
		}
		if (y < 0) {
			return true;
		}
		if (x >= program[y].length()) {
			return true;
		}
		if (x < 0) {
			return true;
		}
		return false;
	}

	public boolean doOp(char c) {
		boolean exit = false;
		if (bracketText != null && c != '}') {
			bracketText += c;
			return exit;
		}
		if (mode.literal && c >= '0' && c <= '9') {
			if (multiplying == false) {
				multiplier = c - '0';
				multiplying = true;
			} else {
				multiplier *= 10;
				multiplier += (c - '0');
			}
			return exit;
		}
		if (mode.selfMultiplying && c == '*') {
			if (multiplying == false) {
				multiplier = mem[pos];
				multiplying = true;
			}
		}
		if (mode.literal && multiplying) {
			multiplying = false;
			// optimised multiple operations
			switch (c) {
			case '<':
				pos -= multiplier;
				pos = mod(pos, mem.length);
				break;
			case '>':
				pos += multiplier;
				pos = mod(pos, mem.length);
				break;
			case '+':
				mem[pos] += multiplier;
				break;
			case '-':
				mem[pos] -= multiplier;
				break;
			default:
				for (int i = 0; i < multiplier; i++) {
					exit |= doOp(c);
					if (exit) {
						break;
					}
				}
			}
			return exit;
		}
		switch (c) {
		case '<':
			if (pos == 0) {
				pos = mem.length - 1;
			} else {
				pos--;
			}
			break;
		case '>':
			pos++;
			pos %= mem.length;
			break;
		case '+':
			mem[pos]++;
			break;
		case '-':
			mem[pos]--;
			break;
		case ',':
			try {
				mem[pos] = (byte) runIn.read();
			} catch (IOException e) {
				e.printStackTrace(System.err);
			}
			break;
		case '.':
			try {
				runOut.write(ubyteToChar(mem[pos]));
				runOut.flush();
			} catch (IOException e) {
				e.printStackTrace(System.err);
			}
			break;
		case '!':
			curX += forward[0];
			curY += forward[1];
			break;
		case '?':
			if (mem[pos] == 0) {
				curX += forward[0];
				curY += forward[1];
			}
			break;
		case '\\':
			lurd();
			break;
		case '/':
			ruld();
			break;
		case '@':
			if (mode.modular) {
				enter();
			}
			break;
		case '#':
			if (mode.modular) {
				exit = leave();
			}
			break;
		case '%':
			if (mode.random) {
				mem[pos] = (byte) (Math.random() * 256.0);
			}
			break;
		case 'Y':
			if (mode.forking) {
				fork();
			}
			break;
		case 'D':
			if (mode.debug) {
				System.err.println(stateToString());
			}
			break;
		case 'F':
			if (mode.debug) {
				System.err.println("FD: " + forkDepth);
			}
			break;
		case '~':
			if (bracketyMode == SNUSP_EXEC) {
				bracketyMode = ARB_EXEC;
			} else {
				bracketyMode = SNUSP_EXEC;
			}
			break;
		case '{':
			if (bracketyMode != 0) {
				bracketText = "";
			}
			break;
		case '}':
			if ((bracketText != null) && (bracketyMode != 0)) {
				switch (bracketyMode) {
				case SNUSP_EXEC:
					snuspExec(bracketText);
					break;
				case ARB_EXEC:
					arbExec(bracketText);
					exit = true;
					break;
				}
				bracketText = null;
				bracketyMode = 0;
			}
			break;
		default:
		}
		return exit;
	}

	public char ubyteToChar(byte b) {
		int c = (int) b;
		if (b == -1) {
			return 255;
		}
		return (char) (c & 255);
	}

	private void setPipeNode(PipeNode nodeIn) {
		pipeNode = nodeIn;
		runIn = nodeIn.getInputStream();
		runOut = nodeIn.getOutputStream();
	}

	private byte read() throws IOException {
		int c = 0;
		return (byte) c;
	}

	public void pruneParent() {
		parent = parent.getParent();
		if (parent != null) {
			forkDepth = parent.forkDepth + 1;
		}
	}

	public void setParent(SnuspI parent) {
		this.parent = parent;
		if (parent != null) {
			forkDepth = parent.forkDepth + 1;
		}
	}

	public SnuspI getParent() {
		return parent;
	}

	/**
	 * Do not change the values of runIn or runOut in this method
	 * or any of its delegates.
	 * Part of the beauty of forking and execking is creating
	 * a communication network and then replacing nodes in it with
	 * prebuilt programs.
	 */
	public synchronized void snuspExec(String cmd) {
		try {
			load(cmd);
			initProgram();
			reset();
		} catch (IOException e) {
			mem[pos] = (byte) 255;
		}
	}

	public void reset() {
		callStack = new Stack<Call>();
		mem = new byte[mem.length];
	}

	public void arbExec(String cmd) {
		new JNIPart().go(new String[] {cmd});
	}

	public void enter() {
		if (forward == null) {
			System.err.println("forward is null!");
		}
		callStack.push(new Call(curX + forward[0], curY + forward[1], forward));
	}

	public boolean leave() {
		if (callStack.empty()) {
			return true;
		}
		Call popped;
		popped = callStack.pop();
		curX = popped.getCur()[0];
		curY = popped.getCur()[1];
		if (popped ==null) {
			System.err.println("WTF!");
		}
		if (popped.getForward() ==null) {
			System.err.println("WTF!2");
		}
		if (popped.getForward().clone() ==null) {
			System.err.println("WTF!3");
		}
		if (this ==null) {
			System.err.println("WTF!4");
		}
		forward = popped.getForward().clone();
		return false;
	}

	/**
	 * Does the FORK instruction.<p/>
	 * Sets the current position in memory to<br/>
	 *   0 in the parent,<br/>
	 *   1 in the child,<br/>
	 * 255 in the event of an error (in the parent).<p/>
	 * The output channel of the parent and the input channel of the child
	 * are tied together.<br/>
	 * stdin → Parent → Child → stdout<br/>
	 * The child is effectively a decorator fot the parent's output.
	 * When a parent or child terminates, it is removed from the IO chain.
	 */
	public void fork() {
		int[] childCur = {curX + forward[0], curY + forward[1]};
		SnuspI oldChild = child;
		String childNodeName = "fork";
		if (pipeNode.getName().equals("fork")) {
			childNodeName = "mork";
		} else if (pipeNode.getName().equals("mork")) {
			childNodeName = "rork";
		} else if (pipeNode.getName().equals("rork")) {
			childNodeName = "lork";
		} else if (pipeNode.getName().equals("lork")) {
			childNodeName = "fork";
		}
		if (pipeNode.getNext() != null && 
				pipeNode.getNext().getName().equals(childNodeName)) {
			childNodeName = (childNodeName.charAt(0) + "").toUpperCase() +
					childNodeName.substring(1, childNodeName.length());
		}
		PipeNode node2 = new PipeNode(childNodeName);
		node2.setPipeDebug(pipeDebug);
		pipeNode.insert(node2);
		try {
			child = new SnuspI(
				mem, pos, program, childCur,
				forward, callStack, mode, this,
				bracketyMode, bracketText, node2
			);
			child.setMemValue(pos, (byte) 1);
			mem[pos] = 0;
			if (oldChild != null) {
				oldChild.setParent(child);
			}

			// run the child
			// The new child will unfreeze the old child.
			child.start();
		} catch (VirtualMachineError e) {
			mem[pos] = (byte) 255;
			node2.remove();
		}
	}

	public void insertYourOutputPipeAtStartOfQueueOf(SnuspI s) {
		insertOutputPipeTo = s;
	}

	/**
	 * backslash '\'<br/>
	 *  1,  0		 0,  1
	 *  0, -1		-1,  0
	 * -1,  0		 0, -1
	 *  0,  1		 1,  0
	 */
	private void lurd() {
		forward = new int[] {forward[1], forward[0]};
	}

	/**
	 * forward-slash '/'<br/>
	 *  1,  0		 0, -1
	 *  0, -1		 1,  0
	 * -1,  0		 0,  1
	 *  0,  1		-1,  0
	 */
	private void ruld() {
		// RULD can be achieved by swapping forward's co-ordinate values,
		// and negativising both of them.
		forward = new int[] {-forward[1], -forward[0]};
	}

	public char charAt(int x, int y) {
		return program[y].charAt(x);
	}

	public String[] readProgram() {
		String line;
		char c;
		boolean exit;
		BufferedReader bufIn = new BufferedReader(codeIn);
		List<String> lineList = new ArrayList<String>();
		// copy the code into memory
		try {
			while (true) {
				line = bufIn.readLine();
				if (line == null) {
					break;
				}
				lineList.add(line);
			}
		} catch (IOException e) {
			System.err.println("Error reading program:");
			e.printStackTrace(System.err);
			return null;
		}
		if (loadingFromIOChain && parent != null) {
			pruneParent();
		}
		return lineList.toArray(new String[0]);
	}

	public void setMemValue(int pos, byte value) {
		mem[pos] = value;
	}

	public String stateToString() {
		String rv = "";
		rv += "cur: (" + curX + ", " + curY + ")\t\t\t";
		rv += "pos: " + pos + "\n";
		rv += "mem[pos]: " + mem[pos] + "\n";
		rv += "mem[0..3]: " + mem[0] + ", " + mem[1] + ", " + mem[2] +
		      ", " + mem[3] + '\n';
		rv += "direction: " + Arrays.toString(forward) + '\t';
		rv += "callstack length: " + callStack.size() + '\n';
		rv += "forkdepth: " + forkDepth;
		return rv;
	}

	/**
	 * Extracts command-line <code>options</code> for a List of command
	 * arguments.
	 * Finds options in <code>argList</code> and removes them from 
	 * <code>argList</code>.
	 * Adds the options to <code>optList</code>.
	 * For parametric command options, adds entries to <code>optArgMap</code>
	 * mapping the options to their parameter values.
	 */
	public static void extractCommandOptions(List<String> argList,
			List<String> optList, String[] parametricCommandOptions,
			Map<String, String> optArgMap) {
		String cur;
		for (int i = 0; i < argList.size(); i++) {
			cur = argList.get(i);
			if (cur.charAt(0) == '-' && cur.length() > 1) {
				optList.add(cur);
				if (i + 1 < argList.size()) {
					for (String s : parametricCommandOptions) {
						if (cur.equals(s)) {
							optArgMap.put(cur, argList.get(i + 1));
							argList.remove(i + 1);
							break;
						}
					}
				}
				argList.remove(i--);
			}
		}
	}
}
