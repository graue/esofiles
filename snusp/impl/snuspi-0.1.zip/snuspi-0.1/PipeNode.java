/*
 * PipeNode.java
 *
 * Snuspi SNUSP Interpreter 0.1
 * Copyright (C) 2009 Alex Wiegand
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import java.io.*;
import java.util.*;

public class PipeNode implements Closeable {
	/** The previous node. */
	private PipeNode prev = null;
	/** The next node. */
	private PipeNode next = null;
	/** The queue of bytes waiting to be read. */
	private LinkedList<Integer> input = new LinkedList<Integer>();
	/** Whether an EOF should be final.
	 *  When this is set to true, only one file may be read. */
	private boolean stickyEOF = false;
	/** Whether the write-stream is closed. */
	private boolean wClosed = false;
	/** The OutputStream wrapper for this node. */
	private PipeNodeOutputStream out = null;
	/** The name of this node. Used for debugging. */
	private String name;
	/** The thread that is waiting in the read method, if any. */
	private Thread reading = null;
	private boolean eofHasOccurred = false;
	private boolean pipeDebug = false;

	/**
	 * Creates a new PipeNode.
	 * The name is set to the node's Object name.
	 */
	public PipeNode() {
		name = super.toString();
	}

	/**
	 * Creates a new PipeNode with the name specified.
	 */
	public PipeNode(String nameIn) {
		name = nameIn;
	}

	/**
	 * Returns the node's name.
	 */
	public String toString() {
		return name;
	}

	public String getName() {
		return name;
	}

	public void setPipeDebug(boolean pDbgIn) {
		pipeDebug = pDbgIn;
	}

	/**
	 * Returns the number of bytes available for reading without
	 * a blocking call. Returns the number of bytes in the input queue.
	 */
	public int available() throws IOException {
		if (prev == null) {
			return System.in.available();
		}
		int end = input.indexOf(-1);
		if (end == -1) {
			return input.size();
		} else {
			return end;
		}
	}

	/**
	 * Adds a value to the input queue.
	 * The value may be either a byte or -1, signifying EOF.
	 */
	public synchronized boolean enqueue(int c) {
		boolean rv = input.offer(c);
		// wake up any thread waiting in read()
		if (reading != null) {
			reading.interrupt();
		}
		return rv;
	}

	/**
	 * Returns true iff this node is the head node.
	 * The head node reads directly from standard input.
	 */
	public boolean isHead() {
		return prev == null;
	}

	/**
	 * Returns the next node in the pipe.
	 */
	public PipeNode getNext() {
		return next;
	}

	/**
	 * Reads one byte from the prior node, or stdin.
	 * If some values are waiting in the input queue,
	 * polls the first value from there.
	 */
	public int read() throws IOException {
		if (stickyEOF && eofHasOccurred) {
			return -1;
		}
		if (prev == null && input.isEmpty()) {
			int c = System.in.read();
			if (pipeDebug) {
				System.err.println(this + "r: " + c);
			}
			if (stickyEOF && c == -1) {
				eofHasOccurred = true;
			}
			// returning breaks the loop
			return c;
		}
		int count = 0;
		int rv;
		reading = Thread.currentThread();
		while (input.isEmpty()) {
			// sleep until enqueue wakes the thread up
			// because there are bytes in the queue
			try {
				// sleep for a day
				Thread.sleep(86400000);
				count++;
			} catch (InterruptedException e) {
				// check whether there is anything to wake up for
			}
			// if prev became null during the sleep,
			if (prev == null) {
				// goto top ;)
				return read();
			}
		}
		synchronized (this) {
			// We must check again just in case it was emptied
			// between the end of the while loop and
			// the start of the synchronisation.
			if (!input.isEmpty()) {
				reading = null;
				rv = input.poll();
				if (stickyEOF && rv == -1) {
					eofHasOccurred = true;
				}
				if (pipeDebug) {
					System.err.println(this + "r: " + rv);
				}
				return rv;
			}
		}
		return read();
	}

	public synchronized void write(int b) throws IOException {
		if (pipeDebug) {
			System.err.println(this + "w: " + b);
		}
		if (next == null) {
			if (b == -1) {
				System.out.close();
			} else {
				System.out.write(b);
			}
			return;
		}
		next.enqueue(b);
	}

	public int read(byte[] b) throws IOException {
		return read(b, 0, b.length);
	}

	public int read(byte[] b, int off, int len) throws IOException {
		if (stickyEOF && eofHasOccurred) {
			return -1;
		}
		synchronized (input) {
			// don't read from stdin if there is input waiting in the queue
			if (prev == null && input.isEmpty()) {
				int rv;
				rv = System.in.read(b, off, len);
				if (rv < len && stickyEOF) {
					eofHasOccurred = true;
				}
				if (pipeDebug) {
					System.err.println(this + "r " + len + " bytes: " + rv);
				}
				return rv;
			}
		}
		int count = 0;
		int c;
		for (int i = off; count < len; i++) {
			c = read();
			if (c == -1) {
				break;
			}
			b[i] = (byte) c;
			count++;
		}
		if (count == 0) {
			return -1;
		}
		if (pipeDebug)  {
			System.err.println(this + "r " + len + " bytes: " + count);
		}
		return count;
	}

	public synchronized void write(byte[] b, int off, int len) throws IOException {
		if (pipeDebug) {
			System.err.println(this + "w " + len + " bytes");
		}
		if (next == null) {
			System.out.write(b, off, len);
			return;
		}
		int count = 0;
		for (int i = off; count < len; i++) {
			next.enqueue(b[i]);
			count++;
		}
	}

	public synchronized void write(byte[] b) throws IOException {
		write(b, 0, b.length);
	}

	public void flush() throws IOException {
		if (next == null) {
			System.out.flush();
		}
	}

	/**
	 * closes the node for writing.
	 */
	public synchronized void close() throws IOException {
		// flush the output stream
		flush();
		if (wClosed) {
			return;
		}
		// tell the next node, or stdout, that the file from this node
		// has ended
		write(-1);
		// remove this node from the pipe
		remove();
		wClosed = true;
	}

	public void rClose() throws IOException {
		// pass the message onto stdin, if connected to it
		if (prev == null) {
			System.in.close();
		}
	}

	public void finalize() {
		try {
			close();
			rClose();
		} catch (IOException e) {
		}
	}

	/**
	 * Returns an InputStream front-end to this node.
	 */
	public InputStream getInputStream() {
		return new PipeNodeInputStream(this);
	}

	public OutputStream getOutputStream() {
		if (out == null) {
			out = new PipeNodeOutputStream(this);
		}
		return out;
	}

	public void mark(int readlimit) {
		if (prev == null) {
			System.in.mark(readlimit);
		}
	}

	public boolean markSupported() {
		if (prev == null) {
			return System.in.markSupported();
		}
		return false;
	}

	public void reset() throws IOException {
		if (prev == null) {
			System.in.reset();
		}
	}

	/**
	 * Makes the first EOF to be read final.
	 * Every subsequent read() will return -1
	 * until stickyEOF is turned off again.
	 */
	public synchronized void setStickyEOF(boolean stickyIn) {
		// clear eofHasOccurred when stickyEOF is set to true.
		// We only want to use this variable when stickyEOF is true.
		eofHasOccurred = false;
		stickyEOF = stickyIn;
	}

	public long skip(long n) throws IOException {
		if (prev == null) {
			return System.in.skip(n);
		}
		long skipped;
		for (skipped = 0; skipped < n; skipped++) {
			if (read() == -1) {
				close();
				break;
			}
		}
		return skipped;
	}

	public synchronized void insert(PipeNode newNode) {
		// Four references must be changed to insert a node into
		// the pipe. Those four changes are performed here.
		newNode.setNext(next);
		if (next != null) {
			next.setPrev(newNode);
		}
		newNode.setPrev(this);
		next = newNode;
	}

	public synchronized void remove() {
		// relay all the bytes in the queue
		// so that they aren't lost
		int c;
		int count = 0;
		if (pipeDebug) {
			System.err.println(name + "q: " + input);
		}
		try {
			while (!input.isEmpty()) {
				c = input.poll();
				if (pipeDebug) {
					System.err.println(name + "unq: " + c);
				}
				write(c);
				count++;
			}
		} catch (IOException e) {
			System.err.println("Write error emptying input queue of removed node");
		}

		// remove this node from the tree
		// It takes four steps. They are done here.
		if (next != null) {
			next.setPrev(prev);
		}
		if (prev != null) {
			prev.setNext(next);
		}
		prev = null;
		next = null;
	}

	protected void setPrev(PipeNode prevIn) {
		prev = prevIn;
		// if the read method is currently waiting
		// for things to enter the queue,
		if (reading != null) {
			// let it know that prev has changed
			reading.interrupt();
		}
	}

	protected void setNext(PipeNode nextIn) {
		next = nextIn;
	}
}
