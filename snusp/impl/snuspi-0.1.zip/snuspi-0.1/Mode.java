/*
 * Mode.java
 *
 * Snuspi SNUSP Interpreter 0.1
 * Copyright (C) 2009 Alex Wiegand
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/**
 * Specifies the set of features to run with in a SnuspI instance.
 */
public class Mode implements Cloneable {
	public boolean modular = true;
	// bloated is not implemented
	public boolean bloated = false;
	public boolean random = true;
	public boolean forking = true;
	public boolean toroidal = true;
	public boolean literal = true;
	public boolean selfMultiplying = false;
	public boolean debug = false;

	public Mode clone() {
		Mode rv = new Mode();
		rv.modular = modular;
		rv.bloated = bloated;
		rv.random = random;
		rv.forking = forking;
		rv.toroidal = toroidal;
		rv.literal = literal;
		rv.selfMultiplying = selfMultiplying;
		rv.debug = debug;
		return rv;
	}
}

