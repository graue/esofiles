/*
 * JNIPart.c
 *
 * Snuspi SNUSP Interpreter 0.1
 * Copyright (C) 2009 Deschutron
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <jni.h>
#include <stdio.h>
//#include <unistd.h>
#include "JNIPart.h"

/*jstring toString(JNIEnv* env, jobject obj) {
	jclass clazz = FindClass(env, "java.lang.Object");
	jmethodID methodID =
		GetMethodID(env, clazz, "toString", "()[Ljava/lang/String;V");
	CallObjectMethod(env, obj, methodID);
}*/

JNIEXPORT void JNICALL
Java_JNIPart_exec(JNIEnv* env, jobject obj, jstring jpath, jobjectArray jargs) {
	char* path;
	jsize argC = (jsize) (*env)->GetArrayLength(env, (jarray) jargs);
	int i;
	jstring tempS;
	//printf("argC == %d;\n", argC);
	char* args[argC + 1];
	path = (char*) (*env)->GetStringUTFChars(env, jpath, NULL);
	for (i = 0; i < argC; i++) {
		//printf("start of loop %d\n", i);
		tempS = (jstring) (*env)->GetObjectArrayElement(env, jargs, i);
		args[i] = (char*) (*env)->GetStringUTFChars(env, tempS, NULL);
	}
	args[argC] = 0;
	//printf("line above fork\n");
	/*if (fork()) {
		printf("line above exec\n");
		execvp(path, args);
	}
	printf("line below fork and exec\n");*/

	// contrary to this function's signature,
	// all the arguments should be put into the
	// path parameter, for this implementation at least.
	system(path);
	return;
}
