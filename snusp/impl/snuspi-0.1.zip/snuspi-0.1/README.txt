=Snuspi 0.1 README File=
by Alex Wiegand 2009

==This folder contains==
  1. the source code of Snuspi, in .java files;
  2. the bytecode of Snuspi, in .class files;
  3. a bash script called "snuspi"; and
  4. the three files a JNIPart.c, JNIPart.h and libJNIPart.so.

  The .class files should be runnable as-is.
  The .java files should be compilable and then runnable as-is.
  The bash script needs editing before it can work. The bash script is for convenience.

  The libJNIPart.so is a linux-format sofware library compiled form JNIPart.c.
  Snuspi will use it if called on to execute a SHELL EXEC (~~{xxxx}) instruction.
  If the operating system doesn't support .so files, Snuspi should crash upon attempting to run a SHELL EXEC instruction, and not before.
  It is theoretically possible to compile JNIPart.c to build a .dll library, so it works on Windows.
  By the way SHELL EXEC is a megawimp, OS-specific, non-standard instruction in SNUSP, and I don't encourage dependence on it.

==Running==
This command should work:
 $ java -Djava.library.path=. SnuspI FILE.SNU

where FILE.SNU is the SNUSP program to run.

==Modifying==
I release SNUSP under GNU GPL 2, so you can edit it and share your version under GPL. I made sure not to release it before it worked, so modification shouldn't be required, but improvements are welcome.

==About Snuspi==
Snuspi is an interpreter I wrote for SNUSP, and it contains some extensions that I added.

As well as Core SNUSP, and my extensions, Snuspi supports Modular SNUSP, and the RAND '%' instruction listed under Bloated SNUSP on http://esolangs.org/wiki/SNUSP.

This release (0.1) doesn't have all the extensions turned off by default, but they usually won't interfere with plain SNUSP programs. Any program that doesn't contain the chars 'Y', '0'-'9', '~', '{', or '}' in its code path will not be affected.

==Extensions==
 Y        FORK  (Analogue to a combination of Unix fork() and pipe().)
          $Y?\++++.#
             \,+++.#  outputs the byte value 7.
 0-9      Multipliers
          10+  means  ++++++++++
 ~{xxx}   SNUSP EXEC  (Analogue to Unix exec().)
          ~{alice.snu} runs alice.snu and terminates the snusp program that calls it.
 ~~{xxx}  SHELL EXEC
          ~~{cp alice/bob dfgy.txt} asks the OS's command shell (e.g. bash, DOS) to execute the command "cp alice/bob dfgy.txt", and terminates the snusp program.

==Stdin execution in SNUSP EXEC==
Snuspi's implementation of SNUSP EXEC contains an important quirk.

If you run a program that contains "~{-}", and the progam runs that statement, Snuspi will then read a file of input (read until EOF) and then execute that input as a SNUSP program. My example program Snuspatron uses this feature in order to function as a command shell.
