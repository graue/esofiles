=Snuspatron Command Shell 1.0=
Snuspatron 1.0 is an interactive shell for running SNUSP programs, 
implemented in Forking, Executive Modular SNUSP.

Snuspatron itself is composed of the following files:
1. snuspatron
2. cmdNotFound.snu
3. libsnuspatron/prefix.snu
4. libsnuspatron/prompt.snu
5. libsnuspatron/readAndRun.snu
6. libsnuspatron/suffix.snu
7. libsnuspatron/welcome.snu

==Credit and copyright==
This program is created by Alex Wiegand in 2009.
I, Alex Wiegand, release this code in its present state into the Public Domain.

==Running Snuspatron==
To run Snuspatron,
execute the file "snuspatron"
in a Forking, Executive, Decimal Modular SNUSP interpreter.

The process to compile Snuspatron
really depends on the nature of the SNUSP compiler.
No SNUSP compiler has been made for Executive SNUSP at the time of writing.

When you run Snuspatron,
you should be greeted with the following text:
 Snuspatron Command Shell
  $ _

where _ is the place where you can type.

Typing the name of a SNUSP program file and pressing Enter should cause that
program file to be run.

To exit Snuspatron, you must enter an EOF marker on its command line.
In Unix-based systems,
 * Type Ctrl+D
In DOS or Windows command prompt,
 * Type Ctrl+Z
 * Press Enter

There are some other files in this directory.
Those are SNUSP programs that are included to provide a basic set of commands
to try out.

Those programs are:
0	1	2	3	4	5
cat         C   reads a file from stdin, a prints it to stdout
catTwice    C   reads two files from stdin, and prints them stdout
double      C   reads a byte and returns it's value x 2
echo        M   prints its command arguments
forkmult    MF  reads two bytes, multiplies them and writes the result binarily
hello       M   prints "Hello world!"
helloAndCat M   prints "Hello world!", reads a file from stdin and prints it
iObey       E   reads a SNUSP program from stin and executes it
memoriser   M   reads a file from stdin, stores it in memory, and then prints it
yes         M   prints lines of "y" in an infinite loop

Note: you cannot kill yes without killing Snuspatron.

The version specifiers say the minimum type of SNUSP needed to run
the programs.
0   1   2   3
  C     Core SNUSP
  M     Modular SNUSP
  F     Forking SNUSP
  E     Executive SNUSP, 1st level

Forking and Executive SNUSP are described at
http://esolangs.org/wiki/SNUSP/Extensions .

==Argument sending==
When asked to invoke a command with arguments,
Snuspatron uses the EPARM protocol (http://esolangs.org/wiki/EPARM).

==Next goals in development==
These are the things that Deschutron plans to do next.
===Undecimalisation===
Snuspatron, and some of its bundled commands are written in Decimal SNUSP,
a wimp-mode that greatly eased creation of the programs,
but damages the near-orthogonality of the variant of SNUSP required to run
them.

The plan is to replace the decimal multipliers with Modular SNUSP enter-leave
multipliers, similar to those used in echo.

===Command-losing bug===
There is a bug that when the user types an invalid command followed by a
valid command, Snuspatron refuses to follow the valid command,
under some conditions. The cauise is suspected to lie within the Memoriser
component inside snuspatron.

This should be fixed.
