#!/bin/sh
./glass cache GlassBot GregorR esoteric > GLASSOUT
